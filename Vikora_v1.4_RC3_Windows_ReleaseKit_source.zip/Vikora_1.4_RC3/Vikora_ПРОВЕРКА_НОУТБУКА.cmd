@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0packaging\diagnose_windows.ps1"
if errorlevel 1 (
  echo.
  echo Vikora Windows check did not complete.
  pause
)
