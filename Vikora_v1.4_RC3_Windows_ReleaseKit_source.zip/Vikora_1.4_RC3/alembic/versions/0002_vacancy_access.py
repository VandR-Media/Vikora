"""Add explicit per-vacancy membership.

Revision ID: 0002_vacancy_access
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_vacancy_access"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "vacancy_access",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("vacancy_id", sa.Uuid(), sa.ForeignKey("vacancies.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.Uuid(), sa.ForeignKey("user_accounts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("role", sa.String(20), nullable=False),
        sa.CheckConstraint("role IN ('editor', 'viewer')", name="ck_access_role"),
        sa.UniqueConstraint("vacancy_id", "user_id", name="uq_vacancy_access_user"),
    )
    op.create_index("ix_vacancy_access_vacancy_id", "vacancy_access", ["vacancy_id"])
    op.create_index("ix_vacancy_access_user_id", "vacancy_access", ["user_id"])


def downgrade():
    op.drop_index("ix_vacancy_access_user_id", table_name="vacancy_access")
    op.drop_index("ix_vacancy_access_vacancy_id", table_name="vacancy_access")
    op.drop_table("vacancy_access")
