"""Track durable filesystem erasure after candidate row deletion.

Revision ID: 0003_privacy_lifecycle
Revises: 0002_vacancy_access
"""
import sqlalchemy as sa
from alembic import op

revision = "0003_privacy_lifecycle"
down_revision = "0002_vacancy_access"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "purge_requests",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("actor_id", sa.Uuid(), sa.ForeignKey("user_accounts.id", ondelete="SET NULL")),
        sa.Column("reason", sa.String(32), nullable=False),
        sa.Column("application_count", sa.Integer(), nullable=False),
        sa.Column("resume_count", sa.Integer(), nullable=False),
        sa.Column("evaluation_count", sa.Integer(), nullable=False),
        sa.Column("audit_redacted_count", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
    )
    op.create_table(
        "purge_blobs",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("request_id", sa.Uuid(), sa.ForeignKey("purge_requests.id", ondelete="CASCADE"), nullable=False),
        sa.Column("storage_key", sa.String(500), nullable=False),
        sa.Column("state", sa.String(16), nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False),
        sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("error_code", sa.String(80)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
        sa.UniqueConstraint("storage_key", name="uq_purge_blob_key"),
    )
    op.create_index("ix_purge_blobs_request_id", "purge_blobs", ["request_id"])
    op.create_index("ix_purge_blobs_due", "purge_blobs", ["state", "next_attempt_at"])
    # Do not automatically change legacy NULL retention deadlines: they need policy review.


def downgrade():
    op.drop_index("ix_purge_blobs_due", table_name="purge_blobs")
    op.drop_index("ix_purge_blobs_request_id", table_name="purge_blobs")
    op.drop_table("purge_blobs")
    op.drop_table("purge_requests")
