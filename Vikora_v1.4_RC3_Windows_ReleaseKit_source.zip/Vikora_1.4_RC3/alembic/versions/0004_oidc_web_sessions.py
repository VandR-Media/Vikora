"""Browser OIDC login attempts and revocable sessions.

Revision ID: 0004_oidc_web_sessions
Revises: 0003_privacy_lifecycle
"""
import sqlalchemy as sa
from alembic import op

revision = "0004_oidc_web_sessions"
down_revision = "0003_privacy_lifecycle"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "oidc_login_attempts",
        sa.Column("state_hash", sa.String(64), primary_key=True),
        sa.Column("browser_binding_hash", sa.String(64), nullable=False),
        sa.Column("code_verifier", sa.String(128), nullable=False),
        sa.Column("nonce", sa.String(128), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_oidc_login_attempts_expires", "oidc_login_attempts", ["expires_at"])
    op.create_table(
        "web_sessions",
        sa.Column("token_hash", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.Uuid(), sa.ForeignKey("user_accounts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_web_sessions_user_id", "web_sessions", ["user_id"])
    op.create_index("ix_web_sessions_expires", "web_sessions", ["expires_at"])


def downgrade():
    op.drop_index("ix_web_sessions_expires", table_name="web_sessions")
    op.drop_index("ix_web_sessions_user_id", table_name="web_sessions")
    op.drop_table("web_sessions")
    op.drop_index("ix_oidc_login_attempts_expires", table_name="oidc_login_attempts")
    op.drop_table("oidc_login_attempts")
