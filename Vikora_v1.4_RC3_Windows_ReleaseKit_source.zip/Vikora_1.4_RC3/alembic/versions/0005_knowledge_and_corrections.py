"""Add reviewer-approved glossary and per-assessment corrections.
Revision ID: 0005_knowledge_and_corrections
Revises: 0004_oidc_web_sessions
"""
from alembic import op
import sqlalchemy as sa

revision = "0005_knowledge_and_corrections"
down_revision = "0004_oidc_web_sessions"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("knowledge_terms",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("vacancy_id", sa.Uuid(), sa.ForeignKey("vacancies.id", ondelete="CASCADE")),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("normalized_name", sa.String(120), nullable=False),
        sa.Column("aliases", sa.JSON(), nullable=False),
        sa.Column("explanation", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("vacancy_id", "normalized_name", name="uq_knowledge_scope_name"))
    op.create_index("ix_knowledge_terms_vacancy_id", "knowledge_terms", ["vacancy_id"])
    op.create_table("expert_corrections",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("evaluation_id", sa.Uuid(), sa.ForeignKey("evaluations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("criterion_key", sa.String(80), nullable=False),
        sa.Column("corrected_level", sa.String(25), nullable=False),
        sa.Column("note", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("evaluation_id", "criterion_key", name="uq_expert_eval_criterion"))
    op.create_index("ix_expert_corrections_evaluation_id", "expert_corrections", ["evaluation_id"])


def downgrade():
    op.drop_index("ix_expert_corrections_evaluation_id", table_name="expert_corrections")
    op.drop_table("expert_corrections")
    op.drop_index("ix_knowledge_terms_vacancy_id", table_name="knowledge_terms")
    op.drop_table("knowledge_terms")
