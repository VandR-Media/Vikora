"""Desktop: explicit read-only HeadHunter vacancy link.
Revision ID: 0006_hh_vacancy_link
Revises: 0005_knowledge_and_corrections
"""
from alembic import op
import sqlalchemy as sa
revision = '0006_hh_vacancy_link'
down_revision = '0005_knowledge_and_corrections'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('hh_vacancy_links',
        sa.Column('vacancy_id',sa.Uuid(),sa.ForeignKey('vacancies.id', ondelete='CASCADE'),primary_key=True),
        sa.Column('hh_vacancy_id',sa.String(40),nullable=False),
        sa.Column('linked_at',sa.DateTime(timezone=True),server_default=sa.func.now(),nullable=False))

def downgrade():
    op.drop_table('hh_vacancy_links')
