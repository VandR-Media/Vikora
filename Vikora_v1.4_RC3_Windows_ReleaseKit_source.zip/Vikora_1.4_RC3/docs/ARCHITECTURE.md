# Архитектура

Frontend: Next.js (внутренний домен) → API FastAPI → PostgreSQL.
Для пакетной обработки: FastAPI → очередь Redis/Celery → Parser → AI Provider → PostgreSQL.
Файлы — отдельное приватное S3-совместимое хранилище, с шифрованием и политикой удаления.
SSO по OIDC и проверка ролей на каждом API-эндпоинте до появления данных кандидатов.

Поток:
1. Recruiter создает вакансию и критерии в PostgreSQL.
2. PDF/DOCX кладется в приватное хранилище, в БД — метаданные. Очередь получает resume_id.
3. Парсер извлекает текст и координаты/страницы; проверяет тип, размер и сканирует файл.
4. AI получает только необходимые для оценки фрагменты, возвращает валидированный JSON.
5. Правила и AI-оценка сохраняются как неизменяемая версия с model_version, prompt_version и criteria_snapshot.
6. UI показывает объяснение и исходные выдержки; этап воронки меняет только человек.

Точки защиты:
- RBAC, служебные роли, least privilege.
- Сервисные секреты в секрет-хранилище; раздельные dev/prod базы.
- Снижение передачи PII стороннему LLM: редактирование контактов до запроса, договор о данных и проверка региона обработки.
- Удаление из S3, БД, поискового индекса и очереди по политике retention.
- Отказоустойчивость задач, retry с backoff, DLQ; rate limits к внешним интеграциям.

На шаге 1 функционируют API, Postgres, миграция и tests. Остальные блоки — план следующих шагов.

## Фактическая реализация на этапе v0.2 (по сравнению с целевой)

```text
recruiter (Swagger UI for prototype)
  -> FastAPI (OIDC RS256/JWKS or local dev Bearer)
       |-> PostgreSQL (vacancies, access, applications, resume metadata)
       |-> private shared upload volume (not public)
  -> worker polling PostgreSQL pending resumes
       |-> private upload volume
       |-> pypdf/python-docx parser
       |-> PostgreSQL (parse_status, parsed_fields.pages)
```

Независимый Redis/Celery, Next.js, S3 и внешний LLM **пока отсутствуют**. Локальная демонстрация использует dev-токены и отключённый malware scan (только синтетические документы). Строгий режим production требует OIDC и ClamAV, но полной готовности к production нет из-за retention, удаления, шифрования, sandbox и непротестированных интеграций.

Право видеть кандидата определяется доступом к *вакансии, указанной в URL*, после проверки принадлежности application/resume к ней. `admin` имеет доступ ко всем вакансиям, владелец — к своей, члены `vacancy_access` — по роли `editor`/`viewer`. Права на изменение ограничиваются ролью `recruiter` или `admin`.
