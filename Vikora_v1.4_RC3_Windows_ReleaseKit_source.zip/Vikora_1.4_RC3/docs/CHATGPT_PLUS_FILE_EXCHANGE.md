# ChatGPT Plus manual file exchange v1

Protocol: request `vikora-chatgpt-request` v1; response `vikora-chatgpt-result` v1. Both are UTF-8 JSON and **not encrypted**.

Request generation: choose 1–20 applications or exact application/resume pairs. Generate a random `exchange_id`, stable UUID references, vacancy/criteria, parsed resume pages, and a `source_hash` equal to SHA-256 of canonical JSON of `{vacancy, candidates}` (`ensure_ascii=False`, `sort_keys=True`, separators `(',', ':')`). Append Russian task instructions and sample response format.

Response: copy `exchange_id`, `vacancy_id`, `source_hash`, `selections`, and output `results` with exactly one `assessment.results` item per criterion and one candidate entry per selected resume. `match_level` is one of `met`, `partial`, `not_met`, `unknown`. Evidence is a page-number/excerpt pair; `unknown` must carry `[]`.

Import: parse strict JSON with duplicate-key and extra-field rejection. Reconstruct the source snapshot from the local DB using the selection IDs; verify unchanged vacancy text, criteria, resume SHA and parsed text by recomputing `source_hash`. Check all candidate and criterion counts, keys, evidence quotes and page references with existing `validate_grounding`. Reject previously imported exchange IDs or unchanged previous imported responses. Import all or none in one DB transaction. Store only an assessment; never change application stage.

Security: the resumes are untrusted input, and the prompt explicitly forbids following directives embedded inside them. Token/key not included in JSON. File size cap 4 MB incoming, 150k text chars outgoing. Manual confirmation before exporting. Remote ChatGPT sharing is not anonymous by default and has separate retention controls; require permission to transfer candidate data. No direct OpenAI API call.

Practical limitations: photos, scanned resumes without extracted text and embedded content are not exported. Hash detects accidental staleness, **not malicious edits** (it is not authenticated or signed). ChatGPT's evaluation is still subject to hallucinations and biased interpretations; verbatim-quote validation does not prove an inference correct. No automatic rejection/hiring. For production consider optional contact redaction, job-content minimization, signed exchange records if needed, and stronger audit/retention handling.
