# Структура БД, v0.1

| Таблица | Основные колонки | Связи/правила |
|---|---|---|
| user_accounts | id, email, full_name, role, sso_subject | email и sso_subject уникальные |
| vacancies | id, title, description, department, location, status, owner_id | owner_id → user_accounts |
| vacancy_criteria | id, vacancy_id, key, label, importance, weight, sort_order | vacancy_id → vacancies; уникальный (vacancy_id,key), weight 1..10 |
| candidates | id, full_name, email, phone, source, source_external_id, retention_until, deleted_at | отдельная сущность, кандидат может откликаться на много вакансий |
| resumes | id, candidate_id, storage_key, sha256, parse_status, parsed_fields | → candidates, файлы вне БД; уникальный (candidate_id,sha256) |
| applications | id, vacancy_id, candidate_id, stage, recruiter_id | → vacancies,candidates; уникальный (vacancy_id,candidate_id) |
| evaluations | id, application_id, resume_id, criteria_snapshot, status, overall_score, model_name, prompt_version, explanation | отдельный immutable запуск AI оценки |
| criterion_evaluations | id, evaluation_id, criterion_key, match_level, evidence, rationale | → evaluations; уникальный (evaluation_id,criterion_key) |
| audit_events | id, actor_id, action, entity_type, entity_id, details, created_at | история действий, без раскрытия полного PII в details |

Примечание: уже созданные оценки сохраняют свой критерий в snapshot при редактировании вакансии. Данные кандидатов и резюме не должны быть доступны до добавления SSO/RBAC. `overall_score` не является решением о найме.

## Важно перед production
- Версионирование критериев отдельными revision-таблицами или сохранение неизменяемой копии при каждой evaluation.
- Удаление кандидата: cascade для resumes/applications; связанные записи удаляются каскадно по FK; дополнительно необходимо удалить S3-объекты и обеспечить политику purge резервных копий. Реализовать и тестировать процедуру удаления атомарно.
- В продакшене контакты защищаются шифрованием и контролем доступа. Индекс email в этой заготовке предназначен лишь для тестового окружения и пересматривается после выбора стратегии шифрования/поиска.

## Добавление в v0.2 — миграция `0002_vacancy_access`

| Таблица | Колонки | Правило |
|---|---|---|
| vacancy_access | id, vacancy_id, user_id, role | уникальная пара (vacancy_id,user_id); role=editor/viewer |

Владелец вакансии определяется `vacancies.owner_id`, администратор видит все вакансии. Рекрутер может писать в собственную или явно предоставленную с ролью `editor` вакансию, а reviewer (`viewer`) только читать. Все API кандидатов и резюме вложены в путь с vacancy_id и проверяют права до чтения. Предыдущие записи вакансий с `owner_id=NULL` доступны только администраторам, пока им не будет назначен владелец.

Обработка резюме использует прежнюю таблицу `resumes`: `storage_key` — внутренний ключ в закрытом томе; `parsed_fields.pages` — массив объектов `{page, text}`. Поле `parse_status` меняется `pending -> processing -> parsed/failed`. Отдельная схема для истории парсинга и восстановления зависших задач понадобится в следующем релизе.
