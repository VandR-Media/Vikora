# Release notes v0.2

**Implemented:** OIDC-compatible JWT verification, dev CLI tokens, provisioned users, vacancy-scoped access, access grants, applicants, manual pipeline stages, PDF/DOCX upload, bounded file validation, ClamAV integration (not integration-tested), SHA256 duplicate check, offline parser worker, PDF/DOCX text extraction, audit on sensitive operations, revoke-access endpoint, disable-user CLI and no-store API headers.

**Schema:** added Alembic `0002_vacancy_access`, no modification to original `0001_initial`.

**Verified:** `PYTHONPATH=src pytest -q` (16 passed), SQLite Alembic upgrade from zero to head and `alembic check` clean, CLI create-user and dev-token. Docker/production not available for test.

**Still missing:** retention/delete, encrypted production object storage, sandboxed parsing, actual OIDC setup, actual antivirus deployment, AI scoring, UI, hh.ru integrations.
