"""Developer-only synthetic benchmark of Qwen. Needs Ollama already running."""
from __future__ import annotations
from app.services.quality_audit import read_synthetic_cases, evaluate_cases


def main() -> None:
    cases = read_synthetic_cases()
    report = evaluate_cases('ollama_local', cases)
    for row in report['results']:
        label = 'OK' if row['correctly_matched'] else 'REVIEW'
        print(f"{row['id']}: {label} expected={row['expected']} predicted={row['predicted']}")
    print(report['summary'])
    print('Synthetic-only check. Not validated hiring accuracy.')

if __name__ == '__main__':
    main()
