# HTTPS reverse proxy — deployment checklist (not installed by Docker Compose)

Vikora production never publishes API directly to the internet. `api` listens only
on `127.0.0.1:8000` on its Docker host. Deploy a managed HTTPS reverse proxy on
that host or behind a private VPN, and route `https://vikora.internal.example`
to `http://127.0.0.1:8000`.

Mandatory proxy settings:

- Provide TLS (managed cert with trusted CA). No direct internet access to port 8000.
- Only forward for the exact expected Host; do not use a wildcard virtual host.
- Disable access logging of `/api/v1/auth/callback` query strings: authorization codes are in URLs.
- Enforce size/rate limits on upload endpoints and rate-limit `/api/v1/auth/login`.
- Do not forward untrusted `X-Forwarded-*` headers from clients.
- `PUBLIC_ORIGIN` must exactly equal the HTTPS origin visible to browsers.
- Set security headers and access logging policies at the perimeter. The app sets
  HSTS and basic CSP internally but is not itself a TLS listener.
- Restrict to trusted corporate networks/users, keep database and scanner private.

This is an operator checklist, **not** an end-to-end configured secure deployment.
