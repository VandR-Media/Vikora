#define MyAppName "Vikora"
#define MyAppVersion "1.4.0-rc3"
#define MyAppExe "Vikora.exe"
[Setup]
AppId={{A1C6CC29-2FF3-4925-8AB3-7F8BD2DFB6CF}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={localappdata}\Programs\Vikora
DefaultGroupName=Vikora
PrivilegesRequired=lowest
OutputDir=..\dist\installer
OutputBaseFilename=Vikora_Setup_{#MyAppVersion}
Compression=lzma
SolidCompression=yes
UninstallDisplayIcon={app}\{#MyAppExe}
CloseApplications=yes
RestartApplications=no
[Tasks]
Name: "desktopicon"; Description: "Создать ярлык Vikora на рабочем столе"; GroupDescription: "Значки:"
[Files]
Source: "..\dist\Vikora\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\Vikora"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\Vikora"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon
[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Открыть Vikora"; Flags: nowait postinstall skipifsilent
; Local candidate data lives separately in %LOCALAPPDATA%\Vikora.
; Uninstallation deliberately does NOT erase that data, avoiding accidental loss.
