# Build on 64-bit Windows, not Linux. PowerShell 5.1 and later are supported.
# Example: powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1 -RequireInstaller
param([switch]$RequireInstaller)
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)

# Refuse to build incomplete or inconsistently versioned sources.
python packaging/verify_release_sources.py
if ($LASTEXITCODE -ne 0) { throw 'Vikora release source checks failed' }

if (-not $IsWindows -and $PSVersionTable.PSEdition -eq 'Core') {
    throw 'Build Vikora.exe only on Windows.'
}

if (-not (Test-Path '.builder\Scripts\python.exe')) {
    py -3.11 -m venv .builder
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 is required for Windows build' }
}
$python = (Resolve-Path '.builder\Scripts\python.exe').Path
& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Unable to install pip' }
& $python -m pip install -e '.[dev]' 'pyinstaller>=6.12,<7'
if ($LASTEXITCODE -ne 0) { throw 'Unable to install build dependencies' }

& $python -m PyInstaller --noconfirm --clean --onedir --windowed --name Vikora `
    --paths src --collect-data app --collect-submodules app --collect-submodules uvicorn `
    --collect-submodules keyring windows_entry.py
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed' }
$exe = Join-Path (Get-Location) 'dist\Vikora\Vikora.exe'
if (-not (Test-Path $exe)) { throw 'Windows executable missing after build' }
Write-Host "Executable built: $exe"

$compilerCandidates = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles}\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles}\Inno Setup 7\ISCC.exe"
)
$compiler = $compilerCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $compiler) {
    if ($RequireInstaller) { throw 'Inno Setup 6/7 not installed: installer is required' }
    Write-Warning 'No Inno Setup compiler: only the unpacked executable folder was built.'
    exit 0
}
& $compiler packaging\Vikora.iss
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup installer build failed' }
$installers = @(Get-ChildItem 'dist\installer\Vikora_Setup_*.exe' -ErrorAction SilentlyContinue)
if ($installers.Count -ne 1) { throw 'Expected exactly one Windows setup EXE' }
Write-Host "Installer built: $($installers[0].FullName)"
