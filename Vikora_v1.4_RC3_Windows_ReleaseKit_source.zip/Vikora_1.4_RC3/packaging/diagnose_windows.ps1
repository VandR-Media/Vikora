# Read-only technical preflight for one user's Windows laptop.
# Does not read resumes, API keys, browser data or Vikora's SQLite records.
# No internet connection, installations or configuration changes.
$ErrorActionPreference = 'Stop'
$lines = New-Object 'System.Collections.Generic.List[string]'
function Add-Row([string]$name, [string]$value) {
    $lines.Add(('{0}: {1}' -f $name, $value))
}
function Safe-Check([scriptblock]$check) {
    try { return [string](& $check) } catch { return 'Не удалось проверить' }
}

$lines.Add('VIKORA — ПРОВЕРКА СОВМЕСТИМОСТИ НОУТБУКА')
$lines.Add('Отчёт содержит только технические параметры; не содержит резюме и паролей.')
$lines.Add('')
Add-Row 'Дата проверки' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Add-Row 'Windows' (Safe-Check {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    '{0}, версия {1}, разрядность {2}' -f $os.Caption, $os.Version, $os.OSArchitecture
})
Add-Row 'Процессор' (Safe-Check {
    (Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1 -ExpandProperty Name).Trim()
})
Add-Row 'Оперативная память' (Safe-Check {
    $memory = (Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory
    '{0:N1} ГБ' -f ($memory / 1GB)
})
Add-Row 'Свободное место на системном диске' (Safe-Check {
    $drive = [System.IO.Path]::GetPathRoot($env:LOCALAPPDATA)
    $disk = Get-CimInstance -ClassName Win32_LogicalDisk -Filter ("DeviceID='{0}'" -f $drive.TrimEnd('\'))
    if ($null -eq $disk) { return 'Диск не определён' }
    '{0:N1} ГБ' -f ($disk.FreeSpace / 1GB)
})
Add-Row 'Windows Defender' (Safe-Check {
    $defender = Get-MpComputerStatus -ErrorAction Stop
    if ($defender.AntivirusEnabled -and $defender.AMServiceEnabled -and $defender.RealTimeProtectionEnabled) {
        'Включён (антивирус, служба и постоянная защита)'
    } else {
        'НЕ ВСЕ КОМПОНЕНТЫ ВКЛЮЧЕНЫ: нужна проверка перед загрузкой PDF/DOCX'
    }
})
Add-Row 'Ollama на компьютере' (Safe-Check {
    if (Get-Command 'ollama.exe' -ErrorAction SilentlyContinue) { 'Обнаружена команда Ollama (саму модель нужно проверить отдельно)' }
    else { 'Не обнаружена (для файлового обмена с ChatGPT не требуется)' }
})
Add-Row 'Локальный порт Vikora 18467' (Safe-Check {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $result = $client.BeginConnect('127.0.0.1', 18467, $null, $null)
        if ($result.AsyncWaitHandle.WaitOne(350)) {
            try { $client.EndConnect($result); return 'Занят (возможно, Vikora уже запущена)' }
            catch { return 'Свободен' }
        }
        return 'Вероятно свободен'
    } finally { $client.Dispose() }
})
Add-Row 'Папка данных Vikora' (Safe-Check {
    if (Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA 'Vikora')) { 'Уже существует, содержимое НЕ проверялось' }
    else { 'Будет создана при первом запуске' }
})
$lines.Add('')
$lines.Add('Важно: даже хороший отчёт НЕ заменяет испытаний установщика и нейросетей на Windows 11.')
$lines.Add('Не публикуйте отчёт открыто: в нём указаны технические характеристики вашего устройства.')
$desktop = [Environment]::GetFolderPath('Desktop')
if (-not $desktop -or -not (Test-Path -LiteralPath $desktop)) { $desktop = $env:TEMP }
$file = Join-Path $desktop ('Vikora_проверка_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
[System.IO.File]::WriteAllLines($file, $lines, (New-Object System.Text.UTF8Encoding($true)))
Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $file + '"')
Write-Host ('Готово. Отчёт сохранён: ' + $file)
