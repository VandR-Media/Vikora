"""Release-source checks before attempting the real Windows installer build.

Runs on Linux or Windows; this does NOT claim the Windows executable works.
"""
from __future__ import annotations
from pathlib import Path
import re
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    project = tomllib.loads((ROOT / 'pyproject.toml').read_text(encoding='utf-8'))
    pep_version = project['project']['version']
    display_version = pep_version.replace('rc', '-rc')
    app_py = (ROOT / 'src/app/main.py').read_text(encoding='utf-8')
    installer = (ROOT / 'packaging/Vikora.iss').read_text(encoding='utf-8-sig')
    versions = {
        'python package': pep_version,
        'FastAPI': re.search(r'FastAPI\(title=settings\.app_name, version="([^"]+)"', app_py),
        'Windows installer': re.search(r'#define MyAppVersion "([^"]+)"', installer),
    }
    for component, result in versions.items():
        actual = result if isinstance(result, str) else (result.group(1) if result else '<missing>')
        expected = pep_version if component == 'python package' else display_version
        if actual != expected:
            raise AssertionError(f'{component} version mismatch: {actual!r} vs {expected!r}')

    required = [
        'windows_entry.py', 'src/app/local_runner.py',
        'src/app/web/index.html', 'src/app/web/assets/app.js',
        'src/app/web/assets/styles.css', 'src/app/quality_cases_v14.json',
        'packaging/windows_smoke.py', 'packaging/test_installer_windows.ps1',
        'packaging/build_windows.ps1', 'packaging/Vikora.iss',
        'packaging/diagnose_windows.ps1', 'Vikora_ПРОВЕРКА_НОУТБУКА.cmd',
        '.github/workflows/windows-installer.yml',
    ]
    for rel in required:
        path = ROOT / rel
        if not path.is_file() or not path.stat().st_size:
            raise AssertionError(f'Missing or empty release resource: {rel}')
    workflow = (ROOT / '.github/workflows/windows-installer.yml').read_text(encoding='utf-8')
    for word in ('windows-2022', 'test_installer_windows.ps1', 'windows_smoke.py',
                 'SHA256SUMS.txt', 'upload-artifact'):
        if word not in workflow:
            raise AssertionError(f'Windows CI workflow is missing: {word}')
    build_script = (ROOT / 'packaging/build_windows.ps1').read_text(encoding='utf-8')
    for word in ('--onedir', '--windowed', '--collect-data app', '-RequireInstaller'):
        if word not in build_script:
            raise AssertionError(f'Windows build does not declare {word}')
    # Also check the human-visible version file to avoid giving a wrong download label.
    version_file = (ROOT / 'VERSION.txt').read_text(encoding='utf-8')
    if '1.4.0 RC3' not in version_file:
        raise AssertionError('VERSION.txt must name RC3, not a previous installer')
    if (ROOT / '.env').exists():
        raise AssertionError('An actual .env file must not be packaged in Vikora')
    print(f'PASS: Vikora {display_version} release sources and Windows scripts are consistent')
    print('NOTE: this is NOT a Windows .exe execution or installation test')
    return 0


if __name__ == '__main__':
    sys.exit(main())
