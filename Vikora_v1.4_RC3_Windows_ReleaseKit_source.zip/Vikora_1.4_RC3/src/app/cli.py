"""Operator-only commands; no public user-registration/token-issuance endpoint."""
import argparse
from datetime import datetime, timedelta, timezone

import jwt
from sqlalchemy import select

from app.core.config import settings
from app.db import SessionLocal
from app.models import UserAccount


def main():
    parser = argparse.ArgumentParser(description="Vikora administration")
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("create-user", help="Provision an allowed IdP subject")
    create.add_argument("--email", required=True)
    create.add_argument("--name", required=True)
    create.add_argument("--subject", required=True)
    create.add_argument("--role", choices=["admin", "recruiter", "reviewer"], default="recruiter")
    disable = sub.add_parser("disable-user", help="Immediately revoke a provisioned user at database level")
    disable.add_argument("--subject", required=True)
    token = sub.add_parser("dev-token", help="Generate temporary local development token")
    token.add_argument("--subject", required=True)
    args = parser.parse_args()

    if args.command == "create-user":
        with SessionLocal.begin() as db:
            existing = db.scalar(select(UserAccount).where(UserAccount.sso_subject == args.subject))
            if existing is not None:
                raise SystemExit("Subject is already provisioned; refusing to overwrite")
            if db.scalar(select(UserAccount).where(UserAccount.email == args.email)):
                raise SystemExit("Email is already registered")
            db.add(UserAccount(email=args.email, full_name=args.name, sso_subject=args.subject, role=args.role))
        print("Provisioned:", args.subject, args.role)
    elif args.command == "disable-user":
        with SessionLocal.begin() as db:
            existing = db.scalar(select(UserAccount).where(UserAccount.sso_subject == args.subject))
            if existing is None:
                raise SystemExit("User not found")
            existing.is_active = False
        print("Disabled:", args.subject)
    elif args.command == "dev-token":
        if settings.auth_mode != "dev" or settings.app_env != "development":
            raise SystemExit("dev-token is only available in local development")
        with SessionLocal() as db:
            user = db.scalar(select(UserAccount).where(UserAccount.sso_subject == args.subject))
            if user is None or not user.is_active:
                raise SystemExit("Subject is not an active provisioned user")
        now = datetime.now(timezone.utc)
        value = jwt.encode({"iss": "internal-ai-recruiter-dev", "aud": "internal-ai-recruiter-api",
                            "sub": args.subject, "iat": now, "exp": now + timedelta(minutes=60)},
                           settings.dev_auth_secret, algorithm="HS256")
        print(value)


if __name__ == "__main__":
    main()
