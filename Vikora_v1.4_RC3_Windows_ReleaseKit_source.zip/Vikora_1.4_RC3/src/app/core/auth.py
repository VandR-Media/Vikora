"""Validate bearer tokens and resolve only pre-provisioned, active users.

Never authorize roles or access solely from a token claim. The DB is authoritative.
"""
import uuid
import secrets

import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db import get_db
from app.models import UserAccount
from app.core.web_sessions import protect_cookie_write, session_from_request

bearer = HTTPBearer(auto_error=False)
_jwks_client: jwt.PyJWKClient | None = None


def _decode_token(token: str) -> dict:
    global _jwks_client
    try:
        if settings.auth_mode == "dev":
            return jwt.decode(
                token,
                settings.dev_auth_secret,
                algorithms=["HS256"],
                issuer="internal-ai-recruiter-dev",
                audience="internal-ai-recruiter-api",
                options={"require": ["sub", "exp", "iat", "iss", "aud"]},
                leeway=30,
            )
        if _jwks_client is None:
            _jwks_client = jwt.PyJWKClient(settings.oidc_jwks_url, cache_keys=True)
        signing_key = _jwks_client.get_signing_key_from_jwt(token)
        return jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=settings.oidc_issuer,
            audience=settings.oidc_audience,
            options={"require": ["sub", "exp", "iat", "iss", "aud"]},
            leeway=30,
        )
    except (jwt.PyJWTError, ValueError, OSError) as exc:
        raise HTTPException(status_code=401, detail="Invalid or expired bearer token", headers={"WWW-Authenticate": "Bearer"}) from exc


def current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    db: Session = Depends(get_db),
) -> UserAccount:
    if credentials is None:
        session_data = session_from_request(request, db) if settings.auth_mode == "oidc" else None
        if session_data is not None:
            _session, user, raw_cookie = session_data
            protect_cookie_write(request, raw_cookie)
            return user
        raise HTTPException(status_code=401, detail="Authentication required", headers={"WWW-Authenticate": "Bearer"})
    if credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Bearer token required", headers={"WWW-Authenticate": "Bearer"})
    if settings.auth_mode == "local":
        # Access is limited to the current Windows session. One strong temporary
        # token is passed to the launched browser tab and kept only in sessionStorage.
        if not secrets.compare_digest(credentials.credentials, settings.vikora_local_token):
            raise HTTPException(status_code=401, detail="Local access token is invalid")
        user = db.scalar(select(UserAccount).where(UserAccount.sso_subject == "vikora-local-owner"))
        if user is None or not user.is_active or user.role != "admin":
            raise HTTPException(status_code=503, detail="Vikora local profile is not initialized")
        return user
    claims = _decode_token(credentials.credentials)
    subject = claims.get("sub")
    if not isinstance(subject, str) or not subject.strip() or len(subject) > 255:
        raise HTTPException(status_code=401, detail="Invalid subject")
    user = db.scalar(select(UserAccount).where(UserAccount.sso_subject == subject))
    if user is None or not user.is_active:
        raise HTTPException(status_code=403, detail="User has not been provisioned or is disabled")
    return user
