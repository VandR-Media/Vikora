from typing import Literal
from urllib.parse import urlsplit

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Vikora API"
    app_env: Literal["development", "production", "desktop"] = "development"
    database_url: str = "sqlite:///./recruiter_dev.db"
    auth_mode: Literal["dev", "oidc", "local"] = "oidc"
    dev_auth_secret: str = ""
    # Ephemeral secret generated anew each time the laptop app starts. Never persist it.
    vikora_local_token: str = ""
    oidc_issuer: str = ""
    oidc_audience: str = ""
    oidc_jwks_url: str = ""
    # Browser-side SSO uses OIDC Authorization Code + PKCE. Bearer API token audience
    # above is intentionally separate from the browser OIDC client ID.
    oidc_client_id: str = ""
    oidc_client_secret: str = ""
    oidc_authorize_url: str = ""
    oidc_token_url: str = ""
    oidc_redirect_uri: str = ""
    public_origin: str = ""
    session_hours: int = Field(default=8, ge=1, le=12)
    upload_dir: str = "./private_uploads"
    # New records get a deadline; legacy NULL deadlines require human review.
    default_retention_days: int = Field(default=180, ge=1, le=730)
    max_retention_days: int = Field(default=730, ge=1, le=3650)
    max_upload_bytes: int = Field(default=10 * 1024 * 1024, ge=1024, le=50 * 1024 * 1024)
    malware_scan_mode: Literal["disabled", "clamav", "windows_defender"] = "clamav"
    clamav_host: str = "clamav"
    clamav_port: int = 3310
    # Local baseline is an exact phrase matcher, NOT a model. No network egress.
    ai_provider: Literal["heuristic", "ollama_local", "openai_api", "deepseek_api", "gigachat_api", "alice_api", "openai_compatible", "disabled"] = "heuristic"
    ai_endpoint: str = ""
    ai_model: str = ""
    ai_api_key: str = ""
    ai_allow_resume_transmission: bool = False
    ai_request_timeout: int = Field(default=60, ge=5, le=180)

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @staticmethod
    def _valid_url(value: str, *, https: bool, origin: bool = False) -> bool:
        try:
            parts = urlsplit(value)
            if parts.username or parts.password or parts.query or parts.fragment or not parts.hostname:
                return False
            if parts.scheme not in ({"https"} if https else {"https", "http"}):
                return False
            if parts.scheme == "http" and parts.hostname not in {"localhost", "127.0.0.1"}:
                return False
            if origin and (parts.path not in {"", "/"} or value.endswith("/")):
                return False
            return True
        except ValueError:
            return False

    @model_validator(mode="after")
    def check_security_settings(self):
        if self.default_retention_days > self.max_retention_days:
            raise ValueError("Default retention cannot exceed maximum retention")
        if self.auth_mode == "dev":
            if self.app_env != "development":
                raise ValueError("Development tokens are forbidden in production")
            if len(self.dev_auth_secret) < 32 or self.dev_auth_secret.startswith("REPLACE_"):
                raise ValueError("DEV_AUTH_SECRET must contain at least 32 characters")
        elif self.auth_mode == "local":
            if self.app_env != "desktop":
                raise ValueError("Local single-user mode requires APP_ENV=desktop")
            if len(self.vikora_local_token) < 40:
                raise ValueError("VIKORA_LOCAL_TOKEN must be a random temporary secret")
            if not self.database_url.startswith("sqlite:"):
                raise ValueError("Desktop mode supports only local SQLite")
        else:
            if not all([self.oidc_issuer, self.oidc_audience, self.oidc_jwks_url]):
                raise ValueError("OIDC_ISSUER, OIDC_AUDIENCE, OIDC_JWKS_URL are required")
            for name in ("oidc_jwks_url", "oidc_issuer", "oidc_authorize_url", "oidc_token_url"):
                address = getattr(self, name)
                if not address or not self._valid_url(address, https=True):
                    raise ValueError(f"{name.upper()} must be a valid HTTPS URL without credentials, query or fragment")
            if not self.oidc_client_id or not self.oidc_redirect_uri or not self.public_origin:
                raise ValueError("OIDC_CLIENT_ID, OIDC_REDIRECT_URI and PUBLIC_ORIGIN required in OIDC mode")
            allow_http_local = self.app_env == "development"
            if not self._valid_url(self.public_origin, https=not allow_http_local, origin=True):
                raise ValueError("PUBLIC_ORIGIN must be a valid HTTPS origin (localhost HTTP allowed only in development)")
            if not self._valid_url(self.oidc_redirect_uri, https=not allow_http_local):
                raise ValueError("OIDC_REDIRECT_URI must be HTTPS (localhost HTTP allowed only in development)")
            if self.oidc_redirect_uri != self.public_origin.rstrip("/") + "/api/v1/auth/callback":
                raise ValueError("OIDC_REDIRECT_URI must match PUBLIC_ORIGIN plus /api/v1/auth/callback")
        if self.app_env == "desktop" and self.auth_mode != "local":
            raise ValueError("Desktop mode requires local single-user authentication")
        if self.app_env == "production" and not self.database_url.startswith("postgresql+"):
            raise ValueError("Production requires a PostgreSQL database")
        if self.app_env == "production" and self.malware_scan_mode != "clamav":
            raise ValueError("Malware scanning cannot be disabled in production")
        if self.app_env == "production" and self.auth_mode != "oidc":
            raise ValueError("Production requires corporate OIDC")
        if self.ai_provider == "openai_compatible":
            url = urlsplit(self.ai_endpoint)
            if not self.ai_model.strip() or not url.hostname or url.username or url.password or url.query or url.fragment:
                raise ValueError("AI_MODEL and a valid AI_ENDPOINT are required")
            if url.scheme != "https":
                dev_hosts = {"localhost", "127.0.0.1", "host.docker.internal", "ollama"}
                if self.app_env != "development" or url.scheme != "http" or url.hostname not in dev_hosts:
                    raise ValueError("AI_ENDPOINT must use HTTPS except local development models")
        return self


settings = Settings()
