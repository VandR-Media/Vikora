import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import UserAccount, Vacancy, VacancyAccess


def require_vacancy(db: Session, vacancy_id: uuid.UUID, user: UserAccount, *, edit: bool = False, manage: bool = False) -> Vacancy:
    vacancy = db.get(Vacancy, vacancy_id)
    if vacancy is None:
        raise HTTPException(status_code=404, detail="Vacancy not found")
    if user.role == "admin":
        return vacancy
    if vacancy.owner_id == user.id:
        return vacancy
    membership = db.scalar(select(VacancyAccess).where(
        VacancyAccess.vacancy_id == vacancy_id, VacancyAccess.user_id == user.id,
    ))
    if membership and not manage and (not edit or (membership.role == "editor" and user.role == "recruiter")):
        return vacancy
    # Do not disclose whether a restricted vacancy exists.
    raise HTTPException(status_code=404, detail="Vacancy not found")


def require_editor(user: UserAccount) -> None:
    if user.role not in {"admin", "recruiter"}:
        raise HTTPException(status_code=403, detail="Editing requires recruiter permissions")
