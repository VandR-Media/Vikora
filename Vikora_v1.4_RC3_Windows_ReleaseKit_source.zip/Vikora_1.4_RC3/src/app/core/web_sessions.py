"""Opaque cookie sessions, same-origin CSRF protection, and session revocation."""
import hashlib
import hmac
from datetime import datetime, timezone

from fastapi import HTTPException, Request
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import UserAccount, WebSession


def digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def utc(value: datetime) -> datetime:
    # sqlite returns naive datetimes while PostgreSQL returns UTC-aware ones.
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def cookie_name() -> str:
    return "__Host-vikora" if settings.app_env == "production" else "vikora_dev_session"


def login_cookie_name() -> str:
    return "__Host-vikora-login" if settings.app_env == "production" else "vikora_dev_login"


def session_from_request(request: Request, db: Session) -> tuple[WebSession, UserAccount, str] | None:
    raw = request.cookies.get(cookie_name())
    if not raw or len(raw) > 200:
        return None
    session = db.get(WebSession, digest(raw))
    if session is None or session.revoked_at is not None or utc(session.expires_at) <= datetime.now(timezone.utc):
        return None
    user = db.get(UserAccount, session.user_id)
    if user is None or not user.is_active:
        return None
    return session, user, raw


def csrf_for_cookie(raw: str) -> str:
    # Domain separation from the cookie's database hash. Never expose the raw cookie to JS.
    return digest("vikora.csrf.v1:" + raw)


def protect_cookie_write(request: Request, raw: str) -> None:
    if request.method in {"GET", "HEAD", "OPTIONS"}:
        return
    supplied = request.headers.get("X-CSRF-Token", "")
    if not hmac.compare_digest(supplied, csrf_for_cookie(raw)):
        raise HTTPException(403, "Invalid CSRF token")
    origin = request.headers.get("Origin")
    if origin and settings.public_origin and origin != settings.public_origin:
        raise HTTPException(403, "Invalid request origin")
