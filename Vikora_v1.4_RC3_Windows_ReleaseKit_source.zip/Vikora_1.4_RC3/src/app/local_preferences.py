"""Local desktop AI switch. Intentionally importable before Settings are initialized."""
from __future__ import annotations
import json
import os
from pathlib import Path
from app.local_runtime import data_directory

MODEL_TAG = "qwen3:4b"
OPENAI_MODEL_TAG = "gpt-5.4-mini"
CLOUD_MODEL_TAGS = {'deepseek_api': 'deepseek-flash', 'gigachat_api': 'GigaChat', 'alice_api': 'aliceai-llm'}
CONFIG_FILE = "ai_preferences.json"

def preference_path() -> Path:
    return data_directory() / CONFIG_FILE


def read_ai_preference() -> str:
    """Failure-safe: invalid/missing config cannot enable the model."""
    try:
        path = preference_path()
        if path.stat().st_size > 1024:
            return "heuristic"
        data = json.loads(path.read_text(encoding="utf-8"))
        if data == {"mode": "ollama_local", "model": MODEL_TAG}:
            return "ollama_local"
        if data == {"mode": "openai_api", "model": OPENAI_MODEL_TAG}:
            return "openai_api"
        for mode, model in CLOUD_MODEL_TAGS.items():
            if data == {"mode": mode, "model": model}:
                return mode
    except (OSError, ValueError, TypeError):
        pass
    return "heuristic"


def save_ai_preference(mode: str) -> None:
    if mode not in {"heuristic", "ollama_local", "openai_api", *CLOUD_MODEL_TAGS}:
        raise ValueError("Unsupported AI mode")
    path = preference_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    try:
        with temp.open("w", encoding="utf-8") as file:
            json.dump({"mode": mode, "model": OPENAI_MODEL_TAG if mode == "openai_api" else CLOUD_MODEL_TAGS.get(mode, MODEL_TAG)}, file)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


