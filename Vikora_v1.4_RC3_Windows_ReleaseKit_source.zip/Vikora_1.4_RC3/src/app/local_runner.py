"""Windows EXE entry point or `python -m app.local_runner` for development.

Internal FastAPI runs ONLY on 127.0.0.1. Browser UI is bundled in the EXE.
The laptop needs no PostgreSQL, Docker, hosted server or cloud AI account.
"""
from __future__ import annotations
import logging
import os
import secrets
import socket
import sys
from pathlib import Path
import webbrowser
from threading import Thread
import time


def configure_desktop() -> tuple[str, Path]:
    from app.local_runtime import data_directory
    root = data_directory()
    root.mkdir(parents=True, exist_ok=True)
    (root / "files").mkdir(exist_ok=True)
    # Set environment values before importing app.core.config / app.db.
    from app.local_preferences import read_ai_preference, MODEL_TAG, OPENAI_MODEL_TAG, CLOUD_MODEL_TAGS
    preferred_mode = read_ai_preference()
    os.environ.update({
        "APP_ENV": "desktop", "AUTH_MODE": "local",
        "VIKORA_LOCAL_TOKEN": secrets.token_urlsafe(48),
        "DATABASE_URL": "sqlite:///" + (root / "vikora.sqlite3").as_posix(),
        "UPLOAD_DIR": str(root / "files"),
        "MALWARE_SCAN_MODE": "windows_defender" if os.name == "nt" else "disabled",
        "AI_PROVIDER": preferred_mode,  # local AI only after explicit opt-in in the app
        "AI_ALLOW_RESUME_TRANSMISSION": "false",
        "AI_MODEL": (MODEL_TAG if preferred_mode == "ollama_local" else OPENAI_MODEL_TAG if preferred_mode == "openai_api" else CLOUD_MODEL_TAGS.get(preferred_mode, "")),
    })
    return os.environ["VIKORA_LOCAL_TOKEN"], root



def open_browser_when_ready(server, port: int, token: str, *, max_wait: float = 90.0) -> bool:
    """Open the local UI only after Uvicorn reports it has started.

    A frozen Windows executable can take longer than one second to initialize,
    especially during the first Windows Defender check. Starting the browser
    before startup could show an alarming connection error to a nontechnical user.
    The access token remains in a URL fragment, not an HTTP request.
    """
    deadline = time.monotonic() + max_wait
    while time.monotonic() < deadline:
        if getattr(server, "should_exit", False):
            return False
        if getattr(server, "started", False):
            webbrowser.open(f"http://127.0.0.1:{port}/app#vikora={token}")
            return True
        time.sleep(0.2)
    return False


def main() -> None:
    try:
        token, root = configure_desktop()
        from app.local_runtime import SingleInstanceLock, prepare_local_database, set_shutdown
        with SingleInstanceLock(root / "vikora.lock"):
            logging.basicConfig(
                filename=str(root / "vikora.log"), level=logging.WARNING,
                format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                encoding="utf-8",
            )
            prepare_local_database()
            import uvicorn
            from app.main import app
            # Only the current computer can connect; 127.0.0.1 is not an
            # externally reachable server address.
            port = int(os.getenv("VIKORA_DESKTOP_PORT", "18467"))
            if not 1024 <= port <= 65535:
                raise ValueError("Invalid local port")
            with socket.socket() as probe:
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    probe.bind(("127.0.0.1", port))
                except OSError as exc:
                    raise RuntimeError("Локальный порт Vikora занят другой программой. "
                                       "Закройте её и попробуйте снова.") from exc
            server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port,
                                                   log_level="warning", access_log=False))
            set_shutdown(lambda: setattr(server, "should_exit", True))
            if os.getenv("VIKORA_NO_BROWSER") != "1":
                # Wait for application startup, which may be slower on Windows.
                # Fragment is not sent in HTTP; the UI clears it immediately.
                Thread(target=open_browser_when_ready, args=(server, port, token),
                       daemon=True, name="vikora-open-browser").start()
            server.run()
            from app.local_runtime import take_restore, workers_stopped
            pending = take_restore()
            if pending is not None:
                if not workers_stopped():
                    raise RuntimeError("Невозможно безопасно восстановить данные: фоновые задачи ещё работают. Текущие данные сохранены.")
                source, password = pending
                try:
                    # Ensure SQLite connections are closed before replacing DB files.
                    from app.db import engine
                    engine.dispose()
                    from app.services.backup import restore_offline
                    details = restore_offline(root, source, password)
                    msg = ("Данные Vikora восстановлены.\n\n"
                           "Закройте старую вкладку и запустите Vikora через ярлык ещё раз.\n\n"
                           "Зашифрованная страховочная копия прежних данных сохранена в:\n"
                           + details["emergency_backup"])
                    if os.name == "nt":
                        import ctypes
                        ctypes.windll.user32.MessageBoxW(None, msg, "Vikora — восстановление завершено", 0x40)
                    else:
                        print(msg)
                finally:
                    source.unlink(missing_ok=True)
    except Exception as exc:
        # Windows onefile/onefolder builds run without a console. Explain the
        # problem to the user instead of crashing without visible feedback.
        message = "Не удалось запустить Vikora.\n\n" + str(exc) + "\n\nПопробуйте закрыть ранее открытые окна Vikora."
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, "Vikora — ошибка запуска", 0x10)
        else:
            print(message, file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
