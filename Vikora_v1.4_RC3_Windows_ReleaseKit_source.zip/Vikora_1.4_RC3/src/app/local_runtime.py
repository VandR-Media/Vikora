"""Single-user local runtime. No cloud service and no external network listener.

The random access credential exists only for one application run. Data lives in
Windows LocalAppData rather than beside an EXE (which may be read-only).
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
import sys
import threading
import time
from typing import Callable

from sqlalchemy import update, select

LOCAL_SUBJECT = "vikora-local-owner"
_shutdown: Callable[[], None] | None = None
_pending_restore: tuple[Path, str] | None = None
_workers_stopped: bool = True


def data_directory() -> Path:
    if os.getenv("VIKORA_DATA_DIR"):
        return Path(os.environ["VIKORA_DATA_DIR"]).expanduser().resolve()
    if os.name == "nt":
        base = os.getenv("LOCALAPPDATA")
        if not base:
            base = str(Path.home() / "AppData" / "Local")
        return (Path(base) / "Vikora").resolve()
    return (Path.home() / ".local" / "share" / "Vikora").resolve()



def check_existing_sqlite(path: Path) -> None:
    """Refuse a broken or unrelated database BEFORE create_all can touch it.

    For a clean installation no database exists, so schema creation proceeds.
    This is a safety check, not an automated migration or a backup.
    """
    if not path.exists() and not path.is_symlink():
        return
    if path.is_symlink() or not path.is_file():
        raise RuntimeError("Файл базы данных Vikora имеет недопустимый тип. Данные не изменены.")
    try:
        uri = path.resolve().as_uri() + "?mode=ro"
        with sqlite3.connect(uri, uri=True, timeout=5) as connection:
            result = connection.execute("PRAGMA quick_check").fetchone()
            if result != ("ok",):
                raise RuntimeError("База Vikora повреждена. Запуск остановлен, чтобы сохранить данные.")
            rows = {item[0] for item in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if "user_accounts" not in rows:
                raise RuntimeError("Обнаружена неизвестная база данных. Vikora не будет её изменять.")
    except sqlite3.DatabaseError as exc:
        raise RuntimeError("Не удалось проверить базу Vikora. Данные не изменены.") from exc


def prepare_local_database() -> None:
    """Create a *new* local DB, or reuse an existing compatible DB.

    Existing business records are never deleted. Database migrations are a
    separate step when the schema changes in a future release.
    """
    from app import models  # noqa: F401 (register ORM models)
    from app.db import Base, SessionLocal, engine
    from app.models import UserAccount
    data_directory().mkdir(parents=True, exist_ok=True)
    check_existing_sqlite(data_directory() / "vikora.sqlite3")
    Base.metadata.create_all(engine)
    with engine.begin() as db:
        if engine.dialect.name == "sqlite":
            db.exec_driver_sql("PRAGMA journal_mode=WAL")
    with SessionLocal.begin() as session:
        local_user = session.scalar(select(UserAccount).where(UserAccount.sso_subject == LOCAL_SUBJECT))
        if local_user is None:
            session.add(UserAccount(
                sso_subject=LOCAL_SUBJECT,
                email="owner@vikora.local.invalid", full_name="Владелец Vikora",
                role="admin", is_active=True,
            ))
        else:
            local_user.role = "admin"
            local_user.is_active = True


def requeue_after_interrupted_shutdown() -> tuple[int, int]:
    """One-process desktop mode recovers tasks left in 'processing' by a crash.

    Caller must hold the single-instance lock before this operation.
    """
    from app.db import SessionLocal
    from app.models import Evaluation, Resume
    with SessionLocal.begin() as db:
        resumed = db.execute(update(Resume).where(Resume.parse_status == "processing")
                             .values(parse_status="pending")).rowcount
        evaluations = db.execute(update(Evaluation).where(Evaluation.status == "processing")
                                 .values(status="pending")).rowcount
    return resumed, evaluations


def set_workers_stopped(value: bool) -> None:
    global _workers_stopped
    _workers_stopped = value


def workers_stopped() -> bool:
    return _workers_stopped


def schedule_restore(encrypted_file: Path, password: str) -> None:
    """Password remains only in this process, never in a queue file."""
    global _pending_restore
    if _pending_restore is not None:
        raise ValueError("Восстановление уже запланировано")
    _pending_restore = (encrypted_file, password)


def cancel_restore() -> None:
    global _pending_restore
    _pending_restore = None


def take_restore() -> tuple[Path, str] | None:
    global _pending_restore
    result = _pending_restore
    _pending_restore = None
    return result


def set_shutdown(fn: Callable[[], None]) -> None:
    global _shutdown
    _shutdown = fn


def ask_to_shutdown() -> bool:
    if _shutdown is None:
        return False
    def later():
        time.sleep(0.35)
        _shutdown()
    threading.Thread(target=later, daemon=True).start()
    return True


class SingleInstanceLock:
    """Non-blocking lock held for the entire desktop process lifetime."""
    def __init__(self, path: Path):
        self.path = path
        self.file = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = open(self.path, "a+b")
        try:
            if os.name == "nt":
                import msvcrt
                self.file.seek(0, os.SEEK_END)
                if self.file.tell() == 0:
                    self.file.write(b"\0")
                    self.file.flush()
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError):
            self.file.close()
            self.file = None
            raise RuntimeError("Vikora is already running. Use its existing browser window.")
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.file is not None:
            try:
                if os.name == "nt":
                    import msvcrt
                    self.file.seek(0)
                    msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
            finally:
                self.file.close()
