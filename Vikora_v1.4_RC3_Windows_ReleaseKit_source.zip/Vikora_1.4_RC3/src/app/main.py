from pathlib import Path
from contextlib import asynccontextmanager
from threading import Event, Thread
import logging
from starlette.middleware.trustedhost import TrustedHostMiddleware

from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.routes.access import router as access_router
from app.routes.applications import router as applications_router
from app.routes.vacancies import router as vacancies_router
from app.routes.evaluations import router as evaluations_router
from app.routes.profile import router as profile_router
from app.routes.privacy import router as privacy_router
from app.routes.auth_web import router as auth_web_router

log = logging.getLogger("vikora-desktop")

@asynccontextmanager
async def lifespan(app: FastAPI):
    stop = Event()
    workers = []
    if settings.auth_mode == "local":
        from app.local_runtime import requeue_after_interrupted_shutdown, set_workers_stopped
        set_workers_stopped(False)
        from app.worker.parse import process_next as parse_next
        from app.worker.evaluate import process_next as evaluate_next
        from app.worker.lifecycle import run_once as lifecycle_next
        requeue_after_interrupted_shutdown()
        def worker_loop(fn, wait, label):
            while not stop.is_set():
                try:
                    did_work = fn()
                except Exception:
                    log.exception("Local %s worker encountered an error", label)
                    did_work = False
                if not did_work:
                    stop.wait(wait)
        def lifecycle_loop():
            while not stop.is_set():
                try:
                    lifecycle_next()
                except Exception:
                    log.exception("Local retention cleanup failed")
                stop.wait(60)
        for fn, label in [(parse_next,"parse"),(evaluate_next,"assessment")]:
            thread = Thread(target=worker_loop, args=(fn, 1.0, label), daemon=True)
            thread.start()
            workers.append(thread)
        thread = Thread(target=lifecycle_loop, daemon=True)
        thread.start()
        workers.append(thread)
    yield
    stop.set()
    for worker in workers:
        worker.join(timeout=20)
    if workers:
        from app.local_runtime import set_workers_stopped
        set_workers_stopped(all(not worker.is_alive() for worker in workers))

app = FastAPI(title=settings.app_name, version="1.4.0-rc3", lifespan=lifespan)
if settings.auth_mode == "local":
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost"])

WEB_ROOT = Path(__file__).resolve().parent / "web"


@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Frame-Options"] = "DENY"
    if settings.app_env == "production":
        response.headers["Strict-Transport-Security"] = "max-age=31536000"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if request.url.path.startswith("/api/") or request.url.path == "/app":
        response.headers["Cache-Control"] = "no-store"
    if request.url.path == "/app" or request.url.path.startswith("/assets/"):
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; script-src 'self'; style-src 'self'; "
            "connect-src 'self'; img-src 'self' data:; "
            "base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        )
    return response


@app.get("/health", tags=["health"])
def health():
    return {"status": "ok", "phase": "single-user-desktop" if settings.auth_mode == "local" else "api"}


@app.get("/", include_in_schema=False)
def home():
    return RedirectResponse(url="/app", status_code=307)


@app.get("/app", include_in_schema=False)
def web_app():
    return FileResponse(WEB_ROOT / "index.html", media_type="text/html", headers={"Cache-Control": "no-store"})


app.mount("/assets", StaticFiles(directory=WEB_ROOT / "assets"), name="assets")
app.include_router(vacancies_router)
app.include_router(access_router)
app.include_router(applications_router)
app.include_router(evaluations_router)
app.include_router(profile_router)
app.include_router(privacy_router)
app.include_router(auth_web_router)
if settings.auth_mode == "local":
    from app.routes.local_desktop import router as local_desktop_router
    app.include_router(local_desktop_router)
    from app.routes.local_backups import router as local_backup_router
    app.include_router(local_backup_router)
    from app.routes.local_ai import router as local_ai_router
    app.include_router(local_ai_router)
    from app.routes.chatgpt_exchange import router as chatgpt_exchange_router
    app.include_router(chatgpt_exchange_router)
    from app.routes.bulk import router as bulk_router
    app.include_router(bulk_router)
    from app.routes.knowledge import router as knowledge_router
    app.include_router(knowledge_router)

if settings.auth_mode == "local":
    from app.routes.hh_connector import router as hh_router
    app.include_router(hh_router)

if settings.auth_mode == "local":
    from app.routes.quality_audit import router as quality_router
    app.include_router(quality_router)
