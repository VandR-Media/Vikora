import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.permissions import require_vacancy
from app.db import get_db
from app.models import UserAccount, VacancyAccess, AuditEvent

router = APIRouter(prefix="/api/v1/vacancies", tags=["vacancy access"])


class AccessRequest(BaseModel):
    user_id: uuid.UUID
    role: str


@router.post("/{vacancy_id}/access", status_code=201)
def grant_access(vacancy_id: uuid.UUID, payload: AccessRequest,
                 db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user, manage=True)
    target = db.get(UserAccount, payload.user_id)
    if target is None or not target.is_active:
        raise HTTPException(status_code=404, detail="User not found")
    if payload.role not in {"viewer", "editor"} or (payload.role == "editor" and target.role != "recruiter"):
        raise HTTPException(status_code=422, detail="Invalid access role")
    if target.id == user.id:
        raise HTTPException(status_code=409, detail="Owner/admin does not require separate membership")
    old = db.scalar(select(VacancyAccess).where(VacancyAccess.vacancy_id == vacancy_id, VacancyAccess.user_id == target.id))
    if old:
        old.role = payload.role
    else:
        db.add(VacancyAccess(vacancy_id=vacancy_id, user_id=target.id, role=payload.role))
    db.add(AuditEvent(actor_id=user.id, action="vacancy.access.granted", entity_type="vacancy", entity_id=vacancy_id,
                      details={"target_user_id": str(target.id), "role": payload.role}))
    db.commit()
    return {"user_id": target.id, "role": payload.role}


@router.delete("/{vacancy_id}/access/{user_id}", status_code=204)
def revoke_access(vacancy_id: uuid.UUID, user_id: uuid.UUID,
                  db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user, manage=True)
    grant = db.scalar(select(VacancyAccess).where(VacancyAccess.vacancy_id == vacancy_id,
                                                  VacancyAccess.user_id == user_id))
    if grant is None:
        raise HTTPException(status_code=404, detail="Membership not found")
    db.delete(grant)
    db.add(AuditEvent(actor_id=user.id, action="vacancy.access.revoked", entity_type="vacancy", entity_id=vacancy_id,
                      details={"target_user_id": str(user_id)}))
    db.commit()
