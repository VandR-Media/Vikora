"""All candidate and resume access is anchored to a permitted vacancy."""
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.config import settings
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import Application, AuditEvent, Candidate, Resume, UserAccount
from app.schemas import (
    ApplicationOut, ApplicationStagePatch, CandidateCreate, ResumeOut, ResumeParsedText,
)
from app.services.uploads import blob_path, commit_file, stage_upload

router = APIRouter(prefix="/api/v1/vacancies/{vacancy_id}/applications", tags=["applications and resumes"])


def _application_or_404(db: Session, vacancy_id: uuid.UUID, application_id: uuid.UUID) -> Application:
    app = db.get(Application, application_id)
    if app is None or app.vacancy_id != vacancy_id:
        raise HTTPException(404, "Application not found")
    return app


def _resume_or_404(db: Session, candidate_id: uuid.UUID, resume_id: uuid.UUID) -> Resume:
    resume = db.get(Resume, resume_id)
    if resume is None or resume.candidate_id != candidate_id:
        raise HTTPException(404, "Resume not found")
    return resume


def _lock_live_candidate(db: Session, candidate_id: uuid.UUID) -> None:
    # Serialize writes with the admin privacy-purge transaction on PostgreSQL.
    if db.scalar(select(Candidate.id).where(Candidate.id == candidate_id).with_for_update()) is None:
        raise HTTPException(404, "Candidate not found")


@router.post("", status_code=status.HTTP_201_CREATED, response_model=ApplicationOut)
def add_candidate(vacancy_id: uuid.UUID, payload: CandidateCreate,
                  db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    candidate = Candidate(**payload.model_dump(mode="json"),
                          retention_until=datetime.now(timezone.utc) + timedelta(days=settings.default_retention_days))
    db.add(candidate)
    db.flush()
    application = Application(vacancy_id=vacancy_id, candidate_id=candidate.id, recruiter_id=user.id)
    db.add(application)
    db.flush()
    db.add(AuditEvent(actor_id=user.id, action="application.created", entity_type="application", entity_id=application.id,
                      details={"vacancy_id": str(vacancy_id)}))
    db.commit()
    db.refresh(application)
    return application


@router.get("", response_model=list[ApplicationOut])
def list_applications(vacancy_id: uuid.UUID,
                      limit: int = Query(default=200, ge=1, le=200),
                      offset: int = Query(default=0, ge=0),
                      db: Session = Depends(get_db),
                      user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    return db.scalars(select(Application).where(Application.vacancy_id == vacancy_id)
                      .order_by(Application.created_at.desc(), Application.id).offset(offset).limit(limit)).all()


@router.patch("/{application_id}", response_model=ApplicationOut)
def update_application(vacancy_id: uuid.UUID, application_id: uuid.UUID, payload: ApplicationStagePatch,
                       db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    application = _application_or_404(db, vacancy_id, application_id)
    _lock_live_candidate(db, application.candidate_id)
    previous = application.stage
    application.stage = payload.stage
    db.add(AuditEvent(actor_id=user.id, action="application.stage.updated", entity_type="application", entity_id=application.id,
                      details={"previous": previous, "new": payload.stage}))
    db.commit()
    db.refresh(application)
    return application


@router.get("/{application_id}/resumes", response_model=list[ResumeOut])
def list_resumes(vacancy_id: uuid.UUID, application_id: uuid.UUID,
                 db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    application = _application_or_404(db, vacancy_id, application_id)
    return db.scalars(select(Resume).where(Resume.candidate_id == application.candidate_id)
                      .order_by(Resume.created_at.desc(), Resume.id)).all()


@router.post("/{application_id}/resumes", response_model=ResumeOut, status_code=status.HTTP_201_CREATED)
async def upload_resume(vacancy_id: uuid.UUID, application_id: uuid.UUID,
                        file: UploadFile = File(...), db: Session = Depends(get_db),
                        user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    application = _application_or_404(db, vacancy_id, application_id)
    staged = await stage_upload(file)
    try:
        _lock_live_candidate(db, application.candidate_id)
    except Exception:
        staged.path.unlink(missing_ok=True)
        raise
    existing = db.scalar(select(Resume).where(Resume.candidate_id == application.candidate_id,
                                              Resume.sha256 == staged.sha256))
    if existing is not None:
        staged.path.unlink(missing_ok=True)
        # Idempotent retry: existing document, no new row or blob.
        return existing
    key = None
    try:
        key = commit_file(staged)
        resume = Resume(candidate_id=application.candidate_id, storage_key=key,
                        original_filename=staged.filename, mime_type=staged.mime_type,
                        sha256=staged.sha256, parse_status="pending")
        db.add(resume)
        db.flush()
        db.add(AuditEvent(actor_id=user.id, action="resume.uploaded", entity_type="resume", entity_id=resume.id,
                          details={"vacancy_id": str(vacancy_id), "sha256": staged.sha256}))
        db.commit()
        db.refresh(resume)
        return resume
    except IntegrityError:
        db.rollback()
        if key is not None:
            blob_path(key).unlink(missing_ok=True)
        # Concurrent duplicate; return the already committed blob if it exists.
        existing = db.scalar(select(Resume).where(Resume.candidate_id == application.candidate_id,
                                                  Resume.sha256 == staged.sha256))
        if existing:
            return existing
        raise
    except Exception:
        db.rollback()
        if key is not None:
            blob_path(key).unlink(missing_ok=True)
        else:
            staged.path.unlink(missing_ok=True)
        raise


@router.get("/{application_id}/resumes/{resume_id}/download")
def download_resume(vacancy_id: uuid.UUID, application_id: uuid.UUID, resume_id: uuid.UUID,
                    db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    application = _application_or_404(db, vacancy_id, application_id)
    resume = _resume_or_404(db, application.candidate_id, resume_id)
    path = blob_path(resume.storage_key)
    if not path.is_file():
        raise HTTPException(404, "Resume binary is not available")
    db.add(AuditEvent(actor_id=user.id, action="resume.downloaded", entity_type="resume", entity_id=resume.id,
                      details={"vacancy_id": str(vacancy_id)}))
    db.commit()
    return FileResponse(path, filename=resume.original_filename, media_type=resume.mime_type,
                        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@router.get("/{application_id}/resumes/{resume_id}/text", response_model=ResumeParsedText)
def get_resume_text(vacancy_id: uuid.UUID, application_id: uuid.UUID, resume_id: uuid.UUID,
                    db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    application = _application_or_404(db, vacancy_id, application_id)
    resume = _resume_or_404(db, application.candidate_id, resume_id)
    db.add(AuditEvent(actor_id=user.id, action="resume.text.read", entity_type="resume", entity_id=resume.id,
                      details={"vacancy_id": str(vacancy_id)}))
    db.commit()
    return {"resume_id": resume.id, "parse_status": resume.parse_status,
            "pages": (resume.parsed_fields or {}).get("pages") if resume.parse_status == "parsed" else None}
