"""OIDC Authorization Code + PKCE; server-side sessions for the Vikora browser UI.

No auto-provisioning. IT must provision sso_subject and role in user_accounts.
"""
import base64
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

import httpx
import jwt
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.web_sessions import (
    cookie_name, csrf_for_cookie, digest, login_cookie_name, session_from_request, utc,
)
from app.db import get_db
from app.models import AuditEvent, OIDCLoginAttempt, UserAccount, WebSession

router = APIRouter(prefix="/api/v1/auth", tags=["browser SSO"])


def _require_oidc():
    if settings.auth_mode != "oidc":
        raise HTTPException(404, "Corporate SSO not enabled")


def _jwt_id_token(id_token: str, expected_nonce: str) -> str:
    """Verify issuer, RS256 signature, client audience, token life and CSRF nonce."""
    try:
        client = jwt.PyJWKClient(settings.oidc_jwks_url, cache_keys=True)
        key = client.get_signing_key_from_jwt(id_token).key
        claims = jwt.decode(
            id_token, key, algorithms=["RS256"], audience=settings.oidc_client_id,
            issuer=settings.oidc_issuer,
            options={"require": ["iss", "sub", "aud", "iat", "exp", "nonce"]}, leeway=30,
        )
        if claims.get("nonce") != expected_nonce:
            raise ValueError("OIDC nonce mismatch")
        # RFC 7519 multi-audience tokens should identify the authorized party.
        audience = claims.get("aud")
        if isinstance(audience, list) and len(audience) > 1 and claims.get("azp") != settings.oidc_client_id:
            raise ValueError("Unexpected OIDC authorized party")
        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject.strip() or len(subject) > 255:
            raise ValueError("Invalid OIDC subject")
        return subject
    except (jwt.PyJWTError, ValueError, OSError) as exc:
        raise HTTPException(401, "OIDC identity verification failed") from exc


@router.get("/method")
def method():
    return {"mode": settings.auth_mode, "login_path": "/api/v1/auth/login" if settings.auth_mode == "oidc" else None}


@router.get("/login")
def login(db: Session = Depends(get_db)):
    _require_oidc()
    state = secrets.token_urlsafe(32)
    binding = secrets.token_urlsafe(32)
    nonce = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    now = datetime.now(timezone.utc)
    db.add(OIDCLoginAttempt(
        state_hash=digest(state), browser_binding_hash=digest(binding), nonce=nonce,
        code_verifier=verifier, expires_at=now + timedelta(minutes=5),
    ))
    db.commit()
    query = urlencode({
        "response_type": "code", "client_id": settings.oidc_client_id,
        "redirect_uri": settings.oidc_redirect_uri, "scope": "openid profile email",
        "state": state, "nonce": nonce,
        "code_challenge": challenge, "code_challenge_method": "S256",
    })
    redirect = RedirectResponse(settings.oidc_authorize_url + "?" + query, status_code=302)
    redirect.set_cookie(login_cookie_name(), binding, httponly=True,
                        secure=settings.app_env == "production", samesite="lax", path="/",
                        max_age=300)
    redirect.headers["Cache-Control"] = "no-store"
    return redirect


@router.get("/callback")
def callback(request: Request, code: str = "", state: str = "", db: Session = Depends(get_db)):
    _require_oidc()
    binding = request.cookies.get(login_cookie_name(), "")
    attempt = db.get(OIDCLoginAttempt, digest(state)) if state and len(state) < 256 else None
    if not attempt or not binding or digest(binding) != attempt.browser_binding_hash or utc(attempt.expires_at) <= datetime.now(timezone.utc):
        raise HTTPException(401, "Invalid or expired login request")
    # Consume one-use state before any untrusted network call to prevent replay.
    verifier, expected_nonce = attempt.code_verifier, attempt.nonce
    db.delete(attempt)
    db.commit()
    if not code or len(code) > 2048:
        raise HTTPException(401, "OIDC authorization failed")
    try:
        data = {"grant_type": "authorization_code", "code": code,
                "redirect_uri": settings.oidc_redirect_uri,
                "client_id": settings.oidc_client_id, "code_verifier": verifier}
        if settings.oidc_client_secret:
            # Confidential clients authenticate at the token endpoint via basic auth.
            auth = (settings.oidc_client_id, settings.oidc_client_secret)
            data.pop("client_id")
        else:
            auth = None
        with httpx.Client(timeout=10, follow_redirects=False) as http:
            response = http.post(settings.oidc_token_url, data=data, auth=auth)
            response.raise_for_status()
            payload = response.json()
        id_token = payload.get("id_token", "")
        if not isinstance(id_token, str) or len(id_token) > 15000:
            raise ValueError("Missing ID token")
        subject = _jwt_id_token(id_token, expected_nonce)
    except (httpx.HTTPError, ValueError, TypeError, KeyError) as exc:
        raise HTTPException(401, "OIDC login exchange failed") from exc
    user = db.scalar(select(UserAccount).where(UserAccount.sso_subject == subject))
    if user is None or not user.is_active:
        raise HTTPException(403, "Corporate user is not provisioned or disabled")
    raw_session = secrets.token_urlsafe(48)
    db.add(WebSession(token_hash=digest(raw_session), user_id=user.id,
                      expires_at=datetime.now(timezone.utc) + timedelta(hours=settings.session_hours)))
    db.add(AuditEvent(actor_id=user.id, action="auth.login", entity_type="user", entity_id=user.id,
                      details={"method": "oidc"}))
    db.commit()
    result = RedirectResponse("/app", status_code=303)
    result.delete_cookie(login_cookie_name(), path="/")
    result.set_cookie(cookie_name(), raw_session, secure=settings.app_env == "production",
                      httponly=True, samesite="strict", path="/",
                      max_age=settings.session_hours * 3600)
    result.headers["Cache-Control"] = "no-store"
    return result


@router.get("/session")
def whoami(request: Request, db: Session = Depends(get_db)):
    _require_oidc()
    matched = session_from_request(request, db)
    if matched is None:
        raise HTTPException(401, "No valid browser session")
    _session, user, raw = matched
    return {"user": {"id": str(user.id), "email": user.email,
                     "full_name": user.full_name, "role": user.role},
            "csrf_token": csrf_for_cookie(raw)}


@router.post("/logout", status_code=204)
def logout(request: Request, db: Session = Depends(get_db)):
    _require_oidc()
    matched = session_from_request(request, db)
    if matched is None:
        raise HTTPException(401, "No valid browser session")
    session, user, raw = matched
    from app.core.web_sessions import protect_cookie_write
    protect_cookie_write(request, raw)
    session.revoked_at = datetime.now(timezone.utc)
    db.add(AuditEvent(actor_id=user.id, action="auth.logout", entity_type="user", entity_id=user.id,
                      details={"method": "oidc"}))
    db.commit()
    result = Response(status_code=204)
    result.delete_cookie(cookie_name(), path="/")
    return result
