"""Personal desktop batch workflow: bounded resume intake, assessment queue and CSV.

Each uploaded document is independently validated and recorded, allowing a person
recover from a bad file without silently losing the rest of the batch. This API
is registered only in local desktop mode in the product (tests can mount it).
"""
from __future__ import annotations

import csv
import hashlib
import os
import tempfile
import io
import logging
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.config import settings
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import Application, AuditEvent, Candidate, Evaluation, Resume, UserAccount
from app.routes.evaluations import EvaluationRequest, queue_evaluation
from app.services.uploads import StagedUpload, blob_path, commit_file, stage_upload, scan_for_malware
from app.services.structured_import import parse_bundle, ImportFailure, MAX_FILE_BYTES

log = logging.getLogger('vikora-bulk')
router = APIRouter(prefix='/api/v1/local/bulk/vacancies/{vacancy_id}', tags=['Desktop batch workflow'])
MAX_BATCH = 50


class BulkAssessmentRequest(BaseModel):
    application_ids: list[uuid.UUID] = Field(min_length=1, max_length=MAX_BATCH)
    allow_cloud_transmission: bool = False

    @model_validator(mode='after')
    def check_unique(self):
        if len(set(self.application_ids)) != len(self.application_ids):
            raise ValueError('Повторяющиеся кандидаты в списке')
        return self


class CandidateNamePatch(BaseModel):
    full_name: str = Field(min_length=2, max_length=255)


def _placeholder_name(filename: str) -> str:
    # The document name is NOT an identity assertion; user must verify it.
    stem = Path(filename).stem.strip(' ._-')[:160]
    return ('Из файла: ' + stem)[:255] if stem else 'Кандидат — проверьте имя'


@router.post('/resumes')
async def import_resumes(vacancy_id: uuid.UUID, files: list[UploadFile] = File(...),
                         db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    if not 1 <= len(files) <= MAX_BATCH:
        raise HTTPException(422, f'За один раз можно загрузить от 1 до {MAX_BATCH} резюме')
    if sum(file.size or 0 for file in files) > 80 * 1024 * 1024:
        raise HTTPException(413, 'Общий размер документов превышает 80 МБ. Разделите загрузку на партии.')
    successes, duplicates, errors = [], [], []
    for index, upload in enumerate(files):
        staged, stored_key, committed = None, None, False
        supplied_name = (upload.filename or 'resume').replace('\\', '/').split('/')[-1][:250]
        try:
            staged = await stage_upload(upload)  # bounded per-file + signature + antivirus
            duplicate = db.scalar(select(Resume).join(Application, Resume.candidate_id == Application.candidate_id)
                                  .where(Application.vacancy_id == vacancy_id,
                                         Resume.sha256 == staged.sha256).limit(1))
            if duplicate is not None:
                duplicates.append({'filename': staged.filename, 'resume_id': str(duplicate.id)})
                continue
            stored_key = commit_file(staged)
            candidate = Candidate(
                full_name=_placeholder_name(staged.filename), source='bulk_upload',
                data_source_note='Имя сформировано из названия файла. Проверьте вручную.',
                retention_until=datetime.now(timezone.utc) + timedelta(days=settings.default_retention_days),
            )
            db.add(candidate)
            db.flush()
            application = Application(vacancy_id=vacancy_id, candidate_id=candidate.id, recruiter_id=user.id)
            db.add(application)
            db.flush()
            resume = Resume(candidate_id=candidate.id, storage_key=stored_key,
                            original_filename=staged.filename, mime_type=staged.mime_type,
                            sha256=staged.sha256, parse_status='pending')
            db.add(resume)
            db.flush()
            db.add(AuditEvent(actor_id=user.id, action='resume.bulk_imported', entity_type='resume',
                              entity_id=resume.id, details={'vacancy_id': str(vacancy_id)}))
            db.commit()
            committed = True
            successes.append({'filename': staged.filename, 'application_id': str(application.id),
                              'resume_id': str(resume.id), 'candidate_name': candidate.full_name})
        except HTTPException as exc:
            db.rollback()
            errors.append({'filename': supplied_name, 'reason': str(exc.detail)})
        except Exception:
            db.rollback()
            log.exception('Unable to import batch item %s', index)
            errors.append({'filename': supplied_name, 'reason': 'Не удалось сохранить файл. Проверьте его и повторите попытку.'})
        finally:
            if staged is not None:
                staged.path.unlink(missing_ok=True)
            if stored_key is not None and not committed:
                # A failed database transaction must not leave a private orphan file.
                blob_path(stored_key).unlink(missing_ok=True)
            await upload.close()
    return {'total': len(files), 'imported': successes, 'duplicates': duplicates, 'errors': errors,
            'note': 'Обработка текста началась автоматически. Проверьте имена кандидатов перед работой.'}


@router.post('/structured')
async def import_structured(vacancy_id: uuid.UUID, file: UploadFile = File(...),
                            db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    """One small JSON/CSV/TXT or ZIP-of-TXT -> max 50 text-only résumés.

    The input archive is never stored; candidate text lives in SQLite. All
    resumes are parsed immediately, so the existing scoring pipeline applies.
    """
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    staged_file = None
    filename = (file.filename or 'candidates').replace('\\', '/').split('/')[-1][:200]
    try:
        data = await file.read(MAX_FILE_BYTES + 1)
        if not data or len(data) > MAX_FILE_BYTES:
            raise HTTPException(413, 'Файл пустой или превышает 8 МБ')
        # Scan the uploaded bundle before parsing; never retain the source file.
        root = Path(settings.upload_dir).resolve()
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        with tempfile.NamedTemporaryFile(mode='wb', dir=root, prefix='.vikora-import-', delete=False) as tmp:
            staged_file = Path(tmp.name)
            os.chmod(staged_file, 0o600)
            tmp.write(data)
        scan_for_malware(staged_file)
        try:
            items, errors = parse_bundle(filename, data)
        except ImportFailure as exc:
            raise HTTPException(422, str(exc)) from exc
        successes, duplicates = [], []
        for item in items:
            key = None
            try:
                digest = hashlib.sha256(item.text.encode('utf-8')).hexdigest()
                existing = db.scalar(select(Resume).join(Application, Resume.candidate_id == Application.candidate_id)
                                     .where(Application.vacancy_id == vacancy_id,
                                            Resume.sha256 == digest).limit(1))
                by_external = None
                if item.external_id:
                    by_external = db.scalar(select(Candidate).join(Application, Application.candidate_id == Candidate.id)
                                            .where(Application.vacancy_id == vacancy_id,
                                                   Candidate.source == 'structured_import',
                                                   Candidate.source_external_id == item.external_id).limit(1))
                if existing or by_external:
                    duplicates.append({'filename': item.label,
                                       'reason': 'Такое резюме или внешний ID уже есть в вакансии. Новую версию импортируйте отдельно.'})
                    continue
                candidate = Candidate(full_name=item.full_name, email=item.email, phone=item.phone,
                                      source='structured_import', source_external_id=item.external_id,
                                      data_source_note='Текстовый импорт; проверьте данные кандидата.',
                                      retention_until=datetime.now(timezone.utc) + timedelta(days=settings.default_retention_days))
                db.add(candidate)
                db.flush()
                application = Application(vacancy_id=vacancy_id, candidate_id=candidate.id, recruiter_id=user.id)
                db.add(application)
                db.flush()
                # Store a compact UTF-8 text snapshot, NOT the original
                # JSON/CSV/ZIP. Existing encrypted backups and privacy purge
                # already understand private file blobs; no schema migration.
                with tempfile.NamedTemporaryFile(mode='wb', dir=root, prefix='.resume-text-', delete=False) as tmp_text:
                    temp_text = Path(tmp_text.name)
                    os.chmod(temp_text, 0o600)
                    text_bytes = item.text.encode('utf-8')
                    tmp_text.write(text_bytes)
                try:
                    key = commit_file(StagedUpload(path=temp_text, size=len(text_bytes),
                                                   sha256=digest, mime_type='text/plain',
                                                   filename='resume.txt'))
                finally:
                    temp_text.unlink(missing_ok=True)
                resume = Resume(candidate_id=candidate.id, storage_key=key,
                                original_filename=(item.label[:190] + '.txt'),
                                mime_type='text/plain', sha256=digest, parse_status='parsed',
                                parsed_fields={'pages': [{'page': 1, 'text': item.text}],
                                               'char_count': len(item.text),
                                               'source_format': item.source_format})
                db.add(resume)
                db.flush()
                db.add(AuditEvent(actor_id=user.id, action='resume.structured_imported',
                                  entity_type='resume', entity_id=resume.id,
                                  details={'vacancy_id': str(vacancy_id), 'format': item.source_format}))
                db.commit()
                successes.append({'filename': item.label, 'application_id': str(application.id),
                                  'resume_id': str(resume.id), 'candidate_name': candidate.full_name})
            except Exception:
                db.rollback()
                if key is not None:
                    blob_path(key).unlink(missing_ok=True)
                log.exception('Unable to import structured row')
                errors.append({'filename': item.label, 'reason': 'Не удалось сохранить запись. Повторите попытку.'})
        return {'total': len(items) + len(errors), 'imported': successes, 'duplicates': duplicates,
                'errors': errors,
                'note': 'Тексты доступны в карточках; исходный JSON/CSV/ZIP не сохранён. Проверьте имена.'}
    finally:
        if staged_file is not None:
            staged_file.unlink(missing_ok=True)
        await file.close()


@router.patch('/applications/{application_id}/candidate')
def rename_candidate(vacancy_id: uuid.UUID, application_id: uuid.UUID,
                     payload: CandidateNamePatch, db: Session = Depends(get_db),
                     user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    application = db.get(Application, application_id)
    if application is None or application.vacancy_id != vacancy_id:
        raise HTTPException(404, 'Кандидат не найден в этой вакансии')
    candidate = db.scalar(select(Candidate).where(Candidate.id == application.candidate_id).with_for_update())
    if candidate is None:
        raise HTTPException(404, 'Кандидат не найден')
    name = payload.full_name.strip()
    if len(name) < 2:
        raise HTTPException(422, 'Введите имя кандидата')
    candidate.full_name = name
    db.add(AuditEvent(actor_id=user.id, action='candidate.name.updated',
                      entity_type='candidate', entity_id=candidate.id,
                      details={'vacancy_id': str(vacancy_id)}))
    db.commit()
    return {'candidate_id': str(candidate.id), 'full_name': name}


@router.post('/assessments')
def queue_assessments(vacancy_id: uuid.UUID, payload: BulkAssessmentRequest,
                      db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    mode = settings.ai_provider
    is_cloud = mode in {'openai_api', 'deepseek_api', 'gigachat_api', 'alice_api'}
    if is_cloud and not payload.allow_cloud_transmission:
        raise HTTPException(422, 'Подтвердите передачу текстов выбранных резюме облачному сервису')
    queued, skipped = [], []
    for app_id in payload.application_ids:
        application = db.get(Application, app_id)
        if application is None or application.vacancy_id != vacancy_id:
            skipped.append({'application_id': str(app_id), 'reason': 'Кандидат не найден в этой вакансии'})
            continue
        resume = db.scalar(select(Resume).where(Resume.candidate_id == application.candidate_id,
                                                 Resume.parse_status == 'parsed')
                           .order_by(Resume.created_at.desc(), Resume.id.desc()).limit(1))
        if resume is None:
            skipped.append({'application_id': str(app_id), 'reason': 'Резюме ещё не обработано или текст не извлечён'})
            continue
        # Reuse single-assessment safeguards and avoid duplicating scoring logic.
        try:
            result = queue_evaluation(vacancy_id, app_id,
                                      EvaluationRequest(resume_id=resume.id,
                                                        send_resume_to_openai=mode == 'openai_api' and payload.allow_cloud_transmission,
                                                        send_resume_to_cloud=is_cloud and mode != 'openai_api' and payload.allow_cloud_transmission),
                                      db, user)
            queued.append({'application_id': str(app_id), 'evaluation_id': str(result['id']),
                           'status': result['status']})
        except HTTPException as exc:
            db.rollback()
            skipped.append({'application_id': str(app_id), 'reason': str(exc.detail)})
    return {'queued': queued, 'skipped': skipped,
            'note': 'AI-оценки выполняются по очереди. Этапы найма не меняются автоматически.'}


def _excel_text(value) -> str:
    text = str(value or '')
    # Leading whitespace and some control characters also trigger spreadsheet formulas.
    if text.lstrip(' \t\r\n').startswith(('=', '+', '-', '@')):
        return "'" + text
    return text


@router.get('/results.csv')
def export_results(vacancy_id: uuid.UUID, db: Session = Depends(get_db),
                   user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    vacancy = require_vacancy(db, vacancy_id, user)
    apps = db.scalars(select(Application).where(Application.vacancy_id == vacancy_id)
                      .order_by(Application.created_at.desc(), Application.id).limit(2000)).all()
    out = io.StringIO(newline='')
    writer = csv.writer(out, delimiter=';')
    writer.writerow(['Вакансия', 'Кандидат', 'Этап', 'Статус оценки', 'Баллы',
                     'Модель', 'Комментарий к оценке', 'Дата оценки'])
    for application in apps:
        latest = db.scalar(select(Evaluation).where(Evaluation.application_id == application.id)
                           .order_by(Evaluation.created_at.desc(), Evaluation.id.desc()).limit(1))
        writer.writerow([_excel_text(vacancy.title), _excel_text(application.candidate.full_name),
                         application.stage, latest.status if latest else 'нет оценки',
                         latest.overall_score if latest and latest.overall_score is not None else '',
                         _excel_text(latest.model_name if latest else ''),
                         _excel_text(latest.explanation if latest else ''),
                         latest.created_at.isoformat() if latest and latest.created_at else ''])
    db.add(AuditEvent(actor_id=user.id, action='assessment.csv.exported', entity_type='vacancy',
                      entity_id=vacancy_id, details={'rows': len(apps)}))
    db.commit()
    return Response(content='\ufeff' + out.getvalue(), media_type='text/csv; charset=utf-8',
                    headers={'Content-Disposition': 'attachment; filename="Vikora_results.csv"',
                             'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})
