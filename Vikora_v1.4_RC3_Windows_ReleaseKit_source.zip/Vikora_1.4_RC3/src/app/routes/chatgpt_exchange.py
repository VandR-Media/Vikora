"""Single-user manual ChatGPT Plus import/export, no OpenAI API calls."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import AuditEvent, CriterionEvaluation, Evaluation, UserAccount
from app.services import chatgpt_exchange as exchange
from app.services.evaluate import EvaluationFailure, score_results, summary_text, validate_grounding

router = APIRouter(prefix='/api/v1/local/chatgpt-exchange', tags=['ChatGPT Plus file exchange'])


@router.post('/export')
def export_batch(body: exchange.ExchangeExportInput, db: Session = Depends(get_db),
                 user: UserAccount = Depends(current_user)):
    require_editor(user)
    vacancy = require_vacancy(db, body.vacancy_id, user, edit=True)
    try:
        request = exchange.make_request(db, vacancy, body.application_ids, body.selections)
    except exchange.ExchangeFailure as exc:
        raise HTTPException(422, detail=str(exc)) from exc
    db.add(AuditEvent(actor_id=user.id, action='chatgpt.exchange.exported',
                      entity_type='vacancy', entity_id=body.vacancy_id,
                      details={'exchange_id': request['exchange_id'], 'count': len(request['selections'])}))
    db.commit()
    filename = 'Vikora_задание_' + datetime.now().strftime('%Y-%m-%d_%H-%M') + '.json'
    return Response(
        content=json.dumps(request, ensure_ascii=False, indent=2).encode('utf-8'),
        media_type='application/json; charset=utf-8',
        headers={'Content-Disposition': "attachment; filename=Vikora_request.json; filename*=UTF-8''" +
                 ''.join(f'%{b:02X}' if b > 127 or b == 0x20 else chr(b) for b in filename.encode('utf-8')),
                 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'},
    )


@router.post('/import')
async def import_result(file: UploadFile = File(...), db: Session = Depends(get_db),
                        user: UserAccount = Depends(current_user)):
    require_editor(user)
    try:
        content = await file.read(exchange.MAX_IMPORT_BYTES + 1)
        result = exchange.parse_result_json(content)
        vacancy = require_vacancy(db, result.vacancy_id, user, edit=True)
        snapshot = exchange.make_source_snapshot(db, vacancy, result.selections)
        if exchange.source_hash(snapshot) != result.source_hash:
            raise exchange.ExchangeFailure(
                'Вакансия, критерии или резюме изменились после экспорта. Создайте новый пакет для ChatGPT.')
        # Reject a repeated import, even if the response is renamed or re-downloaded.
        app_ids = [s.application_id for s in result.selections]
        existing = db.scalars(select(Evaluation).where(
            Evaluation.application_id.in_(app_ids),
            Evaluation.model_name == exchange.EXCHANGE_MODEL_NAME,
        )).all()
        for evaluation in existing:
            metadata = evaluation.criteria_snapshot or {}
            if metadata.get('exchange_id') == str(result.exchange_id) or (
                metadata.get('exchange_source_hash') == result.source_hash
                and evaluation.resume_id in {s.resume_id for s in result.selections}
            ):
                raise exchange.ExchangeFailure('Этот пакет уже импортирован в Vikora. Повторно загружать его не нужно.')
        candidates = {item['application_id']: item for item in snapshot['candidates']}
        new_evaluations = []
        for item in result.results:
            source_candidate = candidates[str(item.application_id)]
            criteria = snapshot['vacancy']['criteria']
            try:
                validated = validate_grounding(
                    item.assessment.model_dump(mode='json'), criteria, source_candidate['resume_pages'])
            except EvaluationFailure as exc:
                raise exchange.ExchangeFailure(
                    'Найдена ошибочная оценка или выдуманная цитата. Проверьте файл в ChatGPT: ' + str(exc)
                ) from exc
            score, coverage = score_results(criteria, validated)
            evaluation = Evaluation(
                application_id=item.application_id, resume_id=item.resume_id,
                status='completed', model_name=exchange.EXCHANGE_MODEL_NAME,
                prompt_version=exchange.EXCHANGE_PROMPT_VERSION,
                criteria_snapshot={'version': '1', 'criteria': criteria,
                                   'exchange_id': str(result.exchange_id),
                                   'exchange_source_hash': result.source_hash},
                overall_score=score,
                explanation=summary_text(score, coverage, 'chatgpt-plus-file') +
                            ' · Файловый обмен с ChatGPT Plus. Обязательно проверьте цитаты и выводы.',
                finished_at=datetime.now(timezone.utc),
            )
            db.add(evaluation)
            db.flush()
            for criterion in validated:
                db.add(CriterionEvaluation(
                    evaluation_id=evaluation.id, criterion_key=criterion.criterion_key,
                    match_level=criterion.match_level,
                    evidence=[ev.model_dump(mode='json') for ev in criterion.evidence],
                    rationale=criterion.rationale,
                ))
            new_evaluations.append(str(evaluation.id))
        db.add(AuditEvent(actor_id=user.id, action='chatgpt.exchange.imported',
                          entity_type='vacancy', entity_id=vacancy.id,
                          details={'exchange_id': str(result.exchange_id), 'count': len(result.results)}))
        db.commit()
        return {'status': 'imported', 'count': len(new_evaluations),
                'evaluation_ids': new_evaluations,
                'message': 'Оценки сохранены. Этапы найма не изменены; проверьте результаты вручную.'}
    except exchange.ExchangeFailure as exc:
        db.rollback()
        raise HTTPException(422, detail=str(exc)) from exc
    finally:
        await file.close()
