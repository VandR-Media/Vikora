"""Evaluations are always scoped to an authorized vacancy and application."""
from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.config import settings
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import Application, AuditEvent, Candidate, CriterionEvaluation, Evaluation, Resume, UserAccount
from app.services.evaluate import PROMPT_VERSION, criteria_snapshot, score_results, CriterionResult

router = APIRouter(prefix="/api/v1/vacancies/{vacancy_id}", tags=["Vikora assessment"])


class EvaluationRequest(BaseModel):
    resume_id: uuid.UUID
    send_resume_to_openai: bool = False  # compatibility with v0.9.1
    send_resume_to_cloud: bool = False


class CriterionAssessmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    criterion_key: str
    match_level: str
    evidence: list[dict]
    rationale: str


class EvaluationOut(BaseModel):
    id: uuid.UUID
    application_id: uuid.UUID
    resume_id: uuid.UUID
    status: str
    model_name: str
    prompt_version: str
    overall_score: int | None
    coverage_pct: int | None
    criteria_snapshot: dict
    explanation: str | None
    error_message: str | None
    created_at: datetime
    finished_at: datetime | None
    review_required: bool = True
    results: list[CriterionAssessmentOut]
    expert_corrections: list[dict] = Field(default_factory=list)
    needs_reassessment: bool = False


class ReviewQueueRow(BaseModel):
    application_id: uuid.UUID
    candidate_name: str
    evaluation_id: uuid.UUID | None
    status: str | None
    overall_score: int | None
    coverage_pct: int | None
    unverified_must_criteria: int
    stage: str
    needs_reassessment: bool = False


def _get_application(db: Session, vacancy_id: uuid.UUID, app_id: uuid.UUID) -> Application:
    app = db.get(Application, app_id)
    if app is None or app.vacancy_id != vacancy_id:
        raise HTTPException(status_code=404, detail="Application not found")
    return app


def _get_evaluation(db: Session, app_id: uuid.UUID, eval_id: uuid.UUID) -> Evaluation:
    evaluation = db.get(Evaluation, eval_id)
    if evaluation is None or evaluation.application_id != app_id:
        raise HTTPException(status_code=404, detail="Evaluation not found")
    return evaluation


def _to_output(db: Session, evaluation: Evaluation) -> dict:
    results = db.scalars(select(CriterionEvaluation).where(CriterionEvaluation.evaluation_id == evaluation.id)).all()
    snapshot = (evaluation.criteria_snapshot or {}).get("criteria", [])
    coverage = None
    if evaluation.status == "completed":
        typed = [CriterionResult.model_validate({
            "criterion_key": item.criterion_key, "match_level": item.match_level,
            "evidence": item.evidence, "rationale": item.rationale,
        }) for item in results]
        if len(typed) == len(snapshot):
            _, coverage = score_results(snapshot, typed)
    from app.models import ExpertCorrection, Vacancy
    from app.services.knowledge import snapshot_for, assessment_stale
    corrections = db.scalars(select(ExpertCorrection).where(ExpertCorrection.evaluation_id == evaluation.id)).all()
    application = db.get(Application, evaluation.application_id)
    vacancy = db.get(Vacancy, application.vacancy_id) if application else None
    stale = assessment_stale(snapshot_for(db, vacancy), evaluation.criteria_snapshot or {}) if vacancy else False
    return {
        "expert_corrections": [{"criterion_key": x.criterion_key, "corrected_level": x.corrected_level,
                                 "note": x.note} for x in corrections], "needs_reassessment": stale,
        "id": evaluation.id, "application_id": evaluation.application_id,
        "resume_id": evaluation.resume_id, "status": evaluation.status,
        "model_name": evaluation.model_name, "prompt_version": evaluation.prompt_version,
        "overall_score": evaluation.overall_score, "coverage_pct": coverage,
        "criteria_snapshot": evaluation.criteria_snapshot, "explanation": evaluation.explanation,
        "error_message": evaluation.error_message, "created_at": evaluation.created_at,
        "finished_at": evaluation.finished_at, "review_required": True,
        "results": [{"criterion_key": r.criterion_key, "match_level": r.match_level,
                     "evidence": r.evidence, "rationale": r.rationale} for r in results],
    }


@router.post("/applications/{application_id}/evaluations", response_model=EvaluationOut,
             status_code=status.HTTP_202_ACCEPTED)
def queue_evaluation(vacancy_id: uuid.UUID, application_id: uuid.UUID,
                     payload: EvaluationRequest, db: Session = Depends(get_db),
                     user: UserAccount = Depends(current_user)):
    require_editor(user)
    vacancy = require_vacancy(db, vacancy_id, user, edit=True)
    application = _get_application(db, vacancy_id, application_id)
    if db.scalar(select(Candidate.id).where(Candidate.id == application.candidate_id).with_for_update()) is None:
        raise HTTPException(status_code=404, detail="Candidate not found")
    resume = db.get(Resume, payload.resume_id)
    if resume is None or resume.candidate_id != application.candidate_id:
        raise HTTPException(status_code=404, detail="Resume not found for this application")
    if resume.parse_status != "parsed":
        raise HTTPException(status_code=409, detail="Resume must be parsed before evaluation")
    if not vacancy.criteria:
        raise HTTPException(status_code=422, detail="Add at least one vacancy criterion before evaluation")
    if settings.ai_provider == "disabled":
        raise HTTPException(status_code=503, detail="Evaluation engine is disabled")
    if settings.ai_provider == "openai_compatible" and not settings.ai_allow_resume_transmission:
        raise HTTPException(status_code=503, detail="Explicit AI resume transmission consent is required in configuration")
    if settings.ai_provider == "openai_api":
        from app.services.openai_bridge import read_api_key
        if not payload.send_resume_to_openai:
            raise HTTPException(status_code=422, detail="Подтвердите отправку текста этого резюме в OpenAI API")
        if not read_api_key():
            raise HTTPException(status_code=409, detail="Не настроен ключ OpenAI API")
    if settings.ai_provider in {"deepseek_api", "gigachat_api", "alice_api"}:
        from app.services.cloud_providers import get_credentials
        if not payload.send_resume_to_cloud:
            raise HTTPException(status_code=422, detail="Подтвердите передачу текста резюме выбранному AI-сервису")
        if not get_credentials(settings.ai_provider):
            raise HTTPException(status_code=409, detail="Не настроен ключ выбранного AI-сервиса")
    from app.services.knowledge import snapshot_for
    knowledge_snapshot = snapshot_for(db, vacancy)
    # Do not enqueue duplicates while a prior request is still in-flight.
    existing = db.scalar(select(Evaluation).where(
        Evaluation.application_id == application_id, Evaluation.resume_id == resume.id,
        Evaluation.status.in_(["pending", "processing"]),
    ).order_by(Evaluation.created_at.desc(), Evaluation.id.desc()).limit(1))
    if existing:
        from app.services.knowledge import assessment_stale
        if not assessment_stale(knowledge_snapshot, existing.criteria_snapshot or {}):
            return _to_output(db, existing)
        if existing.status == "pending":
            existing.status = "failed"
            existing.error_message = "Критерии или словарь изменились; заменено новой оценкой"
            existing.finished_at = datetime.now(timezone.utc)
    assessment = Evaluation(
        application_id=application_id, resume_id=resume.id, status="pending",
        model_name="local-exact-match-v1" if settings.ai_provider == "heuristic" else ("qwen3:4b" if settings.ai_provider == "ollama_local" else settings.ai_model),
        prompt_version=PROMPT_VERSION, criteria_snapshot={**knowledge_snapshot, "provider": settings.ai_provider, "cloud_consent": (payload.send_resume_to_openai if settings.ai_provider == "openai_api" else payload.send_resume_to_cloud if settings.ai_provider in {"deepseek_api", "gigachat_api", "alice_api"} else False)},
    )
    db.add(assessment)
    db.flush()
    db.add(AuditEvent(actor_id=user.id, action="evaluation.queued", entity_type="evaluation",
                      entity_id=assessment.id, details={"vacancy_id": str(vacancy_id), "mode": settings.ai_provider}))
    db.commit()
    db.refresh(assessment)
    return _to_output(db, assessment)


@router.get("/applications/{application_id}/evaluations", response_model=list[EvaluationOut])
def list_evaluations(vacancy_id: uuid.UUID, application_id: uuid.UUID,
                     limit: int = Query(default=20, ge=1, le=100),
                     db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    _get_application(db, vacancy_id, application_id)
    items = db.scalars(select(Evaluation).where(Evaluation.application_id == application_id)
                       .order_by(Evaluation.created_at.desc(), Evaluation.id.desc()).limit(limit)).all()
    db.add(AuditEvent(actor_id=user.id, action="evaluation.list.read", entity_type="application",
                      entity_id=application_id, details={"vacancy_id": str(vacancy_id)}))
    db.commit()
    return [_to_output(db, item) for item in items]


@router.get("/applications/{application_id}/evaluations/{evaluation_id}", response_model=EvaluationOut)
def get_evaluation(vacancy_id: uuid.UUID, application_id: uuid.UUID, evaluation_id: uuid.UUID,
                   db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    _get_application(db, vacancy_id, application_id)
    evaluation = _get_evaluation(db, application_id, evaluation_id)
    db.add(AuditEvent(actor_id=user.id, action="evaluation.read", entity_type="evaluation",
                      entity_id=evaluation_id, details={"vacancy_id": str(vacancy_id)}))
    db.commit()
    return _to_output(db, evaluation)


@router.get("/review-queue", response_model=list[ReviewQueueRow])
def review_queue(vacancy_id: uuid.UUID, limit: int = Query(default=100, ge=1, le=200),
                 offset: int = Query(default=0, ge=0),
                 db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    apps = db.scalars(select(Application).where(Application.vacancy_id == vacancy_id)
                      .order_by(Application.created_at.desc(), Application.id).offset(offset).limit(limit)).all()
    out = []
    for application in apps:
        latest = db.scalar(select(Evaluation).where(Evaluation.application_id == application.id)
                           .order_by(Evaluation.created_at.desc(), Evaluation.id.desc()).limit(1))
        data = _to_output(db, latest) if latest else None
        must_keys = {c["key"] for c in (latest.criteria_snapshot or {}).get("criteria", []) if c["importance"] == "must"} if latest else set()
        known_must = {r["criterion_key"] for r in data["results"] if r["match_level"] != "unknown"} if data else set()
        out.append({
            "application_id": application.id, "candidate_name": application.candidate.full_name,
            "evaluation_id": latest.id if latest else None,
            "status": latest.status if latest else None,
            "overall_score": data["overall_score"] if data else None,
            "coverage_pct": data["coverage_pct"] if data else None,
            "unverified_must_criteria": len(must_keys - known_must),
            "stage": application.stage,
            "needs_reassessment": data["needs_reassessment"] if data else False,
        })
    db.add(AuditEvent(actor_id=user.id, action="evaluation.review_queue.read", entity_type="vacancy",
                      entity_id=vacancy_id))
    db.commit()
    # Keep natural application order. Do not automate hire/reject or score-sort by default.
    return out
