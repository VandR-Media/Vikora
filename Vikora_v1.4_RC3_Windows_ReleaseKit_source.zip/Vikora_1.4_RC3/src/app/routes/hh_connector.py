"""Optional personal HeadHunter connection. All employer resources are READ ONLY.

No messages, invitations, unlocking paid contacts or changing hh.ru statuses.
Imported resumes stay in the user's local Vikora storage.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import os
import tempfile
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.config import settings
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import Application, AuditEvent, Candidate, HHVacancyLink, Resume, UserAccount
from app.services.uploads import StagedUpload, blob_path, commit_file
from app.services import hh_connector as hh

router = APIRouter(prefix='/api/v1/local/hh', tags=['HeadHunter (read-only)'])


class HHConfig(BaseModel):
    client_id: str = Field(min_length=8, max_length=128)
    client_secret: str = Field(min_length=12, max_length=256)
    contact_email: str = Field(min_length=5, max_length=254)


class VacancyLinkRequest(BaseModel):
    hh_vacancy_id: str = Field(pattern=r'^\d{1,20}$')


class ImportRequest(BaseModel):
    collection_id: str = Field(min_length=1, max_length=100)
    page: int = Field(ge=0, le=2000)
    negotiation_ids: list[str] = Field(min_length=1, max_length=50)
    confirm_resume_view: bool = False


def _api_error(exc):
    if isinstance(exc, hh.HHError):
        raise HTTPException(exc.status, str(exc)) from exc
    raise exc


@router.get('/status')
def status(_user: UserAccount = Depends(current_user)):
    try:
        config = hh.get_config()
        connected = bool(hh._read_secret('oauth_tokens'))
        return {'configured':bool(config), 'connected':connected,
                'redirect_uri':config.get('redirect_uri'),
                'note':'Для работы с откликами нужны права аккаунта работодателя и доступ к платным методам API hh.ru.'}
    except hh.HHError as exc:
        _api_error(exc)


@router.post('/settings')
def configure(body: HHConfig, _user: UserAccount = Depends(current_user)):
    if settings.auth_mode != 'local':
        raise HTTPException(403, 'Только в личной версии Vikora')
    try:
        port = int(os.getenv('VIKORA_DESKTOP_PORT','18467'))
        hh.save_config(body.client_id, body.client_secret, body.contact_email, port)
        # Do not return or log the client secret.
        return {'configured':True, 'redirect_uri':hh.get_config()['redirect_uri']}
    except hh.HHError as exc:
        _api_error(exc)


@router.delete('/connection')
def disconnect(_user: UserAccount = Depends(current_user)):
    try:
        hh.remove_connection()
        return {'connected':False, 'note':'Локальные кандидаты и вакансии не удалены.'}
    except hh.HHError as exc:
        _api_error(exc)


@router.post('/authorize')
def authorize(_user: UserAccount = Depends(current_user)):
    try:
        return {'url':hh.create_authorization_url()}
    except hh.HHError as exc:
        _api_error(exc)


@router.get('/oauth/callback', response_class=HTMLResponse, include_in_schema=False)
def oauth_callback(code: str = '', state: str = '', error: str = ''):
    if error:
        # Do not print OAuth error_description or secrets into the browser page.
        return HTMLResponse('<html><meta charset="utf-8"><p>hh.ru не предоставил доступ. Вернитесь в Vikora.</p></html>', status_code=400)
    try:
        hh.exchange_code(code, state)
    except hh.HHError:
        return HTMLResponse('<html><meta charset="utf-8"><p>Подключение не завершено. Вернитесь в Vikora и повторите попытку.</p></html>', status_code=400)
    return HTMLResponse('<html><meta charset="utf-8"><p>hh.ru подключён. Вернитесь в первоначальную вкладку Vikora и обновите её.</p></html>')


@router.get('/vacancies')
def hh_vacancies(_user: UserAccount = Depends(current_user)):
    try:
        return {'items':hh.list_vacancies(), 'note':'Показаны доступные активные вакансии аккаунта работодателя.'}
    except hh.HHError as exc:
        _api_error(exc)


@router.get('/vacancies/{vacancy_id}/link')
def current_link(vacancy_id: uuid.UUID, db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_vacancy(db, vacancy_id, user)
    link = db.get(HHVacancyLink, vacancy_id)
    return {'hh_vacancy_id':link.hh_vacancy_id if link else None}


@router.post('/vacancies/{vacancy_id}/link')
def link_vacancy(vacancy_id: uuid.UUID, body: VacancyLinkRequest,
                 db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    require_vacancy(db, vacancy_id, user, edit=True)
    # Verify the employer can actually see this vacancy; never trust user-supplied ID alone.
    try:
        if body.hh_vacancy_id not in {v['id'] for v in hh.list_vacancies()}:
            raise HTTPException(403,'Эта вакансия недоступна в подключённом аккаунте hh.ru.')
    except hh.HHError as exc:
        _api_error(exc)
    link=db.get(HHVacancyLink,vacancy_id)
    if link is None:
        db.add(HHVacancyLink(vacancy_id=vacancy_id, hh_vacancy_id=body.hh_vacancy_id))
    else:
        link.hh_vacancy_id=body.hh_vacancy_id
    db.add(AuditEvent(actor_id=user.id,action='hh.vacancy.linked',entity_type='vacancy',entity_id=vacancy_id))
    db.commit()
    return {'hh_vacancy_id':body.hh_vacancy_id}


def _linked(db: Session, vacancy_id:uuid.UUID) -> str:
    link=db.get(HHVacancyLink,vacancy_id)
    if link is None:
        raise HTTPException(409,'Сначала выберите вакансию hh.ru, соответствующую вакансии Vikora.')
    return link.hh_vacancy_id


@router.get('/vacancies/{vacancy_id}/collections')
def collections(vacancy_id:uuid.UUID, db:Session=Depends(get_db),user:UserAccount=Depends(current_user)):
    require_vacancy(db,vacancy_id,user)
    try:
        return {'items':hh.list_collections(_linked(db,vacancy_id))}
    except hh.HHError as exc:
        _api_error(exc)


@router.get('/vacancies/{vacancy_id}/preview')
def preview(vacancy_id:uuid.UUID, collection_id:str=Query(min_length=1,max_length=100),
            page:int=Query(default=0,ge=0,le=2000),db:Session=Depends(get_db),
            user:UserAccount=Depends(current_user)):
    require_vacancy(db,vacancy_id,user)
    try:
        return {'items':hh.list_collection_page(_linked(db,vacancy_id),collection_id,page),
                'page':page,'note':'Предварительный список. Полные резюме ещё не запрашивались.'}
    except hh.HHError as exc:
        _api_error(exc)


@router.post('/vacancies/{vacancy_id}/import')
def import_selected(vacancy_id:uuid.UUID, body:ImportRequest,
                    db:Session=Depends(get_db),user:UserAccount=Depends(current_user)):
    require_editor(user)
    require_vacancy(db,vacancy_id,user,edit=True)
    if not body.confirm_resume_view:
        raise HTTPException(422,'Подтвердите получение полного текста резюме. На hh.ru отклик может быть отмечен просмотренным.')
    if len(set(body.negotiation_ids))!=len(body.negotiation_ids):
        raise HTTPException(422,'Повторяющиеся отклики в списке.')
    try:
        page=hh.list_collection_page(_linked(db,vacancy_id),body.collection_id,body.page)
    except hh.HHError as exc:
        _api_error(exc)
    allowed={row['id']:row for row in page}
    if any(i not in allowed for i in body.negotiation_ids):
        raise HTTPException(409,'Список откликов изменился. Обновите предпросмотр.')
    imported, duplicates, skipped = [], [], []
    root = Path(settings.upload_dir).resolve()
    root.mkdir(parents=True,exist_ok=True)
    for negotiation_id in body.negotiation_ids:
        row=allowed[negotiation_id]
        ext_id=row['resume_id'] or 'negotiation:'+negotiation_id
        existing=db.scalar(select(Candidate).join(Application,Application.candidate_id==Candidate.id)
                 .where(Application.vacancy_id==vacancy_id,Candidate.source=='hh.ru',
                        Candidate.source_external_id==ext_id).limit(1))
        if existing:
            duplicates.append({'negotiation_id':negotiation_id,'reason':'Уже есть в этой вакансии'})
            continue
        if not row.get('has_resume'):
            skipped.append({'negotiation_id':negotiation_id,'reason':'Полный текст резюме недоступен'})
            continue
        key=None
        try:
            info,text = hh.fetch_resume(row['resume_url'])
            digest=hashlib.sha256(text.encode('utf-8')).hexdigest()
            same=db.scalar(select(Resume).join(Application,Resume.candidate_id==Application.candidate_id)
                .where(Application.vacancy_id==vacancy_id,Resume.sha256==digest).limit(1))
            if same:
                duplicates.append({'negotiation_id':negotiation_id,'reason':'Точно такое резюме уже загружено'})
                continue
            parts=[str(info.get(k) or '').strip() for k in ('last_name','first_name','middle_name')]
            full_name=' '.join(x for x in parts if x)[:255] or 'Кандидат hh.ru — проверьте имя'
            candidate=Candidate(full_name=full_name,source='hh.ru',source_external_id=ext_id,
                      data_source_note='Получено через официальный API hh.ru; объём данных зависит от прав аккаунта.',
                      retention_until=datetime.now(timezone.utc)+timedelta(days=settings.default_retention_days))
            db.add(candidate);db.flush()
            application=Application(vacancy_id=vacancy_id,candidate_id=candidate.id,recruiter_id=user.id)
            db.add(application);db.flush()
            payload=text.encode('utf-8')
            with tempfile.NamedTemporaryFile(mode='wb',dir=root,prefix='.hh-resume-',delete=False) as handle:
                temp=Path(handle.name)
                os.chmod(temp,0o600)
                handle.write(payload)
            try:
                key=commit_file(StagedUpload(path=temp, size=len(payload),sha256=digest,
                             mime_type='text/plain',filename='hh_resume.txt'))
            finally:
                temp.unlink(missing_ok=True)
            resume=Resume(candidate_id=candidate.id,storage_key=key,
                      original_filename='hh_resume.txt',mime_type='text/plain',sha256=digest,
                      parse_status='parsed',parsed_fields={'pages':[{'page':1,'text':text}],
                      'char_count':len(text),'source_format':'hh_api',
                      'source_resume_id':row['resume_id']})
            db.add(resume);db.flush()
            db.add(AuditEvent(actor_id=user.id,action='hh.resume.imported',entity_type='resume',
                  entity_id=resume.id,details={'vacancy_id':str(vacancy_id)}))
            db.commit()
            imported.append({'negotiation_id':negotiation_id,'application_id':str(application.id),
                             'resume_id':str(resume.id),'candidate_name':full_name})
        except hh.HHError as exc:
            db.rollback()
            if key:blob_path(key).unlink(missing_ok=True)
            skipped.append({'negotiation_id':negotiation_id,'reason':str(exc)})
        except Exception:
            db.rollback()
            if key:blob_path(key).unlink(missing_ok=True)
            skipped.append({'negotiation_id':negotiation_id,'reason':'Не удалось сохранить резюме. Повторите импорт.'})
    return {'imported':imported,'duplicates':duplicates,'skipped':skipped,
            'note':'Кандидаты добавлены в Vikora. На hh.ru приглашения и статусы не изменялись.'}
