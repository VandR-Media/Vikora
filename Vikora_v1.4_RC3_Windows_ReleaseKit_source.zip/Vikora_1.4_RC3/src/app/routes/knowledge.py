"""Private, single-user knowledge base and explicit human corrections.

These endpoints are intentionally mounted ONLY in local desktop mode.
No URL here triggers training, network calls, or automatic candidate decisions.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import AuditEvent, Evaluation, ExpertCorrection, KnowledgeTerm, UserAccount
from app.services.knowledge import canonical_name, visible_terms

router = APIRouter(prefix="/api/v1/local/knowledge", tags=["Personal recruiter knowledge"])


class TermCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    aliases: list[str] = Field(default_factory=list, max_length=12)
    explanation: str = Field(default="", max_length=1000)
    vacancy_id: uuid.UUID | None = None

    @field_validator("name", "explanation")
    @classmethod
    def trim(cls, value: str) -> str:
        if any(ord(ch) < 32 and ch not in "\n\t" for ch in value):
            raise ValueError("Запрещённые управляющие символы")
        return value.strip()

    @field_validator("aliases")
    @classmethod
    def validate_aliases(cls, value: list[str]) -> list[str]:
        cleaned = [" ".join(v.split()) for v in value]
        if any(len(a) < 2 or len(a) > 100 for a in cleaned):
            raise ValueError("Синоним должен содержать от 2 до 100 символов")
        if len({canonical_name(a) for a in cleaned}) != len(cleaned):
            raise ValueError("Синонимы не должны повторяться")
        return cleaned

    @model_validator(mode="after")
    def check(self):
        if len(self.name.strip()) < 2:
            raise ValueError("Укажите термин")
        if canonical_name(self.name) in {canonical_name(a) for a in self.aliases}:
            raise ValueError("Название термина не нужно повторять в синонимах")
        return self


class TermPatch(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=120)
    aliases: list[str] | None = Field(default=None, max_length=12)
    explanation: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def check(self):
        if not self.model_fields_set or any(getattr(self, key) is None for key in self.model_fields_set):
            raise ValueError("Изменения должны быть заполнены")
        return self


class TermOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    vacancy_id: uuid.UUID | None
    name: str
    aliases: list[str]
    explanation: str


class CorrectionInput(BaseModel):
    criterion_key: str = Field(min_length=2, max_length=80)
    corrected_level: str = Field(pattern=r"^(met|partial|not_met|unknown)$")
    note: str = Field(min_length=5, max_length=2000)


class CorrectionOut(BaseModel):
    criterion_key: str
    corrected_level: str
    note: str


def require_scope(db: Session, vacancy_id, user):
    require_editor(user)
    if vacancy_id is not None:
        require_vacancy(db, vacancy_id, user, edit=True)


def _term(db: Session, term_id: uuid.UUID, user) -> KnowledgeTerm:
    term = db.get(KnowledgeTerm, term_id)
    if term is None:
        raise HTTPException(404, "Термин не найден")
    require_scope(db, term.vacancy_id, user)
    return term


def _unique(db: Session, scope, name: str, excluding=None) -> None:
    existing = db.scalar(select(KnowledgeTerm).where(KnowledgeTerm.vacancy_id == scope,
                                                       KnowledgeTerm.normalized_name == canonical_name(name)))
    if existing is not None and existing.id != excluding:
        raise HTTPException(409, "Термин с таким названием уже есть в выбранном справочнике")


@router.get("/terms", response_model=list[TermOut])
def list_terms(vacancy_id: uuid.UUID | None = None, db: Session = Depends(get_db),
               user: UserAccount = Depends(current_user)):
    if vacancy_id is not None:
        require_vacancy(db, vacancy_id, user)
        return visible_terms(db, vacancy_id)
    require_editor(user)
    return db.scalars(select(KnowledgeTerm).where(KnowledgeTerm.vacancy_id.is_(None))
                      .order_by(KnowledgeTerm.name)).all()


@router.post("/terms", response_model=TermOut, status_code=201)
def create_term(payload: TermCreate, db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_scope(db, payload.vacancy_id, user)
    _unique(db, payload.vacancy_id, payload.name)
    record = KnowledgeTerm(vacancy_id=payload.vacancy_id, name=payload.name,
                           normalized_name=canonical_name(payload.name), aliases=payload.aliases,
                           explanation=payload.explanation)
    db.add(record)
    db.flush()
    db.add(AuditEvent(actor_id=user.id, action="knowledge.created", entity_type="knowledge_term", entity_id=record.id))
    db.commit()
    db.refresh(record)
    return record


@router.patch("/terms/{term_id}", response_model=TermOut)
def update_term(term_id: uuid.UUID, payload: TermPatch, db: Session = Depends(get_db),
                user: UserAccount = Depends(current_user)):
    record = _term(db, term_id, user)
    # Full validation ensures updates cannot bypass the alias/duplicate checks.
    desired = TermCreate(name=payload.name if payload.name is not None else record.name,
                         aliases=payload.aliases if payload.aliases is not None else record.aliases,
                         explanation=payload.explanation if payload.explanation is not None else record.explanation,
                         vacancy_id=record.vacancy_id)
    _unique(db, record.vacancy_id, desired.name, excluding=record.id)
    record.name, record.normalized_name, record.aliases, record.explanation = (
        desired.name, canonical_name(desired.name), desired.aliases, desired.explanation)
    record.updated_at = datetime.now(timezone.utc)
    db.add(AuditEvent(actor_id=user.id, action="knowledge.updated", entity_type="knowledge_term", entity_id=record.id))
    db.commit()
    db.refresh(record)
    return record


@router.delete("/terms/{term_id}", status_code=204)
def delete_term(term_id: uuid.UUID, db: Session = Depends(get_db),
                user: UserAccount = Depends(current_user)):
    record = _term(db, term_id, user)
    db.add(AuditEvent(actor_id=user.id, action="knowledge.deleted", entity_type="knowledge_term", entity_id=record.id))
    db.delete(record)
    db.commit()


@router.post("/vacancies/{vacancy_id}/evaluations/{evaluation_id}/corrections", response_model=CorrectionOut)
def save_correction(vacancy_id: uuid.UUID, evaluation_id: uuid.UUID, payload: CorrectionInput,
                    db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_scope(db, vacancy_id, user)
    from app.models import Application
    evaluation = db.get(Evaluation, evaluation_id)
    application = db.get(Application, evaluation.application_id) if evaluation else None
    if not evaluation or not application or application.vacancy_id != vacancy_id:
        raise HTTPException(404, "Оценка не найдена в выбранной вакансии")
    if evaluation.status != "completed":
        raise HTTPException(409, "Замечания можно добавлять к завершённой оценке")
    if payload.criterion_key not in {item['key'] for item in evaluation.criteria_snapshot.get('criteria', [])}:
        raise HTTPException(422, "Критерий отсутствует в этой оценке")
    item = db.scalar(select(ExpertCorrection).where(ExpertCorrection.evaluation_id == evaluation.id,
                                                     ExpertCorrection.criterion_key == payload.criterion_key))
    if item is None:
        item = ExpertCorrection(evaluation_id=evaluation.id, criterion_key=payload.criterion_key)
        db.add(item)
    item.corrected_level = payload.corrected_level
    item.note = payload.note.strip()
    item.updated_at = datetime.now(timezone.utc)
    db.add(AuditEvent(actor_id=user.id, action="evaluation.correction.saved", entity_type="evaluation",
                      entity_id=evaluation.id, details={"criterion_key": payload.criterion_key}))
    db.commit()
    return payload.model_dump()
