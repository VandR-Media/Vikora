"""Personal AI settings, mounted only on the single-user desktop runtime."""
from typing import Literal
import re
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, model_validator
from app.core.auth import current_user
from app.core.config import settings
from app.models import UserAccount
from app.local_preferences import MODEL_TAG, OPENAI_MODEL_TAG, CLOUD_MODEL_TAGS, save_ai_preference
from app.services.local_ai import probe_ollama
from app.services.evaluate import EvaluationFailure
from app.services import openai_bridge, cloud_providers

router = APIRouter(prefix="/api/v1/local/ai", tags=["personal AI"])

class ChangeMode(BaseModel):
    enabled: bool | None = None  # backward compatible with v0.9 tests
    mode: Literal["heuristic", "ollama_local", "openai_api", "deepseek_api", "gigachat_api", "alice_api"] | None = None

    @model_validator(mode="after")
    def validate_request(self):
        if (self.enabled is None) == (self.mode is None):
            raise ValueError("Specify either mode or enabled")
        return self

class ApiKeyInput(BaseModel):
    api_key: str = Field(min_length=20, max_length=260)

class VacancyDraftRequest(BaseModel):
    role: str = Field(min_length=3, max_length=200)
    notes: str = Field(min_length=10, max_length=4000)
    send_to_openai: bool = False  # legacy client support
    send_to_cloud: bool = False
    provider: Literal["openai_api", "deepseek_api", "gigachat_api", "alice_api"] | None = None

@router.get("/status")
def status(_user: UserAccount = Depends(current_user)):
    health = probe_ollama()
    mode = settings.ai_provider
    configured = openai_bridge.read_api_key() is not None
    cloud_configured = {provider: cloud_providers.get_credentials(provider) is not None for provider in CLOUD_MODEL_TAGS}
    is_cloud = mode in CLOUD_MODEL_TAGS
    ready = (cloud_configured.get(mode, False) if is_cloud else configured if mode == "openai_api"
             else health["service_running"] and health["model_installed"] if mode == "ollama_local" else True)
    model = CLOUD_MODEL_TAGS.get(mode, OPENAI_MODEL_TAG if mode == "openai_api" else MODEL_TAG)
    return {"mode": mode, "model": model,
            "providers": {"openai_api": configured, **cloud_configured},
            "models": {"openai_api": OPENAI_MODEL_TAG, **CLOUD_MODEL_TAGS},
            **health, "openai_configured": configured,
            "openai_model": OPENAI_MODEL_TAG,
            "ready": ready,
            "message": (("Настройки подключены; работа API проверяется только по вашему запросу" if ready else "Сначала настройте выбранный AI-сервис") if is_cloud else
                        "Ключ OpenAI API сохранён; его работу проверим при первом запросе" if configured and mode == "openai_api" else
                        "Для облачного ИИ нужен API-ключ OpenAI" if mode == "openai_api" else
                        "Локальный ИИ готов" if health["model_installed"] else
                        "Ollama работает, но модель qwen3:4b не загружена" if health["service_running"] else
                        "Обычная проверка работает без нейросети")}

@router.post("/key")
def set_key(body: ApiKeyInput, _user: UserAccount = Depends(current_user)):
    try:
        openai_bridge.write_api_key(body.api_key.strip())
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except openai_bridge.SecretStorageUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"configured": True, "message": "Ключ сохранён в хранилище Windows"}

@router.delete("/key")
def delete_key(_user: UserAccount = Depends(current_user)):
    try:
        openai_bridge.erase_api_key()
    except openai_bridge.SecretStorageUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if settings.ai_provider == "openai_api":
        save_ai_preference("heuristic")
        settings.ai_provider = "heuristic"
        settings.ai_model = ""
    return {"configured": False, "message": "Ключ удалён"}

@router.post("/mode")
def switch_mode(body: ChangeMode, _user: UserAccount = Depends(current_user)):
    mode = body.mode or ("ollama_local" if body.enabled else "heuristic")
    if mode == "ollama_local":
        health = probe_ollama()
        if not health["service_running"]:
            raise HTTPException(status_code=409, detail="Сначала установите и запустите Ollama на этом ноутбуке.")
        if not health["model_installed"]:
            raise HTTPException(status_code=409, detail="В Ollama не установлена модель qwen3:4b. Скачайте её перед включением AI.")
    if mode == "openai_api" and not openai_bridge.read_api_key():
        raise HTTPException(status_code=409, detail="Сначала добавьте ключ OpenAI API. Подписка Plus не является API-ключом.")
    if mode in CLOUD_MODEL_TAGS and not cloud_providers.get_credentials(mode):
        raise HTTPException(status_code=409, detail="Сначала добавьте ключ выбранного AI-сервиса")
    try:
        save_ai_preference(mode)
    except OSError:
        raise HTTPException(status_code=500, detail="Не удалось сохранить настройки Vikora")
    settings.ai_provider = mode
    settings.ai_model = MODEL_TAG if mode == "ollama_local" else OPENAI_MODEL_TAG if mode == "openai_api" else CLOUD_MODEL_TAGS.get(mode, "")
    return {"mode": mode, "model": settings.ai_model, "message": "Режим оценки обновлён"}

class CloudCredentials(BaseModel):
    api_key: str = Field(min_length=12, max_length=500)
    folder_id: str | None = Field(default=None, max_length=80)


@router.post("/providers/{provider}/credentials")
def save_cloud_credentials(provider: Literal["deepseek_api", "gigachat_api", "alice_api"],
                           body: CloudCredentials, _user: UserAccount = Depends(current_user)):
    if provider == "alice_api" and (not body.folder_id or not re.fullmatch(r"[a-zA-Z0-9_-]{6,80}", body.folder_id)):
        raise HTTPException(status_code=422, detail="Для Алисы AI нужен корректный Folder ID")
    try:
        cloud_providers.set_credentials(provider, body.api_key.strip(), body.folder_id)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except cloud_providers.SecretStorageUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"configured": True, "provider": provider}


@router.delete("/providers/{provider}/credentials")
def remove_cloud_credentials(provider: Literal["deepseek_api", "gigachat_api", "alice_api"],
                              _user: UserAccount = Depends(current_user)):
    try:
        cloud_providers.delete_credentials(provider)
    except cloud_providers.SecretStorageUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if settings.ai_provider == provider:
        save_ai_preference("heuristic")
        settings.ai_provider = "heuristic"
        settings.ai_model = ""
    return {"configured": False, "provider": provider}


@router.post("/vacancy-draft")
def draft_vacancy(body: VacancyDraftRequest, _user: UserAccount = Depends(current_user)):
    provider = body.provider or settings.ai_provider
    if not body.send_to_cloud and not (provider == "openai_api" and body.send_to_openai):
        raise HTTPException(status_code=422, detail="Подтвердите отправку описания вакансии выбранному AI-сервису")
    if provider == "openai_api":
        if not openai_bridge.read_api_key():
            raise HTTPException(status_code=409, detail="Сначала добавьте ключ OpenAI API")
        fn = lambda: openai_bridge.draft_vacancy_with_api(body.role, body.notes)
    elif provider in CLOUD_MODEL_TAGS:
        if not cloud_providers.get_credentials(provider):
            raise HTTPException(status_code=409, detail="Сначала подключите выбранный AI-сервис")
        fn = lambda: cloud_providers.draft_vacancy(provider, body.role, body.notes)
    else:
        raise HTTPException(status_code=409, detail="Для этой операции выберите облачного AI-провайдера или используйте ChatGPT Plus")
    try:
        return fn()
    except EvaluationFailure as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
