"""Backup/restore controls available only in single-user desktop mode."""
from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path
import tempfile
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.background import BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from app.core.auth import current_user
from app.local_runtime import ask_to_shutdown, data_directory, schedule_restore
from app.models import UserAccount
from app.services.backup import BackupError, MAX_ARCHIVE, create_backup, verify_backup

router = APIRouter(prefix="/api/v1/local", tags=["desktop backups"])


class BackupPayload(BaseModel):
    password: str = Field(min_length=12, max_length=256)


def _temporary_directory():
    folder = data_directory() / "backups" / ".temporary"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


@router.post("/backup")
def download_encrypted_backup(payload: BackupPayload, tasks: BackgroundTasks,
                              _owner: UserAccount = Depends(current_user)):
    temporary = _temporary_directory()
    path = temporary / ("export-" + uuid.uuid4().hex + ".vikora")
    try:
        create_backup(data_directory(), path, payload.password)
        # Don't leave a second, forgotten copy next to the working database.
        tasks.add_task(lambda: path.unlink(missing_ok=True))
        filename = "Vikora_backup_" + datetime.now().strftime("%Y-%m-%d_%H-%M") + ".vikora"
        return FileResponse(path, media_type="application/octet-stream", filename=filename,
                            headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
                            background=tasks)
    except BackupError as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(422, str(exc)) from exc
    except Exception:
        path.unlink(missing_ok=True)
        raise


@router.post("/restore")
async def stage_restore(password: str = Form(...), confirmation: str = Form(...),
                        file: UploadFile = File(...), _owner: UserAccount = Depends(current_user)):
    if confirmation != "ВОССТАНОВИТЬ":
        raise HTTPException(422, "Подтвердите восстановление словом ВОССТАНОВИТЬ")
    if not file.filename or not file.filename.lower().endswith(".vikora"):
        raise HTTPException(415, "Выберите файл резервной копии Vikora (.vikora)")
    temporary = _temporary_directory()
    path = temporary / ("restore-" + uuid.uuid4().hex + ".vikora")
    try:
        total = 0
        with path.open("xb") as output:
            while chunk := await file.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_ARCHIVE:
                    raise HTTPException(413, "Слишком большой файл резервной копии (более 2 ГБ)")
                output.write(chunk)
        result = verify_backup(path, password)
        schedule_restore(path, password)
        if not ask_to_shutdown():
            from app.local_runtime import cancel_restore
            cancel_restore()
            raise HTTPException(503, "Программа не может перезапуститься; восстановление отменено")
        return {"status": "scheduled", "message": "Копия проверена. Vikora завершает работу и восстановит данные. Затем запустите Vikora снова.", **result}
    except BackupError as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(422, str(exc)) from exc
    except Exception:
        # Do not keep an unverified copy after any error.
        from app.local_runtime import cancel_restore
        cancel_restore()
        path.unlink(missing_ok=True)
        raise
    finally:
        await file.close()


@router.post("/verify-backup")
async def check_backup(password: str = Form(...), file: UploadFile = File(...),
                       _owner: UserAccount = Depends(current_user)):
    """Checks uploaded .vikora and all attachment hashes without modifying data."""
    if not file.filename or not file.filename.lower().endswith(".vikora"):
        raise HTTPException(415, "Выберите файл .vikora")
    path = _temporary_directory() / ("verify-" + uuid.uuid4().hex + ".vikora")
    try:
        size = 0
        with path.open("xb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_ARCHIVE:
                    raise HTTPException(413, "Файл превышает 2 ГБ")
                output.write(chunk)
        return {"status": "valid", **verify_backup(path, password)}
    except BackupError as exc:
        raise HTTPException(422, str(exc)) from exc
    finally:
        path.unlink(missing_ok=True)
        await file.close()
