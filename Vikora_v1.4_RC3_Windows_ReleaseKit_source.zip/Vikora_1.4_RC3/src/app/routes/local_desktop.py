"""Personal desktop controls; mounted only in AUTH_MODE=local."""
from fastapi import APIRouter, Depends, HTTPException
from app.core.auth import current_user
from app.models import UserAccount
from app.local_runtime import ask_to_shutdown

router = APIRouter(prefix="/api/v1/local", tags=["desktop"])


@router.post("/quit")
def quit_local_app(_user: UserAccount = Depends(current_user)):
    if not ask_to_shutdown():
        raise HTTPException(503, "Desktop shutdown is not configured")
    return {"message": "Vikora is closing. You may close the browser tab."}
