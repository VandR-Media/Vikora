"""Admin-only lifecycle endpoints: GDPR-like workflows require human verification."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.auth import current_user
from app.core.config import settings
from app.db import get_db
from app.models import AuditEvent, Candidate, UserAccount
from app.services.privacy import (
    CandidateMissing, receipt_status, retention_overview,
    schedule_candidate_purge, try_cleanup_request, utcnow,
)

router = APIRouter(prefix="/api/v1/privacy", tags=["privacy lifecycle"])


class RetentionUpdate(BaseModel):
    days: int = Field(ge=0, le=3650)


class RetentionOut(BaseModel):
    candidate_id: uuid.UUID
    retention_until: datetime


class PurgeStatusOut(BaseModel):
    request_id: uuid.UUID
    state: Literal["completed", "cleanup_pending"]
    reason: str
    applications_removed: int
    resumes_removed: int
    evaluations_removed: int
    audit_events_redacted: int
    files_pending: int
    files_with_retry: int
    created_at: datetime
    finished_at: datetime | None


class PrivacyOverview(BaseModel):
    expired_candidates: int
    missing_retention_deadline: int
    expiring_30_days: int
    pending_file_cleanup: int
    file_cleanup_errors: int


def admin_only(user: UserAccount = Depends(current_user)) -> UserAccount:
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Administrator rights required")
    return user


@router.get("/overview", response_model=PrivacyOverview)
def overview(db: Session = Depends(get_db), user: UserAccount = Depends(admin_only)):
    return retention_overview(db)


@router.patch("/candidates/{candidate_id}/retention", response_model=RetentionOut)
def change_retention(candidate_id: uuid.UUID, payload: RetentionUpdate,
                     db: Session = Depends(get_db), user: UserAccount = Depends(admin_only)):
    if payload.days > settings.max_retention_days:
        raise HTTPException(status_code=422, detail="Retention period exceeds policy maximum")
    candidate = db.scalar(select(Candidate).where(Candidate.id == candidate_id).with_for_update())
    if candidate is None:
        raise HTTPException(status_code=404, detail="Candidate not found")
    candidate.retention_until = utcnow() + timedelta(days=payload.days)
    db.add(AuditEvent(actor_id=user.id, action="privacy.retention.changed",
                      entity_type="candidate", entity_id=candidate.id,
                      details={"days": payload.days}))
    db.commit()
    return {"candidate_id": candidate.id, "retention_until": candidate.retention_until.replace(tzinfo=timezone.utc) if candidate.retention_until.tzinfo is None else candidate.retention_until}


@router.delete("/candidates/{candidate_id}", response_model=PurgeStatusOut, status_code=202)
def delete_candidate(candidate_id: uuid.UUID,
                     reason: Literal["administrative", "privacy_request", "duplicate"] = Query(default="administrative"),
                     confirmation: uuid.UUID = Header(alias="X-Confirm-Candidate-Id"),
                     db: Session = Depends(get_db), user: UserAccount = Depends(admin_only)):
    if confirmation != candidate_id:
        raise HTTPException(status_code=400, detail="Candidate ID confirmation mismatch")
    try:
        request_id = schedule_candidate_purge(db, candidate_id, actor_id=user.id, reason=reason)
    except CandidateMissing as exc:
        raise HTTPException(status_code=404, detail="Candidate not found") from exc
    # Best effort; if a filesystem call fails the outbox remains and worker retries.
    try_cleanup_request(db, request_id)
    return receipt_status(db, request_id)


@router.get("/purge-requests/{request_id}", response_model=PurgeStatusOut)
def get_purge_request(request_id: uuid.UUID, db: Session = Depends(get_db),
                      user: UserAccount = Depends(admin_only)):
    status = receipt_status(db, request_id)
    if status is None:
        raise HTTPException(status_code=404, detail="Purge receipt not found")
    return status
