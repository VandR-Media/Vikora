"""Read-only identity endpoint. The database, not bearer claims, defines permissions."""
import uuid

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.auth import current_user
from app.models import UserAccount

router = APIRouter(prefix="/api/v1", tags=["account"])


class CurrentUserOut(BaseModel):
    id: uuid.UUID
    full_name: str
    email: str
    role: str


@router.get("/me", response_model=CurrentUserOut)
def me(user: UserAccount = Depends(current_user)):
    return CurrentUserOut(id=user.id, full_name=user.full_name, email=user.email, role=user.role)
