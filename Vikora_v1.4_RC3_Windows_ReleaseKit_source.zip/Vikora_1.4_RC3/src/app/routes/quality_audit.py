"""Local-only, synthetic-only AI quality benchmark API."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.core.auth import current_user
from app.models import UserAccount
from app.services import quality_audit

router = APIRouter(prefix='/api/v1/local/quality', tags=['synthetic AI quality checks'])


class AuditRequest(BaseModel):
    provider: str = Field(max_length=30)
    case_ids: list[str] = Field(min_length=1, max_length=24)
    confirm_paid_cloud_test: bool = False


@router.get('/cases')
def cases(_user: UserAccount = Depends(current_user)):
    return {"version": quality_audit.DATASET_VERSION,
            "cases": [{"id": case['id'], "label": case['label']} for case in quality_audit.read_synthetic_cases()],
            "note": "Только вымышленные резюме; проверка не обращается к вашей базе кандидатов."}


@router.post('/runs', status_code=202)
def start(payload: AuditRequest, _user: UserAccount = Depends(current_user)):
    try:
        return quality_audit.begin_run(payload.provider, payload.case_ids,
                                       confirmed_cloud=payload.confirm_paid_cloud_test)
    except PermissionError as exc:
        raise HTTPException(403, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(409, str(exc)) from exc


@router.get('/runs/current')
def current(_user: UserAccount = Depends(current_user)):
    return quality_audit.run_status()


@router.get('/runs')
def list_reports(_user: UserAccount = Depends(current_user)):
    return {"reports": quality_audit.recent_reports()}


@router.get('/runs/{run_id}')
def get_run(run_id: str, _user: UserAccount = Depends(current_user)):
    report = quality_audit.get_report(run_id)
    if report is None:
        raise HTTPException(404, 'Отчёт не найден')
    return report
