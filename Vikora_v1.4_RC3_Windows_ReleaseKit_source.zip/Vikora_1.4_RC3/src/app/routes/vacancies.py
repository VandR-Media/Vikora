import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.auth import current_user
from app.core.permissions import require_editor, require_vacancy
from app.db import get_db
from app.models import UserAccount, Vacancy, VacancyAccess, VacancyCriterion, AuditEvent
from app.schemas import VacancyCreate, VacancyOut, VacancyPatch

router = APIRouter(prefix="/api/v1/vacancies", tags=["vacancies"])


def _new_criteria(items):
    return [VacancyCriterion(**item.model_dump(mode="json")) for item in items]


@router.post("", response_model=VacancyOut, status_code=status.HTTP_201_CREATED)
def create_vacancy(payload: VacancyCreate, db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    vacancy = Vacancy(
        **payload.model_dump(exclude={"criteria"}, mode="json"),
        owner_id=user.id,
        criteria=_new_criteria(payload.criteria),
    )
    db.add(vacancy)
    db.flush()
    db.add(AuditEvent(actor_id=user.id, action="vacancy.created", entity_type="vacancy", entity_id=vacancy.id))
    db.commit()
    db.refresh(vacancy)
    return vacancy


@router.get("", response_model=list[VacancyOut])
def list_vacancies(
    limit: int = Query(30, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    user: UserAccount = Depends(current_user),
):
    query = select(Vacancy)
    if user.role != "admin":
        query = query.where(or_(
            Vacancy.owner_id == user.id,
            Vacancy.id.in_(select(VacancyAccess.vacancy_id).where(VacancyAccess.user_id == user.id)),
        ))
    return db.scalars(query.order_by(Vacancy.created_at.desc(), Vacancy.id).offset(offset).limit(limit)).all()


@router.get("/{vacancy_id}", response_model=VacancyOut)
def get_vacancy(vacancy_id: uuid.UUID, db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    return require_vacancy(db, vacancy_id, user)


@router.patch("/{vacancy_id}", response_model=VacancyOut)
def edit_vacancy(vacancy_id: uuid.UUID, payload: VacancyPatch, db: Session = Depends(get_db), user: UserAccount = Depends(current_user)):
    require_editor(user)
    vacancy = require_vacancy(db, vacancy_id, user, edit=True)
    changes = payload.model_dump(exclude_unset=True, exclude={"criteria"}, mode="json")
    for key, value in changes.items():
        setattr(vacancy, key, value)
    if "criteria" in payload.model_fields_set:
        # Preserve stable criterion rows when the user changes weight/description.
        # Replacing every row used to violate (vacancy_id, key) UNIQUE on SQLite
        # because inserts were flushed before delete-orphans.
        old = {item.key: item for item in vacancy.criteria}
        new_items = []
        for entry in payload.criteria or []:
            row = old.pop(entry.key, None)
            if row is None:
                row = VacancyCriterion(**entry.model_dump(mode="json"))
            else:
                for key, value in entry.model_dump(mode="json").items():
                    setattr(row, key, value)
            new_items.append(row)
        for obsolete in old.values():
            db.delete(obsolete)
        if old:
            db.flush()
        vacancy.criteria = new_items
    db.add(AuditEvent(actor_id=user.id, action="vacancy.updated", entity_type="vacancy", entity_id=vacancy.id))
    db.commit()
    db.refresh(vacancy)
    return vacancy
