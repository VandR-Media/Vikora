import uuid
from datetime import datetime, timezone
from enum import Enum
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class VacancyStatus(str, Enum):
    draft = "draft"
    open = "open"
    paused = "paused"
    closed = "closed"


class Importance(str, Enum):
    must = "must"
    nice = "nice"


class CriterionIn(BaseModel):
    key: str = Field(min_length=2, max_length=80, pattern=r"^[a-z][a-z0-9_]*$")
    label: str = Field(min_length=2, max_length=255)
    description: str | None = Field(default=None, max_length=3000)
    importance: Importance = Importance.nice
    weight: int = Field(default=5, ge=1, le=10)
    sort_order: int = Field(default=0, ge=0)


class VacancyCreate(BaseModel):
    title: str = Field(min_length=3, max_length=255)
    description: str = Field(min_length=10, max_length=30000)
    department: str | None = Field(default=None, max_length=120)
    location: str | None = Field(default=None, max_length=180)
    status: VacancyStatus = VacancyStatus.draft
    criteria: list[CriterionIn] = Field(default_factory=list, max_length=50)

    @model_validator(mode="after")
    def unique_keys(self):
        keys = [c.key for c in self.criteria]
        if len(keys) != len(set(keys)):
            raise ValueError("Criterion keys must be unique within a vacancy")
        return self


class VacancyPatch(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=255)
    description: str | None = Field(default=None, min_length=10, max_length=30000)
    department: str | None = Field(default=None, max_length=120)
    location: str | None = Field(default=None, max_length=180)
    status: VacancyStatus | None = None
    criteria: list[CriterionIn] | None = Field(default=None, max_length=50)

    @model_validator(mode="after")
    def unique_keys(self):
        for required in ("title", "description", "status", "criteria"):
            if required in self.model_fields_set and getattr(self, required) is None:
                raise ValueError(f"{required} cannot be null")
        if self.criteria is not None:
            keys = [c.key for c in self.criteria]
            if len(keys) != len(set(keys)):
                raise ValueError("Criterion keys must be unique within a vacancy")
        return self


class CriterionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    key: str
    label: str
    description: str | None
    importance: Importance
    weight: int
    sort_order: int


class VacancyOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    title: str
    description: str
    department: str | None
    location: str | None
    status: VacancyStatus
    created_at: datetime
    updated_at: datetime
    criteria: list[CriterionOut]


class CandidateCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=255)
    email: str | None = Field(default=None, max_length=320)
    phone: str | None = Field(default=None, max_length=50)
    source: str = Field(default="manual", max_length=50)
    source_external_id: str | None = Field(default=None, max_length=255)
    data_source_note: str | None = Field(default=None, max_length=2000)


class CandidateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    full_name: str
    email: str | None
    phone: str | None
    source: str
    created_at: datetime
    retention_until: datetime | None

    @field_validator("retention_until", mode="after")
    @classmethod
    def normalize_retention_timezone(cls, value):
        return value.replace(tzinfo=timezone.utc) if value is not None and value.tzinfo is None else value


class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    vacancy_id: uuid.UUID
    candidate_id: uuid.UUID
    stage: str
    created_at: datetime
    candidate: CandidateOut


class ApplicationStagePatch(BaseModel):
    stage: str = Field(pattern="^(new|review|interview|offer|hired|rejected)$")


class ResumeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    candidate_id: uuid.UUID
    original_filename: str
    mime_type: str
    sha256: str
    parse_status: str
    created_at: datetime


class ResumeParsedText(BaseModel):
    resume_id: uuid.UUID
    parse_status: str
    # Expose extracted text only through this explicitly authenticated, vacancy-scoped API.
    pages: list[dict] | None
