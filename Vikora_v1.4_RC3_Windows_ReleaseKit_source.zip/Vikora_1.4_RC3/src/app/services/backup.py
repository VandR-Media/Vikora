"""Encrypted, verified, single-user SQLite + resume backup for desktop Vikora.

A .vikora file is an AES-256-GCM encrypted ZIP. Only authenticated plaintext
is trusted. No third-party servers or passwords stored on disk. Snapshotting
uses SQLite's online backup API; files are matched to the snapshot by SHA256.
"""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import closing
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile
import uuid
import zipfile

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"VIKORA8\x00"
SALT_BYTES = 16
NONCE_BYTES = 12
TAG_BYTES = 16
KEY_COST = 2**14
MAX_ARCHIVE = 2 * 1024**3
MAX_UNPACKED = 3 * 1024**3
MAX_ENTRIES = 25000
MAX_DB = 1024**3
KEY_PATTERN = re.compile(r"^[0-9a-f]{2}/[0-9a-f]{32}$")


class BackupError(ValueError):
    """User-facing error with no private database content."""


def _password_check(password: str) -> None:
    if not isinstance(password, str) or len(password) < 12 or len(password) > 256:
        raise BackupError("Пароль резервной копии должен содержать от 12 до 256 символов")


def _key(password: str, salt: bytes) -> bytes:
    return Scrypt(salt=salt, length=32, n=KEY_COST, r=8, p=1).derive(password.encode("utf-8"))


def _sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class _EncryptedOutput:
    """Non-seekable stream consumed by zipfile; never stores plaintext ZIP."""
    def __init__(self, target, encryptor):
        self.target = target
        self.encryptor = encryptor
        self.count = 0
    def write(self, buf):
        data = bytes(buf)
        self.target.write(self.encryptor.update(data))
        self.count += len(data)
        return len(data)
    def flush(self):
        self.target.flush()


def _sqlite_snapshot(db_path: Path, destination: Path) -> list[tuple[str, str]]:
    if not db_path.is_file():
        raise BackupError("Локальная база Vikora не найдена")
    with closing(sqlite3.connect(str(db_path), timeout=20)) as source:
        with closing(sqlite3.connect(str(destination))) as snapshot:
            source.backup(snapshot, pages=500, sleep=0.1)
            result = snapshot.execute("PRAGMA quick_check").fetchone()
            if result != ("ok",):
                raise BackupError("Проверка базы данных не прошла")
            rows = snapshot.execute("SELECT storage_key, sha256 FROM resumes").fetchall()
    return rows


def create_backup(root: Path, target: Path, password: str) -> dict:
    """Create .vikora at target atomically. Caller cleans target when temporary."""
    _password_check(password)
    root = root.resolve()
    target = target.resolve()
    files_root = (root / "files").resolve()
    if target.parent == files_root or files_root in target.parents:
        raise BackupError("Резервная копия не должна находиться среди резюме")
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_output = target.with_name("." + target.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with tempfile.TemporaryDirectory(prefix="vikora-snapshot-") as scratch:
            snapshot = Path(scratch) / "snapshot.sqlite3"
            rows = _sqlite_snapshot(root / "vikora.sqlite3", snapshot)
            if snapshot.stat().st_size > MAX_DB:
                raise BackupError("База превышает ограничение размера резервной копии")
            expected = {}
            for storage_key, digest in rows:
                if not KEY_PATTERN.fullmatch(storage_key or ""):
                    raise BackupError("Некорректный путь к резюме в базе")
                if not re.fullmatch(r"[a-f0-9]{64}", digest or ""):
                    raise BackupError("Некорректная контрольная сумма резюме в базе")
                if storage_key in expected and expected[storage_key] != digest:
                    raise BackupError("Противоречивые контрольные суммы файла")
                expected[storage_key] = digest
            if len(expected) > MAX_ENTRIES - 2:
                raise BackupError("Слишком много файлов для одной копии")
            manifest = {
                "format": 1,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "database": _sha_file(snapshot),
                "files": dict(sorted(expected.items())),
            }
            salt = os.urandom(SALT_BYTES)
            nonce = os.urandom(NONCE_BYTES)
            header = MAGIC + salt + nonce
            encryptor = Cipher(algorithms.AES(_key(password, salt)), modes.GCM(nonce)).encryptor()
            encryptor.authenticate_additional_data(header)
            with temp_output.open("xb") as encrypted:
                encrypted.write(header)
                sink = _EncryptedOutput(encrypted, encryptor)
                with zipfile.ZipFile(sink, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=4, allowZip64=True) as archive:
                    archive.write(snapshot, "data.sqlite3")
                    for storage_key, digest in expected.items():
                        path = files_root / storage_key
                        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(files_root):
                            raise BackupError("Одно из резюме отсутствует или путь небезопасен; попробуйте повторить копирование")
                        if _sha_file(path) != digest:
                            raise BackupError("Файл резюме изменился или повреждён; копирование отменено")
                        archive.write(path, f"files/{storage_key}")
                    archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, separators=(",", ":")))
                encrypted.write(encryptor.finalize())
                encrypted.write(encryptor.tag)
                encrypted.flush()
                os.fsync(encrypted.fileno())
            if temp_output.stat().st_size > MAX_ARCHIVE:
                raise BackupError("Резервная копия превышает лимит 2 ГБ")
            # Self-test the produced ciphertext and every saved attachment before
            # presenting the download as successful.
            verify_backup(temp_output, password)
            os.replace(temp_output, target)
            return {"files": len(expected), "created_at": manifest["created_at"], "size_bytes": target.stat().st_size}
    except Exception:
        temp_output.unlink(missing_ok=True)
        raise


def _decrypt_to_temp(encrypted_path: Path, plain_path: Path, password: str) -> None:
    _password_check(password)
    encrypted_path = encrypted_path.resolve()
    total = encrypted_path.stat().st_size
    header_len = len(MAGIC) + SALT_BYTES + NONCE_BYTES
    if total < header_len + TAG_BYTES or total > MAX_ARCHIVE:
        raise BackupError("Файл копии повреждён или превышает 2 ГБ")
    with encrypted_path.open("rb") as source:
        header = source.read(header_len)
        if not header.startswith(MAGIC):
            raise BackupError("Это не файл резервной копии Vikora v0.8")
        salt = header[len(MAGIC):len(MAGIC)+SALT_BYTES]
        nonce = header[-NONCE_BYTES:]
        source.seek(-TAG_BYTES, os.SEEK_END)
        tag = source.read(TAG_BYTES)
        decryptor = Cipher(algorithms.AES(_key(password, salt)), modes.GCM(nonce, tag)).decryptor()
        decryptor.authenticate_additional_data(header)
        source.seek(header_len)
        remaining = total - header_len - TAG_BYTES
        try:
            with plain_path.open("xb") as plain:
                while remaining:
                    chunk = source.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise BackupError("Файл копии обрезан")
                    plain.write(decryptor.update(chunk))
                    remaining -= len(chunk)
                plain.write(decryptor.finalize())
        except InvalidTag as exc:
            plain_path.unlink(missing_ok=True)
            raise BackupError("Неверный пароль или повреждена резервная копия") from exc


def _check_zip(plain_zip: Path) -> dict:
    try:
        with zipfile.ZipFile(plain_zip, "r") as archive:
            infos = archive.infolist()
            if len(infos) > MAX_ENTRIES or sum(i.file_size for i in infos) > MAX_UNPACKED:
                raise BackupError("Слишком большая или подозрительная копия")
            names = [i.filename for i in infos]
            if len(names) != len(set(names)) or "data.sqlite3" not in names or "manifest.json" not in names:
                raise BackupError("Отсутствуют обязательные части резервной копии")
            if any(n not in {"data.sqlite3", "manifest.json"} and not (n.startswith("files/") and KEY_PATTERN.fullmatch(n[6:])) for n in names):
                raise BackupError("В копии есть недопустимые пути")
            if any(i.is_dir() or ((i.external_attr >> 16) & 0o170000) == 0o120000 for i in infos):
                raise BackupError("Копия содержит ссылки или папки вместо документов")
            if archive.getinfo("manifest.json").file_size > 4 * 1024 * 1024 or archive.getinfo("data.sqlite3").file_size > MAX_DB:
                raise BackupError("Некорректный размер служебных файлов")
            manifest = json.loads(archive.read("manifest.json"))
            if (manifest.get("format") != 1 or not isinstance(manifest.get("files"), dict)
                    or not re.fullmatch(r"[a-f0-9]{64}", manifest.get("database", ""))
                    or not isinstance(manifest.get("created_at"), str)):
                raise BackupError("Неподдерживаемый формат резервной копии")
            paths = set(names) - {"data.sqlite3", "manifest.json"}
            if paths != {"files/" + k for k in manifest["files"]}:
                raise BackupError("Файлы и перечень резюме не совпадают")
            for key, digest in manifest["files"].items():
                if not KEY_PATTERN.fullmatch(key) or not re.fullmatch(r"[a-f0-9]{64}", digest):
                    raise BackupError("Некорректные имена или контрольные суммы")
            return manifest
    except (zipfile.BadZipFile, UnicodeError, json.JSONDecodeError, KeyError, TypeError, OverflowError) as exc:
        raise BackupError("Архив резервной копии повреждён") from exc


def verify_backup(encrypted_path: Path, password: str) -> dict:
    """Authenticate, inspect, and check all hashes; does not change user data."""
    with tempfile.TemporaryDirectory(prefix="vikora-verify-") as tmp:
        plain = Path(tmp) / "backup.zip"
        _decrypt_to_temp(encrypted_path, plain, password)
        manifest = _check_zip(plain)
        with zipfile.ZipFile(plain) as archive:
            for name, expected in [("data.sqlite3", manifest["database"])] + [("files/" + name, digest) for name, digest in manifest["files"].items()]:
                digest = hashlib.sha256()
                with archive.open(name) as part:
                    for block in iter(lambda: part.read(1024 * 1024), b""):
                        digest.update(block)
                if digest.hexdigest() != expected:
                    raise BackupError("Проверка контрольной суммы не прошла")
            dbfile = Path(tmp) / "verify.sqlite3"
            with archive.open("data.sqlite3") as data, dbfile.open("wb") as dest:
                shutil.copyfileobj(data, dest, 1024 * 1024)
            with closing(sqlite3.connect(f"file:{dbfile}?mode=ro", uri=True)) as con:
                required_tables = {"user_accounts", "vacancies", "vacancy_criteria", "candidates", "resumes", "applications", "evaluations", "criterion_evaluations", "audit_events", "purge_requests", "purge_blobs", "vacancy_access", "web_sessions", "oidc_login_attempts"}
                existing = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not required_tables.issubset(existing):
                    raise BackupError("В копии нет обязательных таблиц Vikora")
                if con.execute("PRAGMA quick_check").fetchone() != ("ok",):
                    raise BackupError("База в копии повреждена")
                rows = con.execute("SELECT storage_key, sha256 FROM resumes").fetchall()
                if {key: digest for key, digest in rows} != manifest["files"]:
                    raise BackupError("Резюме в базе и в архиве не совпадают")
        return {"files": len(manifest["files"]), "created_at": manifest["created_at"]}


def restore_offline(root: Path, encrypted_path: Path, password: str) -> dict:
    """Called ONLY after local server has exited and workers have stopped.

    Maintains an encrypted pre-restore backup and a rollback directory until
    file/db replacement is complete. Never blindly extracts ZIP names.
    """
    root = root.resolve()
    # Verify first, before touching current files.
    summary = verify_backup(encrypted_path, password)
    with tempfile.TemporaryDirectory(prefix=".vikora-restore-", dir=root) as scratch:
        staging = Path(scratch)
        plain = staging / "plaintext.zip"
        _decrypt_to_temp(encrypted_path, plain, password)
        manifest = _check_zip(plain)
        new_root = staging / "new"
        new_files = new_root / "files"
        new_files.mkdir(parents=True)
        new_db = new_root / "vikora.sqlite3"
        with zipfile.ZipFile(plain) as archive:
            with archive.open("data.sqlite3") as src, new_db.open("wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
            for key in manifest["files"]:
                destination = new_files / key
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(f"files/{key}") as src, destination.open("wb") as dst:
                    shutil.copyfileobj(src, dst, 1024 * 1024)
        # Emergency backup holds original data, encrypted with the same password.
        backups = root / "backups"
        backups.mkdir(exist_ok=True)
        emergency = backups / ("Before_restore_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6] + ".vikora")
        create_backup(root, emergency, password)
        old_db = root / "vikora.sqlite3"
        old_files = root / "files"
        # These WAL files may contain earlier user data. Checkpoint before swap.
        with closing(sqlite3.connect(str(old_db))) as con:
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        rollback = staging / "old"
        rollback.mkdir()
        swapped = []
        try:
            for name in ("vikora.sqlite3", "files"):
                old = root / name
                old_saved = rollback / name
                new = new_root / name
                if old.exists():
                    os.replace(old, old_saved)
                    swapped.append((old_saved, old))
                os.replace(new, old)
        except Exception:
            for name in ("files", "vikora.sqlite3"):
                final = root / name
                if final.exists():
                    if final.is_dir():
                        shutil.rmtree(final)
                    else:
                        final.unlink()
            for saved, original in reversed(swapped):
                if saved.exists():
                    os.replace(saved, original)
            raise
        # Wal/shm files from old DB must not be applied to restored DB.
        for suffix in ("-wal", "-shm"):
            (root / ("vikora.sqlite3" + suffix)).unlink(missing_ok=True)
        return {**summary, "emergency_backup": str(emergency)}
