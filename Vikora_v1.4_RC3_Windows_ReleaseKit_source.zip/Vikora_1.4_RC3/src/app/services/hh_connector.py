"""Read-only HeadHunter API connector for a single-user desktop application.

No resume search, contact-unlocking, messages, or employer-state mutations.
The API is accessed only after the user explicitly starts an import.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import re
import secrets
from urllib.parse import urlsplit, urlencode
import httpx
try:
    import keyring
except ImportError:  # test environments without Windows Credential Manager integration
    keyring = None

BASE = 'https://api.hh.ru'
AUTH_URL = 'https://hh.ru/oauth/authorize'
TOKEN_URL = 'https://hh.ru/oauth/token'
SERVICE = 'Vikora.HeadHunter'
MAX_ITEMS = 50
MAX_RESPONSE = 3 * 1024 * 1024
_pending: dict[str, datetime] = {}


class HHError(Exception):
    def __init__(self, message, status=502):
        super().__init__(message)
        self.status = status


def _read_secret(key: str) -> str | None:
    try:
        return keyring.get_password(SERVICE, key)
    except Exception as exc:
        raise HHError('Недоступно защищённое хранилище Windows. Подключение hh.ru невозможно.', 503) from exc


def _write_secret(key: str, value: str) -> None:
    try:
        keyring.set_password(SERVICE, key, value)
    except Exception as exc:
        raise HHError('Не удалось сохранить настройки hh.ru в хранилище Windows.', 503) from exc


def _delete_secret(key: str) -> None:
    try:
        keyring.delete_password(SERVICE, key)
    except Exception as exc:
        if keyring is not None and isinstance(exc, keyring.errors.PasswordDeleteError):
            return
        raise HHError('Не удалось удалить настройку hh.ru.', 503) from exc


def get_config() -> dict:
    raw = _read_secret('client_config')
    return json.loads(raw) if raw else {}


def save_config(client_id: str, client_secret: str, contact_email: str, port: int) -> None:
    if not re.fullmatch(r'[A-Za-z0-9_-]{8,128}', client_id):
        raise HHError('Неверный Client ID приложения hh.ru', 422)
    if not 12 <= len(client_secret) <= 256 or '\n' in client_secret:
        raise HHError('Неверный Client Secret приложения hh.ru', 422)
    if not re.fullmatch(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}', contact_email):
        raise HHError('Укажите действительный контактный email приложения.', 422)
    if not 1024 <= port <= 65535:
        raise HHError('Недопустимый локальный порт.', 422)
    _write_secret('client_config', json.dumps({'client_id':client_id,'client_secret':client_secret,
         'contact_email':contact_email, 'redirect_uri':f'http://127.0.0.1:{port}/api/v1/local/hh/oauth/callback'}))
    # A changed client configuration invalidates old OAuth tokens. Never reuse a
    # token obtained for a different registered application or redirect URI.
    _delete_secret('oauth_tokens')


def remove_connection() -> None:
    for key in ('client_config', 'oauth_tokens'):
        _delete_secret(key)
    _pending.clear()


def create_authorization_url() -> str:
    config = get_config()
    if not config:
        raise HHError('Сначала настройте приложение hh.ru.', 409)
    state = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    # Purge expired states. A state can be redeemed exactly once.
    for key, until in list(_pending.items()):
        if until < now:
            _pending.pop(key, None)
    _pending[state] = now + timedelta(minutes=8)
    return AUTH_URL + '?' + urlencode({'response_type':'code', 'client_id':config['client_id'],
                            'redirect_uri':config['redirect_uri'], 'state':state})


def take_state(value: str) -> None:
    expiry = _pending.pop(value, None)
    if expiry is None or expiry < datetime.now(timezone.utc):
        raise HHError('Ссылка подключения истекла или уже использовалась. Начните подключение заново.', 400)


def _post_tokens(data: dict) -> dict:
    try:
        with httpx.Client(timeout=20.0, follow_redirects=False, trust_env=False) as client:
            response = client.post(TOKEN_URL, data=data, headers={'Accept':'application/json'})
        if response.status_code != 200:
            raise HHError('hh.ru не предоставил доступ. Проверьте разрешения приложения и попробуйте снова.', 401)
        payload = response.json()
    except HHError:
        raise
    except (httpx.HTTPError, ValueError) as exc:
        raise HHError('Не удалось подключиться к hh.ru. Проверьте интернет и повторите попытку.') from exc
    if not isinstance(payload, dict) or not isinstance(payload.get('access_token'), str):
        raise HHError('hh.ru вернул некорректный ответ авторизации.')
    payload['expires_at'] = (datetime.now(timezone.utc) + timedelta(seconds=max(60,int(payload.get('expires_in', 3600))))).isoformat()
    _write_secret('oauth_tokens', json.dumps(payload))
    return payload


def exchange_code(code: str, state: str) -> None:
    take_state(state)
    config = get_config()
    if not config or not code or len(code)>2048:
        raise HHError('Ссылка входа недействительна.', 400)
    _post_tokens({'grant_type':'authorization_code', 'client_id':config['client_id'],
                  'client_secret':config['client_secret'], 'code':code,
                  'redirect_uri':config['redirect_uri']})
    try:
        account = api_get('/me')
        if not isinstance(account.get('employer'), dict) or not account['employer'].get('id'):
            _delete_secret('oauth_tokens')
            raise HHError('Вход выполнен не через профиль работодателя. Для импорта откликов нужен доступ работодателя.', 403)
    except Exception:
        _delete_secret('oauth_tokens')
        raise


def _access_token() -> str:
    raw = _read_secret('oauth_tokens')
    if not raw:
        raise HHError('Сначала нажмите «Подключить hh.ru».', 409)
    token = json.loads(raw)
    expires = datetime.fromisoformat(token['expires_at'])
    if expires > datetime.now(timezone.utc) + timedelta(seconds=60):
        return token['access_token']
    config = get_config()
    if not token.get('refresh_token') or not config:
        raise HHError('Срок доступа истёк. Подключите hh.ru повторно.', 401)
    fresh = _post_tokens({'grant_type':'refresh_token', 'refresh_token':token['refresh_token'],
                         'client_id':config['client_id'], 'client_secret':config['client_secret']})
    return fresh['access_token']


def _checked_url(path_or_url: str, allowed_prefixes: tuple[str,...]) -> str:
    if path_or_url.startswith('/') and not path_or_url.startswith('//'):
        path_or_url = BASE + path_or_url
    parsed = urlsplit(path_or_url)
    if (parsed.scheme != 'https' or parsed.hostname != 'api.hh.ru' or parsed.port not in (None,443)
        or parsed.username or parsed.password or parsed.fragment):
        raise HHError('Небезопасный адрес hh.ru отклонён.', 422)
    # No traversal, encoded slashes, host changes, or surprise endpoints from API responses.
    if ('..' in parsed.path or '%' in parsed.path or '\\' in parsed.path
        or not any(parsed.path == p or parsed.path.startswith(p+'/') for p in allowed_prefixes)):
        raise HHError('Неожиданный адрес API hh.ru отклонён.', 422)
    if len(parsed.query)>1500:
        raise HHError('Слишком длинный адрес API.', 422)
    return path_or_url


def api_get(path_or_url: str, params: dict | None=None, *, prefixes=('/me','/employers','/negotiations','/resumes')) -> dict:
    target = _checked_url(path_or_url, prefixes)
    config = get_config()
    if not config:
        raise HHError('Сначала настройте hh.ru.', 409)
    headers = {'Authorization': 'Bearer ' + _access_token(),
               'HH-User-Agent': f"Vikora/1.3 ({config['contact_email']})", 'Accept':'application/json'}
    try:
        with httpx.Client(timeout=25.0, follow_redirects=False, trust_env=False) as client:
            with client.stream('GET', target, params=params, headers=headers) as response:
                if response.status_code in (401, 403):
                    raise HHError('hh.ru не разрешает этот запрос. Проверьте доступ работодателя и тариф.', response.status_code)
                if response.status_code == 429:
                    raise HHError('hh.ru ограничил частоту запросов. Повторите позже.', 429)
                if response.status_code != 200:
                    raise HHError(f'Ответ hh.ru: HTTP {response.status_code}', 502)
                content = bytearray()
                for chunk in response.iter_bytes():
                    content.extend(chunk)
                    if len(content)>MAX_RESPONSE:
                        raise HHError('Слишком большой ответ от hh.ru.')
        data = json.loads(content)
        if not isinstance(data, dict):
            raise ValueError('Expected JSON object')
        return data
    except HHError:
        raise
    except (httpx.HTTPError, ValueError) as exc:
        raise HHError('Ошибка получения данных hh.ru. Проверьте интернет и повторите попытку.') from exc


def get_account() -> dict:
    return api_get('/me')


def list_vacancies() -> list[dict]:
    profile = get_account()
    employer = profile.get('employer') or {}
    employer_id = str(employer.get('id') or '')
    if not employer_id.isdecimal():
        raise HHError('У аккаунта нет доступного работодателя.', 403)
    result = api_get(f'/employers/{employer_id}/vacancies/active', {'page':0,'per_page':50})
    return [{'id':str(item.get('id')), 'name':str(item.get('name',''))[:255]}
            for item in result.get('items', []) if isinstance(item,dict) and str(item.get('id','')).isdecimal()][:50]


def list_collections(hh_vacancy_id: str) -> list[dict]:
    if not hh_vacancy_id.isdecimal():
        raise HHError('Неверный идентификатор вакансии hh.ru.', 422)
    result = api_get('/negotiations', {'vacancy_id':hh_vacancy_id})
    collections=[]
    for item in result.get('collections', []):
        if not isinstance(item,dict):
            continue
        url = str(item.get('url') or '')
        # Validate before including in the user's choices.
        try:
            _checked_url(url, ('/negotiations',))
        except HHError:
            continue
        collections.append({'id':str(item.get('id') or '')[:100],
                            'name':str(item.get('name') or item.get('id') or '')[:150],
                            'url':url})
    return collections[:100]


def list_collection_page(hh_vacancy_id: str, collection_id: str, page: int) -> list[dict]:
    if page<0 or page>2000:
        raise HHError('Неверная страница откликов.', 422)
    collection = next((c for c in list_collections(hh_vacancy_id) if c['id']==collection_id),None)
    if not collection:
        raise HHError('Выбранная коллекция откликов недоступна.', 404)
    # URL is issued by HH itself and checked against api.hh.ru.
    data = api_get(collection['url'], {'vacancy_id':hh_vacancy_id, 'page':page,'per_page':MAX_ITEMS}, prefixes=('/negotiations',))
    items=[]
    for item in data.get('items',[]):
        if not isinstance(item,dict) or not item.get('id'):
            continue
        resume = item.get('resume') if isinstance(item.get('resume'),dict) else {}
        items.append({'id':str(item['id'])[:100], 'resume_id':str(resume.get('id') or '')[:100],
                      'title':str(resume.get('title') or 'Резюме без названия')[:160],
                      'resume_url':str(resume.get('url') or '')[:1000],
                      'has_resume':bool(resume.get('url'))})
    return items[:MAX_ITEMS]


def resume_to_text(data: dict) -> str:
    """Use job evidence; avoid importing age, gender, birthday, photo and other unnecessary fields."""
    lines=[]
    def add(label, value):
        if isinstance(value,str) and value.strip():
            lines.append(f'{label}: {value.strip()[:3000]}')
    add('Желаемая должность', data.get('title'))
    skills=data.get('skill_set')
    if isinstance(skills, list):
        skills=[x for x in skills if isinstance(x,str)]
        add('Навыки',', '.join(skills)[:4000])
    if isinstance(data.get('skills'),str):
        add('О себе',data['skills'])
    for item in (data.get('experience') or [])[:35]:
        if isinstance(item,dict):
            block='; '.join(str(item.get(k) or '')[:1200] for k in ('company','position','start','end','description') if item.get(k))
            add('Опыт работы',block)
    education=data.get('education') or {}
    if isinstance(education,dict):
        for item in (education.get('primary') or [])[:20]:
            if isinstance(item,dict):
                add('Образование','; '.join(str(item.get(k) or '')[:300] for k in ('name','organization','result','year') if item.get(k)))
    for item in (data.get('language') or [])[:20]:
        if isinstance(item,dict):
            add('Языки', str(item.get('name') or '') + ' ' + str((item.get('level') or {}).get('name') or ''))
    text='\n'.join(lines)[:50000]
    if len(text.strip())<20:
        raise HHError('hh.ru не предоставил достаточно данных для анализа этого резюме.', 422)
    return text


def fetch_resume(url: str) -> tuple[dict,str]:
    data = api_get(url, prefixes=('/resumes',))
    return data, resume_to_text(data)
