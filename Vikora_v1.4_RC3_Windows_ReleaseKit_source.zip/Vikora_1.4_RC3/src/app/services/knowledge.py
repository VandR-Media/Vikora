"""Versioned, human-approved glossary for vacancy-scoped assessments.

The glossary changes how models READ requirements, never the source resume.
A word/alias alone cannot establish ability; grounded evidence remains required.
"""
from __future__ import annotations

import hashlib
import json
import re
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.models import KnowledgeTerm, Vacancy
from app.services.evaluate import criteria_snapshot


def canonical_name(name: str) -> str:
    return " ".join(name.split()).casefold()


def visible_terms(db: Session, vacancy_id) -> list[KnowledgeTerm]:
    rows = db.scalars(select(KnowledgeTerm).where(or_(KnowledgeTerm.vacancy_id.is_(None),
                        KnowledgeTerm.vacancy_id == vacancy_id)).order_by(KnowledgeTerm.name, KnowledgeTerm.id)).all()
    # Vacancy-specific definitions override global ones with the same name.
    picked = {}
    for item in rows:
        old = picked.get(item.normalized_name)
        if old is None or item.vacancy_id is not None:
            picked[item.normalized_name] = item
    return sorted(picked.values(), key=lambda item: item.normalized_name)


def snapshot_for(db: Session, vacancy: Vacancy) -> dict:
    """Stable input metadata: no candidate data and no dependence on timestamps."""
    basic = criteria_snapshot(vacancy.criteria)
    terms = visible_terms(db, vacancy.id)
    relevant = []
    # Match a full technology name or approved alias as a *whole expression*
    # inside a longer requirement, but never Java inside JavaScript.
    for term in terms:
        labels = [term.name] + list(term.aliases)
        matches = [criterion for criterion in basic["criteria"] if any(
            re.search(r"(?<!\w)" + re.escape(label) + r"(?!\w)", criterion["label"], re.IGNORECASE)
            for label in labels
        )]
        if not matches:
            continue
        relevant.append(term)
        for criterion in matches:
            known = [term.name] + list(term.aliases)
            aliases = criterion.setdefault("aliases", [])
            for alias in known:
                if canonical_name(alias) != canonical_name(criterion["label"]) and alias not in aliases:
                    aliases.append(alias)
            if term.explanation:
                criterion["glossary_note"] = term.explanation[:1000]
    reference = [{"name": t.name, "aliases": t.aliases, "explanation": t.explanation} for t in relevant]
    raw = json.dumps({"criteria": basic["criteria"], "terms": reference},
                     ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return {"criteria": basic["criteria"], "glossary_terms": reference, "knowledge_hash": digest,
            "knowledge_version": 1}


def assessment_stale(current: dict, previous: dict) -> bool:
    if previous.get("knowledge_hash"):
        return previous["knowledge_hash"] != current["knowledge_hash"]
    # Older assessments had no glossary hash. Compare criterion data at least.
    return previous.get("criteria", []) != criteria_snapshot_from(current)


def criteria_snapshot_from(current: dict) -> list:
    return [{k:v for k,v in c.items() if k not in ("aliases", "glossary_note")}
            for c in current.get("criteria", [])]
