"""No-cloud personal AI provider for the Vikora Windows laptop edition.

Never accepts a URL from the browser or disk. All resume-containing requests go to
127.0.0.1 only, with proxy environment disabled. The model must be downloaded and
started by the owner on their own machine. The local API has no auth, so it MUST
remain bound to loopback (Ollama default) and never be exposed by firewall rules.
"""
from __future__ import annotations

import json

import httpx

from app.services.evaluate import (EvaluationFailure, SYSTEM_PROMPT,
                                   validate_grounding, _document_text)

OLLAMA_ORIGIN = "http://127.0.0.1:11434"
from app.local_preferences import MODEL_TAG, read_ai_preference, save_ai_preference
MAX_CHUNK_CHARS = 7900
MAX_CHUNKS = 5


def probe_ollama() -> dict:
    """Only probes metadata, never sends candidate data."""
    result = {"service_running": False, "model_installed": False, "model": MODEL_TAG}
    try:
        with httpx.Client(timeout=2.0, trust_env=False) as client:
            response = client.get(f"{OLLAMA_ORIGIN}/api/tags")
            response.raise_for_status()
            data = response.json()
        result["service_running"] = True
        result["model_installed"] = any(
            item.get("name") == MODEL_TAG or item.get("model") == MODEL_TAG
            for item in data.get("models", []) if isinstance(item, dict)
        )
    except (httpx.HTTPError, ValueError, KeyError, TypeError):
        pass
    return result


def _split_pages(pages: list[dict]) -> list[list[dict]]:
    """Bound local prompts; never silently discard the tail of a resume."""
    _document_text(pages)
    segments = []
    for page in pages:
        text = page["text"]
        # splitting does not change page numbers; evidence still refers to source page
        for start in range(0, len(text), MAX_CHUNK_CHARS):
            segment = text[start:start + MAX_CHUNK_CHARS]
            if segment.strip():
                segments.append({"page": page["page"], "text": segment})
    chunks, current, size, current_pages = [], [], 0, set()
    for segment in segments:
        if current and (size + len(segment["text"]) > MAX_CHUNK_CHARS or segment["page"] in current_pages):
            chunks.append(current)
            current, size, current_pages = [], 0, set()
        current.append(segment)
        current_pages.add(segment["page"])
        size += len(segment["text"])
    if current:
        chunks.append(current)
    if len(chunks) > MAX_CHUNKS:
        raise EvaluationFailure("Резюме слишком длинное для локальной модели. Требуется ручная проверка или более короткая версия резюме.")
    return chunks


def _combine(criteria: list[dict], all_results: list[list]) -> dict:
    """Take conservative union; conflicts have UNKNOWN status and no evidence."""
    output = []
    for idx, criterion in enumerate(criteria):
        candidates = [chunk[idx] for chunk in all_results]
        found = [res for res in candidates if res.match_level != "unknown"]
        if not found:
            output.append({"criterion_key": criterion["key"], "match_level": "unknown",
                           "evidence": [], "rationale": "В тексте резюме нет однозначного подтверждения. Требуется ручная проверка."})
            continue
        levels = {res.match_level for res in found}
        if "not_met" in levels and len(levels) > 1:
            output.append({"criterion_key": criterion["key"], "match_level": "unknown",
                           "evidence": [], "rationale": "В разных частях резюме обнаружены противоречивые сведения. Проверьте вручную."})
            continue
        # A partial assessment elsewhere prevents declaring the entire criterion 'met'.
        level = "partial" if "partial" in levels else next(iter(levels))
        evidence = []
        for result in found:
            for quote in result.evidence:
                item = quote.model_dump()
                if item not in evidence and len(evidence) < 4:
                    evidence.append(item)
        output.append({"criterion_key": criterion["key"], "match_level": level,
                       "evidence": evidence,
                       "rationale": found[0].rationale[:700] + (" (Сведения из нескольких частей резюме.)" if len(found) > 1 else "")})
    return {"results": output}


def ollama_assess(criteria: list[dict], pages: list[dict], model_name: str | None = None) -> dict:
    """Local inference. Failure never changes the candidate's hiring stage."""
    if model_name is not None and model_name != MODEL_TAG:
        raise EvaluationFailure("Неизвестная локальная модель")
    if len(criteria) > 20:
        raise EvaluationFailure("Для локальной модели используйте не более 20 критериев")
    chunks = _split_pages(pages)
    results = []
    for chunk in chunks:
        payload = {
            "model": MODEL_TAG, "stream": False, "format": "json", "think": False,
            "keep_alive": "2m",
            "options": {"temperature": 0, "num_ctx": 8192, "num_predict": 1900},
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps({"criteria": criteria,
                     "resume_pages": chunk}, ensure_ascii=False)},
            ],
        }
        try:
            with httpx.Client(timeout=300.0, trust_env=False) as client:
                response = client.post(f"{OLLAMA_ORIGIN}/api/chat", json=payload)
                response.raise_for_status()
                content = response.json()["message"]["content"]
            if not isinstance(content, str) or len(content) > 100000:
                raise ValueError("Invalid Ollama content")
            result = json.loads(content)
            results.append(validate_grounding(result, criteria, pages))
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise EvaluationFailure("Локальная модель недоступна или вернула некорректный результат. Проверьте Ollama и попробуйте снова.") from exc
    return _combine(criteria, results)
