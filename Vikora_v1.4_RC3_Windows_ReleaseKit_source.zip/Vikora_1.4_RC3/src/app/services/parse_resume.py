"""Offline text extraction; never evaluate instructions embedded in source documents."""
from pathlib import Path

from docx import Document
from pypdf import PdfReader

MAX_PAGES = 100
MAX_TEXT_CHARS = 250_000


class ParseFailure(Exception):
    pass


def extract_pages(path: Path, mime_type: str) -> list[dict]:
    if mime_type == "application/pdf":
        try:
            reader = PdfReader(str(path), strict=True)
            if len(reader.pages) > MAX_PAGES:
                raise ParseFailure("PDF exceeds page limit")
            pages = [{"page": i + 1, "text": page.extract_text() or ""}
                     for i, page in enumerate(reader.pages)]
        except ParseFailure:
            raise
        except Exception as exc:
            raise ParseFailure("PDF parsing failed") from exc
    elif mime_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        try:
            doc = Document(str(path))
            text_items = [p.text for p in doc.paragraphs]
            for table in doc.tables:
                for row in table.rows:
                    text_items.append("\t".join(cell.text for cell in row.cells))
            pages = [{"page": 1, "text": "\n".join(text_items)}]
        except Exception as exc:
            raise ParseFailure("DOCX parsing failed") from exc
    else:
        raise ParseFailure("Unsupported document MIME")
    if sum(len(p["text"]) for p in pages) > MAX_TEXT_CHARS:
        raise ParseFailure("Extracted text exceeds limit")
    if not any(p["text"].strip() for p in pages):
        raise ParseFailure("No extractable text (possibly a scanned document)")
    return pages
