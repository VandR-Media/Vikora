"""Privacy lifecycle: relational purge + durable, retryable local blob cleanup.

The database purge is atomic. Deletion of OS files cannot share that transaction:
write an outbox first, then retry cleanup until it succeeds. No candidate PII is
copied into purge receipts, blob tickets, or new audit entries.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from app.models import (
    Application, AuditEvent, Candidate, CriterionEvaluation, Evaluation,
    PurgeBlob, PurgeRequest, Resume,
)
from app.services.uploads import blob_path


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def as_utc(value: datetime) -> datetime:
    # SQLite drops timezone offsets from DateTime(timezone=True). Values are stored as UTC.
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


class CandidateMissing(Exception):
    pass


def schedule_candidate_purge(db: Session, candidate_id: uuid.UUID, *,
                             actor_id: uuid.UUID | None, reason: str) -> uuid.UUID:
    """Purge *all* applications of a candidate across vacancies, not just one.

    Lock candidate row for concurrent erasure claims. Record file keys in an
    outbox and redact linked audit events in the *same transaction* as deletion.
    DB foreign keys cascade evaluations and criterion evaluations.
    Caller must not assume files are gone until cleanup receipt is finished.
    """
    candidate = db.scalar(select(Candidate).where(Candidate.id == candidate_id).with_for_update())
    if candidate is None:
        raise CandidateMissing()

    app_ids = db.scalars(select(Application.id).where(Application.candidate_id == candidate_id)).all()
    resumes = db.scalars(select(Resume).where(Resume.candidate_id == candidate_id)).all()
    resume_ids = [resume.id for resume in resumes]
    evaluation_ids = db.scalars(select(Evaluation.id).where(or_(
        Evaluation.application_id.in_(app_ids), Evaluation.resume_id.in_(resume_ids),
    ))).all()
    linked = (
        ((AuditEvent.entity_type == "candidate") & (AuditEvent.entity_id == candidate_id))
        | ((AuditEvent.entity_type == "application") & AuditEvent.entity_id.in_(app_ids))
        | ((AuditEvent.entity_type == "resume") & AuditEvent.entity_id.in_(resume_ids))
        | ((AuditEvent.entity_type == "evaluation") & AuditEvent.entity_id.in_(evaluation_ids))
    )
    linked_audits = db.scalars(select(AuditEvent).where(linked).with_for_update()).all()
    for event in linked_audits:
        event.entity_id = None
        event.details = {"redacted_after_privacy_purge": True}

    request_id = uuid.uuid4()
    now = utcnow()
    receipt = PurgeRequest(
        id=request_id, actor_id=actor_id, reason=reason,
        application_count=len(app_ids), resume_count=len(resumes),
        evaluation_count=len(evaluation_ids), audit_redacted_count=len(linked_audits),
        finished_at=now if not resumes else None,
    )
    db.add(receipt)
    db.flush()  # FK parent must exist before inserting blob outbox rows (SQLite and PostgreSQL).
    for resume in resumes:
        db.add(PurgeBlob(request_id=request_id, storage_key=resume.storage_key,
                         state="pending", attempts=0, next_attempt_at=now))
    db.add(AuditEvent(actor_id=actor_id, action="privacy.candidate.purged",
                      entity_type="purge_request", entity_id=request_id,
                      details={"reason": reason, "applications": len(app_ids),
                               "resumes": len(resumes), "evaluations": len(evaluation_ids),
                               "audits_redacted": len(linked_audits)}))
    db.delete(candidate)
    db.commit()
    return request_id


def _unlink_blob(storage_key: str) -> None:
    """The only filesystem erase operation; safe to retry if already missing."""
    blob_path(storage_key).unlink(missing_ok=True)


def cleanup_one_blob(db: Session, *, request_id: uuid.UUID | None = None) -> bool:
    """Attempt one due operation. Locks protect simultaneous cleanup workers.

    Each file is deleted before its outbox ticket is acknowledged. Crash before
    acknowledgement is safe: the next attempt sees a missing path and succeeds.
    """
    now = utcnow()
    criteria = [PurgeBlob.state == "pending", PurgeBlob.next_attempt_at <= now]
    if request_id is not None:
        criteria.append(PurgeBlob.request_id == request_id)
    ticket = db.scalar(select(PurgeBlob).where(*criteria)
                       .order_by(PurgeBlob.created_at, PurgeBlob.id)
                       .with_for_update(skip_locked=True).limit(1))
    if ticket is None:
        return False
    try:
        _unlink_blob(ticket.storage_key)
    except (OSError, RuntimeError, ValueError) as exc:
        ticket.attempts += 1
        ticket.error_code = type(exc).__name__[:80]  # Do not store filenames or exception messages.
        ticket.next_attempt_at = now + timedelta(seconds=min(3600, 2 ** min(ticket.attempts, 10)))
    else:
        ticket.state = "completed"
        ticket.finished_at = now
        ticket.error_code = None
        db.flush()
        pending_count = db.scalar(select(func.count()).select_from(PurgeBlob).where(
            PurgeBlob.request_id == ticket.request_id,
            PurgeBlob.state != "completed",
        ))
        if pending_count == 0:
            receipt = db.get(PurgeRequest, ticket.request_id)
            if receipt is not None:
                receipt.finished_at = now
    db.commit()
    return True


def try_cleanup_request(db: Session, request_id: uuid.UUID, *, limit: int = 100) -> None:
    for _ in range(limit):
        if not cleanup_one_blob(db, request_id=request_id):
            break


def receipt_status(db: Session, request_id: uuid.UUID) -> dict | None:
    receipt = db.get(PurgeRequest, request_id)
    if receipt is None:
        return None
    pending = db.scalar(select(func.count()).select_from(PurgeBlob).where(
        PurgeBlob.request_id == request_id, PurgeBlob.state == "pending",
    ))
    failed = db.scalar(select(func.count()).select_from(PurgeBlob).where(
        PurgeBlob.request_id == request_id, PurgeBlob.state == "pending", PurgeBlob.attempts > 0,
    ))
    return {
        "request_id": receipt.id,
        "state": "completed" if receipt.finished_at is not None else "cleanup_pending",
        "reason": receipt.reason,
        "applications_removed": receipt.application_count,
        "resumes_removed": receipt.resume_count,
        "evaluations_removed": receipt.evaluation_count,
        "audit_events_redacted": receipt.audit_redacted_count,
        "files_pending": pending,
        "files_with_retry": failed,
        "created_at": receipt.created_at,
        "finished_at": receipt.finished_at,
    }


def retention_overview(db: Session) -> dict:
    now = utcnow()
    return {
        "expired_candidates": db.scalar(select(func.count()).select_from(Candidate).where(Candidate.retention_until <= now)),
        "missing_retention_deadline": db.scalar(select(func.count()).select_from(Candidate).where(Candidate.retention_until.is_(None))),
        "expiring_30_days": db.scalar(select(func.count()).select_from(Candidate).where(and_(
            Candidate.retention_until > now, Candidate.retention_until <= now + timedelta(days=30)))),
        "pending_file_cleanup": db.scalar(select(func.count()).select_from(PurgeBlob).where(PurgeBlob.state == "pending")),
        "file_cleanup_errors": db.scalar(select(func.count()).select_from(PurgeBlob).where(and_(
            PurgeBlob.state == "pending", PurgeBlob.attempts > 0))),
    }


def purge_expired_batch(db: Session, *, limit: int = 50) -> list[uuid.UUID]:
    """Process expired only; legacy candidates without a deadline are reported, not deleted."""
    now = utcnow()
    ids = db.scalars(select(Candidate.id).where(Candidate.retention_until <= now)
                     .order_by(Candidate.retention_until, Candidate.id)
                     .limit(limit)).all()
    purged = []
    for candidate_id in ids:
        try:
            # Recheck expiry under a lock: an administrator might have extended it.
            locked = db.scalar(select(Candidate).where(Candidate.id == candidate_id).with_for_update())
            if locked is None or locked.retention_until is None or as_utc(locked.retention_until) > utcnow():
                db.rollback()
                continue
            request_id = schedule_candidate_purge(db, candidate_id, actor_id=None, reason="retention_expired")
        except CandidateMissing:
            db.rollback()
            continue
        purged.append(request_id)
    return purged


def prune_old_receipts(db: Session, *, days: int = 30) -> int:
    """Keep receipts temporarily, not indefinitely; preserve aggregate audit."""
    cutoff = utcnow() - timedelta(days=days)
    receipts = db.scalars(select(PurgeRequest).where(
        PurgeRequest.finished_at.is_not(None), PurgeRequest.finished_at < cutoff,
    ).limit(100)).all()
    for receipt in receipts:
        for blob in db.scalars(select(PurgeBlob).where(PurgeBlob.request_id == receipt.id)).all():
            db.delete(blob)
        db.delete(receipt)
    db.commit()
    return len(receipts)
