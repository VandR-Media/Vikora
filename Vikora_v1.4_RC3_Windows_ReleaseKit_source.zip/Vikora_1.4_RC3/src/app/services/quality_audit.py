"""Synthetic-only model audit for a one-person desktop recruiter workspace.

This is a smoke/benchmark with deliberately constructed examples, not a clinical,
legal, employment or statistically representative performance validation. No
candidate records, resume files or personnel data are ever read by this module.
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from app.local_runtime import data_directory
from app.services.evaluate import EvaluationFailure, validate_grounding, heuristic_assess

PROVIDERS = ("heuristic", "ollama_local", "openai_api", "deepseek_api", "gigachat_api", "alice_api")
CLOUD_PROVIDERS = frozenset(PROVIDERS[2:])
DATASET_VERSION = "vikora-synthetic-v1"
DATASET_PATH = Path(__file__).resolve().parents[1] / "quality_cases_v14.json"
RUN_DIR_NAME = "quality_audits"
_STORE_LIMIT = 30
_CURRENT: dict | None = None
_LOCK = threading.Lock()


def model_label(provider: str) -> str:
    """Model tag snapshot, not proof of underlying weights/digest."""
    from app.local_preferences import MODEL_TAG, OPENAI_MODEL_TAG, CLOUD_MODEL_TAGS
    if provider == 'heuristic':
        return 'keyword-heuristic-v1'
    if provider == 'ollama_local':
        return MODEL_TAG
    if provider == 'openai_api':
        return OPENAI_MODEL_TAG
    return CLOUD_MODEL_TAGS.get(provider, 'unknown')


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_synthetic_cases() -> list[dict]:
    """The cases come only from our shipped, immutable, explicitly synthetic fixture."""
    data = json.loads(DATASET_PATH.read_text(encoding="utf-8"))
    if data.get("version") != DATASET_VERSION or not isinstance(data.get("cases"), list):
        raise RuntimeError("Набор тестов повреждён")
    cases = data["cases"]
    if not 12 <= len(cases) <= 50 or len({case.get('id') for case in cases}) != len(cases):
        raise RuntimeError("Некорректный набор тестов")
    for case in cases:
        if not case.get('synthetic') or not case.get('criteria') or not case.get('pages'):
            raise RuntimeError("Непроверенный тестовый пример")
        if {c['key'] for c in case['criteria']} != set(case['expected']):
            raise RuntimeError("В тесте нет эталонной оценки")
        if any(level not in {"met", "partial", "not_met", "unknown"} for level in case['expected'].values()):
            raise RuntimeError("Некорректный эталон")
        if any(not p['text'].startswith('Вымышленн') for p in case['pages']):
            raise RuntimeError("Недопустимый текст тестового резюме")
    return cases


def provider_assess(provider: str, criteria: list[dict], pages: list[dict]) -> dict:
    """Never fallback to another provider and never run with actual resumes."""
    if provider == "heuristic":
        return heuristic_assess(criteria, pages)
    if provider == "ollama_local":
        from app.services.local_ai import ollama_assess
        return ollama_assess(criteria, pages)
    if provider == "openai_api":
        from app.services.openai_bridge import evaluate_resume_with_api
        from app.local_preferences import OPENAI_MODEL_TAG
        return evaluate_resume_with_api(criteria, pages, model=OPENAI_MODEL_TAG)
    if provider in {"deepseek_api", "gigachat_api", "alice_api"}:
        from app.services.cloud_providers import evaluate_resume
        from app.local_preferences import CLOUD_MODEL_TAGS
        return evaluate_resume(provider, criteria, pages, model=CLOUD_MODEL_TAGS[provider])
    raise ValueError("Неизвестная модель")


def summarize(items: list[dict]) -> dict:
    """Criterion-level metrics; errors are not silently counted as 'unknown'."""
    attempted = sum(len(item['expected']) for item in items)
    complete = [item for item in items if item['status'] == 'completed']
    assessed = sum(len(item['expected']) for item in complete)
    agree = overclaim = missed_experience = known_when_unknown = 0
    for item in complete:
        for key, expected in item['expected'].items():
            predicted = item['predicted'][key]
            agree += (predicted == expected)
            overclaim += (predicted == 'met' and expected != 'met')
            missed_experience += (expected == 'met' and predicted in ('not_met', 'unknown'))
            known_when_unknown += (expected == 'unknown' and predicted != 'unknown')
    return {
        "cases_total": len(items), "cases_completed": len(complete),
        "cases_failed": len(items) - len(complete),
        "criteria_attempted": attempted, "criteria_assessed": assessed,
        "exact_agreement": agree,
        "agreement_percent_on_assessed": round(100 * agree / assessed, 1) if assessed else None,
        "met_overclaims": overclaim, "missed_clear_experience": missed_experience,
        "unsupported_claims_on_unknown": known_when_unknown,
    }


def evaluate_cases(provider: str, cases: list[dict],
                   assess: Callable[[str, list[dict], list[dict]], dict] | None = None) -> dict:
    """Calculate one report, validating every model quote against its test resume."""
    if provider not in PROVIDERS:
        raise ValueError('Неизвестная модель')
    assess = assess or provider_assess
    results = []
    for case in cases:
        row = {"id": case['id'], "label": case['label'], "expected": case['expected']}
        try:
            raw = assess(provider, case['criteria'], case['pages'])
            normalized = validate_grounding(raw, case['criteria'], case['pages'])
            row.update(status='completed', predicted={r.criterion_key: r.match_level for r in normalized},
                       correctly_matched=all(r.match_level == case['expected'][r.criterion_key] for r in normalized))
        except EvaluationFailure:
            row.update(status='failed', predicted={}, correctly_matched=False,
                       error="ИИ не дал проверяемую оценку или точную цитату")
        except Exception:
            # Never surface raw model text, credentials, HTTP responses or test case content.
            row.update(status='failed', predicted={}, correctly_matched=False,
                       error="Ошибка подключения или обработки ответа")
        results.append(row)
    return {"dataset": DATASET_VERSION, "provider": provider, "model": model_label(provider),
            "generated_at": utc_now(), "summary": summarize(results), "results": results,
            "disclaimer": "Только вымышленные примеры. Это не измерение точности на реальных кандидатах и не основание для автоматического решения о найме."}


def audit_directory() -> Path:
    return data_directory() / RUN_DIR_NAME


def _report_path(run_id: str) -> Path:
    # Strict UUID parsing prevents path traversal or access to arbitrary user files.
    return audit_directory() / (str(uuid.UUID(run_id)) + '.json')


def _store(report: dict) -> None:
    folder = audit_directory()
    folder.mkdir(parents=True, exist_ok=True)
    path = _report_path(report['run_id'])
    temporary = path.with_suffix('.tmp')
    try:
        with temporary.open('x', encoding='utf-8') as file:
            json.dump(report, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    # Remove oldest reports; no resumes or keys are ever stored.
    files = sorted(folder.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in files[_STORE_LIMIT:]:
        old.unlink(missing_ok=True)


def get_report(run_id: str) -> dict | None:
    try:
        path = _report_path(run_id)
    except (ValueError, AttributeError, TypeError):
        return None
    with _LOCK:
        if _CURRENT and _CURRENT['run_id'] == run_id:
            return dict(_CURRENT)
    try:
        if not path.is_file() or path.stat().st_size > 150_000:
            return None
        report = json.loads(path.read_text(encoding='utf-8'))
        if report.get('run_id') != run_id:
            return None
        return report
    except (OSError, ValueError):
        return None


def recent_reports() -> list[dict]:
    folder = audit_directory()
    if not folder.exists():
        return []
    files = sorted(folder.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"run_id": d['run_id'], "provider": d['provider'], "model": d.get("model"), "generated_at": d['generated_at'],
             "summary": d['summary'], "status": "completed"}
            for path in files[:10] if (d := get_report(path.stem)) is not None]


def run_status() -> dict:
    with _LOCK:
        return dict(_CURRENT) if _CURRENT else {"status": "idle"}


def begin_run(provider: str, case_ids: list[str], *, confirmed_cloud: bool) -> dict:
    """Start a single background smoke run; optional cloud access is opt-in per run."""
    if provider not in PROVIDERS:
        raise ValueError('Неизвестный режим проверки')
    if provider in CLOUD_PROVIDERS and not confirmed_cloud:
        raise PermissionError('Подтвердите отдельный платный запрос к облачному сервису')
    cases = read_synthetic_cases()
    by_id = {case['id']: case for case in cases}
    limit = 6 if provider in CLOUD_PROVIDERS else 24
    if not case_ids or len(case_ids) > limit or len(set(case_ids)) != len(case_ids) or any(k not in by_id for k in case_ids):
        raise ValueError(f'Выберите от 1 до {limit} тестовых примеров')
    chosen = [by_id[case_id] for case_id in case_ids]
    if provider == 'ollama_local':
        from app.services.local_ai import probe_ollama
        ready = probe_ollama()
        if not ready['service_running'] or not ready['model_installed']:
            raise ValueError('Локальная нейросеть не установлена или не запущена')
    if provider == 'openai_api':
        from app.services.openai_bridge import read_api_key
        if not read_api_key():
            raise ValueError('Сначала добавьте API-ключ OpenAI в настройках')
    if provider in CLOUD_PROVIDERS and provider != 'openai_api':
        from app.services.cloud_providers import get_credentials
        if not get_credentials(provider):
            raise ValueError('Сначала подключите выбранный AI-сервис')
    global _CURRENT
    with _LOCK:
        if _CURRENT and _CURRENT.get('status') in ('running', 'queued'):
            raise RuntimeError('Проверка уже выполняется')
        job = {"run_id": str(uuid.uuid4()), "status": "queued", "provider": provider,
               "started_at": utc_now(), "completed_cases": 0, "total_cases": len(chosen)}
        _CURRENT = job

    def worker():
        global _CURRENT
        with _LOCK:
            _CURRENT = {**job, 'status': 'running'}
        # We process selected cases in serial to avoid exhausting a 16GB laptop.
        partial = []
        for one in chosen:
            result = evaluate_cases(provider, [one])['results'][0]
            partial.append(result)
            with _LOCK:
                _CURRENT = {**job, 'status': 'running', 'completed_cases': len(partial)}
        report = {"dataset": DATASET_VERSION, "provider": provider, "model": model_label(provider),
                  "generated_at": utc_now(), "summary": summarize(partial), "results": partial,
                  "disclaimer": "Только синтетические примеры, не показатель качества на реальных людях.",
                  "run_id": job['run_id'], "status": 'completed'}
        try:
            _store(report)
        except OSError:
            report['status'] = 'failed'
            report['error'] = 'Не удалось сохранить отчёт на диск'
        with _LOCK:
            _CURRENT = report
    threading.Thread(target=worker, name='vikora-quality-audit', daemon=True).start()
    return job
