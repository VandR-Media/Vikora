"""Small, strict UTF-8 text bundle parser for single-user recruiter.

Accepts JSON/CSV/TXT and a ZIP of TXT files; never extracts ZIP to disk.
All content is untrusted candidate data, *not* instructions to the LLM.
"""
from __future__ import annotations

import csv
import io
import json
import re
import stat
import zipfile
from dataclasses import dataclass
from pathlib import Path

MAX_BATCH = 50
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_TEXT = 5 * 1024 * 1024
MAX_RESUME_TEXT = 200_000


class ImportFailure(ValueError):
    pass


@dataclass
class TextCandidate:
    full_name: str
    text: str
    email: str | None
    phone: str | None
    external_id: str | None
    label: str
    source_format: str


def _read_utf8(data: bytes) -> str:
    try:
        value = data.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        raise ImportFailure('Требуется UTF-8. Сохраните файл в кодировке UTF-8.') from exc
    if '\x00' in value:
        raise ImportFailure('Текст содержит недопустимые управляющие символы')
    return value


def _field(entry: dict, *aliases: str):
    for alias in aliases:
        if alias in entry:
            return entry[alias]
    return None


def _value(value, limit: int, label: str) -> str | None:
    if value is None or value == '':
        return None
    if not isinstance(value, str) or len(value) > limit or any(ord(ch) < 32 for ch in value):
        raise ImportFailure('Некорректное поле ' + label)
    return value.strip() or None


def _parse_entry(record: dict, *, label: str, source_format: str) -> TextCandidate:
    if not isinstance(record, dict):
        raise ImportFailure('Запись кандидата должна быть объектом с полями')
    text = _field(record, 'resume_text', 'text', 'Текст резюме')
    if not isinstance(text, str) or not text.strip():
        raise ImportFailure('Не найден текст резюме (resume_text)')
    text = text.replace('\r\n', '\n').replace('\r', '\n').strip()
    if len(text) > MAX_RESUME_TEXT or '\x00' in text:
        raise ImportFailure('Текст резюме слишком длинный или содержит недопустимые символы')
    name = _value(_field(record, 'full_name', 'ФИО'), 255, 'ФИО') or 'Кандидат — проверьте имя'
    email = _value(_field(record, 'email', 'Email'), 320, 'email')
    phone = _value(_field(record, 'phone', 'Телефон'), 50, 'телефон')
    external_id = _value(_field(record, 'external_id', 'ID'), 255, 'ID')
    return TextCandidate(name, text, email, phone, external_id, label, source_format)


def _json_records(raw: str) -> list:
    def strict(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ImportFailure('Повторяющийся ключ JSON')
            out[key] = value
        return out
    try:
        content = json.loads(raw, object_pairs_hook=strict)
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise ImportFailure('Неверный JSON-файл') from exc
    if isinstance(content, dict):
        content = content.get('candidates')
    if not isinstance(content, list):
        raise ImportFailure('JSON должен содержать список кандидатов или поле candidates')
    return content


def _csv_records(raw: str) -> list[dict]:
    # Spreadsheet exports commonly use comma or semicolon; delimiter is selected
    # from the header only to avoid confusion with résumé prose in quoted cells.
    header = raw.splitlines()[0] if raw.splitlines() else ''
    delimiter = ';' if header.count(';') > header.count(',') else ','
    try:
        reader = csv.DictReader(io.StringIO(raw, newline=''), delimiter=delimiter, strict=True)
        if not reader.fieldnames or not (set(reader.fieldnames) & {'resume_text', 'text', 'Текст резюме'}):
            raise ImportFailure('CSV должен содержать колонку resume_text (Текст резюме)')
        rows = []
        for row in reader:
            if len(rows) >= MAX_BATCH:
                raise ImportFailure('В одном файле можно импортировать до 50 кандидатов')
            if None in row:
                raise ImportFailure('В строке CSV больше полей, чем в заголовке')
            rows.append(row)
        return rows
    except csv.Error as exc:
        raise ImportFailure('Ошибка структуры CSV') from exc


def parse_bundle(filename: str, data: bytes) -> tuple[list[TextCandidate], list[dict]]:
    """Return valid entries and row-local errors; reject unsafe/malformed bundles."""
    if not data or len(data) > MAX_FILE_BYTES:
        raise ImportFailure('Файл пустой или превышает 8 МБ')
    name = Path(filename.replace('\\', '/').split('/')[-1]).name[:200]
    suffix = Path(name).suffix.lower()
    records: list[tuple[str, dict, str]] = []
    if suffix in {'.json', '.csv', '.txt'}:
        raw = _read_utf8(data)
        if suffix == '.json':
            source = _json_records(raw)
        elif suffix == '.csv':
            source = _csv_records(raw)
        else:
            source = [{'full_name': 'Кандидат — проверьте имя', 'resume_text': raw}]
        if len(source) > MAX_BATCH or not source:
            raise ImportFailure('В одном файле должно быть от 1 до 50 кандидатов')
        records = [(f'Запись {i}', row, suffix[1:]) for i, row in enumerate(source, start=1)]
    elif suffix == '.zip':
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                infos = archive.infolist()
                if not 1 <= len(infos) <= MAX_BATCH:
                    raise ImportFailure('В ZIP должно быть от 1 до 50 TXT-файлов')
                if sum(i.file_size for i in infos) > MAX_TOTAL_TEXT:
                    raise ImportFailure('ZIP содержит слишком много текста')
                names = set()
                for info in infos:
                    entry = info.filename
                    # No folders, paths, encrypted entries, symlinks or ambiguous names.
                    if (info.is_dir() or '/' in entry or '\\' in entry or entry in names
                            or entry.startswith('.') or Path(entry).suffix.lower() != '.txt'
                            or info.flag_bits & 1 or stat.S_IFMT(info.external_attr >> 16) == stat.S_IFLNK
                            or info.file_size > MAX_RESUME_TEXT * 4):
                        raise ImportFailure('ZIP должен содержать только отдельные TXT-файлы без папок')
                    if info.file_size > 0 and info.compress_size and info.file_size > info.compress_size * 100:
                        raise ImportFailure('Подозрительное сжатие в ZIP')
                    names.add(entry)
                    raw = _read_utf8(archive.read(info))
                    records.append((entry[:180], {'full_name': 'Кандидат — проверьте имя', 'resume_text': raw}, 'txt'))
        except (zipfile.BadZipFile, RuntimeError, OSError, EOFError) as exc:
            raise ImportFailure('Повреждённый или неподдерживаемый ZIP') from exc
    else:
        raise ImportFailure('Разрешены JSON, CSV, TXT или ZIP с TXT-файлами')
    items: list[TextCandidate] = []
    errors: list[dict] = []
    total = 0
    for label, record, format_name in records:
        try:
            item = _parse_entry(record, label=label, source_format=format_name)
            total += len(item.text.encode('utf-8'))
            if total > MAX_TOTAL_TEXT:
                raise ImportFailure('Общий объём текста превышает 5 МБ')
            items.append(item)
        except ImportFailure as exc:
            errors.append({'filename': label, 'reason': str(exc)})
    return items, errors
