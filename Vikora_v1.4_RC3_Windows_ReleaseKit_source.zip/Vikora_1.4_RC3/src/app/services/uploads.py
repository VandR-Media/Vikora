"""Bounded disk writes, format checks and optional fail-closed ClamAV scanning."""
import hashlib
import os
import socket
import subprocess
import sys
import struct
import tempfile
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path

from fastapi import HTTPException, UploadFile

from app.core.config import settings


@dataclass
class StagedUpload:
    path: Path
    size: int
    sha256: str
    mime_type: str
    filename: str


def _safe_filename(value: str | None) -> str:
    name = (value or "resume").replace("\\", "/").split("/")[-1].strip()
    name = "".join(ch for ch in name if ch.isprintable() and ch not in '\\/:*?"<>|')
    return name[:250] or "resume"


def _validate_file(path: Path, filename: str, claimed_content_type: str | None) -> str:
    suffix = Path(filename).suffix.lower()
    mimetypes = {
        ".pdf": ("application/pdf", {"application/pdf", "application/octet-stream"}),
        ".docx": ("application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                  {"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/zip", "application/octet-stream"}),
    }
    if suffix not in mimetypes:
        raise HTTPException(415, "Only .pdf and .docx resumes are supported")
    detected, allowed_claims = mimetypes[suffix]
    if claimed_content_type and claimed_content_type.lower().split(";")[0].strip() not in allowed_claims:
        raise HTTPException(415, "MIME type does not match file extension")
    with path.open("rb") as f:
        magic = f.read(8)
    if suffix == ".pdf":
        if not magic.startswith(b"%PDF-"):
            raise HTTPException(415, "Invalid PDF signature")
        return detected
    if not magic.startswith(b"PK\x03\x04"):
        raise HTTPException(415, "Invalid DOCX signature")
    try:
        with zipfile.ZipFile(path) as archive:
            info = archive.infolist()
            if (len(info) > 2000 or sum(i.file_size for i in info) > 50 * 1024 * 1024
                    or any(i.file_size > 20 * 1024 * 1024 for i in info)):
                raise HTTPException(413, "DOCX archive expands beyond permitted limits")
            names = {i.filename for i in info}
            if "[Content_Types].xml" not in names or "word/document.xml" not in names:
                raise HTTPException(415, "ZIP is not a DOCX document")
    except (zipfile.BadZipFile, RuntimeError, OSError) as exc:
        raise HTTPException(415, "Invalid DOCX archive") from exc
    return detected


def scan_with_windows_defender(path: Path) -> None:
    """Fail closed if on-demand Windows Defender scan cannot be verified.

    Actual detection behavior and compatibility with third-party AV products
    must be exercised on target Windows laptop before accepting real resumes.
    """
    if sys.platform != "win32":
        raise HTTPException(503, "Проверка Windows Defender доступна только в Windows")
    ps = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    if not ps.is_file():
        raise HTTPException(503, "Не найден Windows Defender; загрузка остановлена")
    # Filename never passes through the shell. Use a separate environment variable.
    command = ("$ErrorActionPreference='Stop'; "
               "$s=Get-MpComputerStatus; "
               "if (!$s.AntivirusEnabled -or !$s.AMServiceEnabled) { exit 12 }; "
               "Start-MpScan -ScanType CustomScan -ScanPath $env:VIKORA_SCAN_FILE -ErrorAction Stop; "
               "if (!(Test-Path -LiteralPath $env:VIKORA_SCAN_FILE)) { exit 13 }")
    environment = dict(os.environ, VIKORA_SCAN_FILE=str(path))
    try:
        result = subprocess.run([str(ps), "-NoProfile", "-NonInteractive", "-EncodedCommand",
                                 __import__("base64").b64encode(command.encode("utf-16le")).decode("ascii")],
                                env=environment, capture_output=True, timeout=120, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(503, "Не удалось завершить антивирусную проверку") from exc
    if result.returncode != 0 or not path.is_file():
        raise HTTPException(422 if result.returncode == 13 else 503,
                            "Антивирус не подтвердил безопасность файла; загрузка отменена")


def scan_for_malware(path: Path) -> None:
    if settings.malware_scan_mode == "disabled":
        if settings.app_env != "development":
            raise HTTPException(503, "Антивирусная проверка не настроена; загрузка запрещена")
        return
    if settings.malware_scan_mode == "windows_defender":
        scan_with_windows_defender(path)
        return
    try:
        with socket.create_connection((settings.clamav_host, settings.clamav_port), timeout=10) as conn:
            conn.settimeout(30)
            conn.sendall(b"zINSTREAM\x00")
            with path.open("rb") as source:
                while chunk := source.read(65536):
                    conn.sendall(struct.pack("!I", len(chunk)) + chunk)
            conn.sendall(struct.pack("!I", 0))
            result = conn.recv(4096)
            if not result.endswith(b"OK\x00") and not result.endswith(b"OK\n"):
                if b"FOUND" in result:
                    raise HTTPException(422, "Malware detected; file rejected")
                raise HTTPException(503, "Antivirus could not verify the file")
    except HTTPException:
        raise
    except (OSError, TimeoutError) as exc:
        raise HTTPException(503, "Antivirus service unavailable; upload rejected") from exc


async def stage_upload(upload: UploadFile) -> StagedUpload:
    filename = _safe_filename(upload.filename)
    root = Path(settings.upload_dir).resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(root, 0o700)
    temp_path = None
    digest = hashlib.sha256()
    size = 0
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=root, prefix=".incoming-", delete=False) as f:
            temp_path = Path(f.name)
            os.chmod(f.name, 0o600)
            while chunk := await upload.read(65536):
                size += len(chunk)
                if size > settings.max_upload_bytes:
                    raise HTTPException(413, "File exceeds size limit")
                digest.update(chunk)
                f.write(chunk)
        if not size:
            raise HTTPException(422, "Empty document")
        mime = _validate_file(temp_path, filename, upload.content_type)
        scan_for_malware(temp_path)
        return StagedUpload(temp_path, size, digest.hexdigest(), mime, filename)
    except BaseException:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()


def commit_file(staged: StagedUpload) -> str:
    root = Path(settings.upload_dir).resolve()
    key = f"{uuid.uuid4().hex[:2]}/{uuid.uuid4().hex}"
    target = root / key
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(target.parent, 0o700)
    os.replace(staged.path, target)
    return key


def blob_path(storage_key: str) -> Path:
    root = Path(settings.upload_dir).resolve()
    path = (root / storage_key).resolve()
    if not path.is_relative_to(root) or path.is_symlink():
        raise RuntimeError("Invalid storage key")
    return path
