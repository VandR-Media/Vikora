/* Vikora v1.4 RC1 preview. Single-user desktop mode uses an ephemeral loopback-only token. */
const root = document.getElementById('app');
const state = {
  token: null, user: null, authMode: null, csrf: null, vacancies: [], vacancy: null,
  applications: [], queue: [], candidate: null, resumes: [], evaluations: [],
  parsedText: null, modal: null, loading: false, error: '', qualityOpen:false, qualityCases:[], qualityReports:[], qualityReport:null, qualityStatus:null, privacyOverview: null, ai: null, aiDraft: null, aiDraftTarget: null, selectedApps: [], cloudProvider: null, bulkReport: null, glossary: [], editingTerm: null, hh: {status:null,link:null,vacancies:[],collections:[],preview:[],page:0,collection:null},
};
let poll = null;
let qualityPoll = null;
let activeLoad = 0;

const e = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date = value => value ? new Date(value).toLocaleDateString('ru-RU') : '—';
const statusVacancy = {draft:'Черновик',open:'Открыта',paused:'Пауза',closed:'Закрыта'};
const stageNames = {new:'Новый',review:'На рассмотрении',interview:'Интервью',offer:'Оффер',hired:'Нанят',rejected:'Отказ'};
const stageColors = {new:'purple',review:'yellow',interview:'purple',offer:'green',hired:'green',rejected:'red'};
const levelNames = {met:'Подтверждено',partial:'Частично',not_met:'Не соответствует',unknown:'Нет данных'};
const levelColors = {met:'green',partial:'yellow',not_met:'red',unknown:''};
const evalNames = {pending:'В очереди',processing:'Анализируется',completed:'Готово',failed:'Ошибка'};
const cloudNames = {openai_api:'OpenAI API',deepseek_api:'DeepSeek API',gigachat_api:'GigaChat API',alice_api:'Алиса AI'};
const providerAllowed = key => ['deepseek_api','gigachat_api','alice_api'].includes(key);
const cloudMode = key => Object.hasOwn(cloudNames,key);
const isConfigured = key => !!state.ai?.providers?.[key];
const canEdit = () => ['admin','recruiter'].includes(state.user?.role);
const tag = (text, color='') => `<span class="badge ${color}">${e(text)}</span>`;
const initials = text => e((text || '?').trim().charAt(0).toUpperCase());
const empty = (icon, title, subtitle) => `<div class="empty"><div class="empty-glyph">${icon}</div><h3>${e(title)}</h3><p>${e(subtitle)}</p></div>`;
// Never interpolate backend strings without e().

async function api(path, options={}) {
  const headers = {...options.headers};
  if(state.token && ['dev','local'].includes(state.authMode)) headers.Authorization = `Bearer ${state.token}`;
  if(state.authMode==='oidc' && !['GET','HEAD','OPTIONS'].includes(options.method||'GET') && state.csrf)
    headers['X-CSRF-Token'] = state.csrf;
  if(options.body && !(options.body instanceof FormData)) headers['Content-Type']='application/json';
  const response = await fetch(path, {...options, headers, cache:'no-store', credentials:'same-origin'});
  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}));
    let detail = errorBody.detail || `Ошибка сервера (${response.status})`;
    if (Array.isArray(detail)) detail = detail.map(x => x.msg || 'Некорректные данные').join('; ');
    if (response.status === 401) { state.token=null;state.user=null;clearInterval(poll);render(); }
    throw new Error(typeof detail === 'string' ? detail : 'Не удалось выполнить запрос');
  }
  if(response.status === 204) return null;
  return response.headers.get('content-type')?.includes('application/json') ? response.json() : response;
}
function notify(message, isError=false) {
  document.querySelector('.notice')?.remove();
  const node = document.createElement('div');node.className='notice'+(isError?' error':'');
  node.textContent=message;node.setAttribute('role',isError?'alert':'status');
  document.body.append(node);
  setTimeout(() => node.remove(), 5000);
}
function brand() {return `<div class="brand"><span class="brand-mark">V</span><span>Vikora<small>AI RECRUITING</small></span></div>`;}
function loginView() {
  const corporate = state.authMode==='oidc';
  const loginContent = state.authMode==='local' ? `<p>Vikora запускается только через ярлык программы. Закройте эту вкладку и откройте Vikora с рабочего стола.</p><div class="hint">Данные остаются на этом компьютере. Интернет и корпоративный вход не нужны.</div>` : corporate ? `<p>Войдите через корпоративную учётную запись. Права доступа назначает администратор Vikora.</p><a class="button wide" href="/api/v1/auth/login">Войти через SSO →</a><div class="hint">Сессия хранится на сервере. Пароль корпоративной учётной записи Vikora не получает.</div>`
    : `<p>Для локальной разработки вставьте временный токен, выданный администратором.</p><form id="login-form"><div class="field"><label for="token">Тестовый токен доступа</label><input id="token" name="token" type="password" required autocomplete="off" placeholder="Bearer JWT-токен" /></div><button class="button wide" type="submit">Открыть рабочее пространство →</button></form><div class="hint">Режим разработки. Не используйте токены для реальных персональных данных.</div>`;
  return `<div class="login"><div class="login-left">${brand()}<blockquote>Талант виден<br>в деталях.</blockquote><span class="note">Интеллектуальный помощник рекрутера. Решение всегда за человеком.</span></div><div class="login-right"><div class="login-form"><div class="eyebrow">Добро пожаловать</div><h1>Вход в Vikora</h1>${loginContent}${state.error?`<div class="errorbox" role="alert">${e(state.error)}</div>`:''}</div></div></div>`;
}
function shell(content) {return `<div class="layout"><aside class="sidebar">${brand()}<nav aria-label="Навигация"><div class="nav-caption">Рабочее пространство</div><button class="nav-btn ${state.vacancy?'':'active'}" data-action="dashboard">▦ &nbsp; Обзор</button><button class="nav-btn ${state.vacancy?'active':''}" data-action="dashboard">▤ &nbsp; Вакансии</button>${state.authMode==='local'?`<button class="nav-btn ${state.qualityOpen?'active':''}" data-action="quality-open">✧ &nbsp; Проверка ИИ</button>`:''}</nav><div class="profile"><b>${e(state.user?.full_name)}</b><small>${e(state.user?.role)} · ${e(state.user?.email)}</small><button class="button ghost sm" data-action="logout">${state.authMode==='local'?'Завершить работу':'Выйти'}</button></div></aside><main class="main"><div class="topbar"><span>VIKORA / ЛИЧНЫЙ ПОМОЩНИК</span><span>${date(new Date().toISOString())}</span></div>${content}<div class="footer">Vikora v1.4 RC1 · Работает на вашем компьютере. Пока используйте только вымышленные данные.</div></main></div>${modalView()}`;}
function dashboardView() {
  const opened = state.vacancies.filter(v=>v.status==='open').length;
  const criteria = state.vacancies.reduce((n,v)=>n+v.criteria.length,0);
  return `<div class="eyebrow">Обзор рекрутинга</div><div class="headline"><div><h1>Рабочее пространство</h1><p>Вакансии, кандидаты и проверяемые результаты оценки в одном месте.</p></div>${canEdit()?`<button class="button" data-action="new-vacancy">＋ Новая вакансия</button>${state.authMode==='local'?'<button class="button secondary" data-action="ai-vacancy">✧ Помочь с вакансией</button>':''}`:''}</div>
  <div class="stats"><div class="card stat"><span class="stat-icon">▤</span><strong>${state.vacancies.length}</strong><small>Доступных вакансий</small></div><div class="card stat"><span class="stat-icon">◉</span><strong>${opened}</strong><small>Открытых вакансий</small></div><div class="card stat"><span class="stat-icon">✧</span><strong>${criteria}</strong><small>Критериев оценки</small></div></div>
  ${state.user?.role==='admin'&&state.privacyOverview?`<div class="muted-card"><b>Контроль хранения данных</b> · Просрочено: ${e(state.privacyOverview.expired_candidates)} · Без срока (проверить вручную): ${e(state.privacyOverview.missing_retention_deadline)} · Файлов на удаление: ${e(state.privacyOverview.pending_file_cleanup)}${state.privacyOverview.file_cleanup_errors?` · <b>Ошибок очистки: ${e(state.privacyOverview.file_cleanup_errors)}</b>`:''} <button class="button ghost sm" data-action="refresh-privacy">↻ Обновить</button></div>`:''}
  ${state.authMode==='local'?`<div class="card" style="margin-bottom:22px"><div class="section-head"><h2>ИИ для Vikora</h2>${tag(cloudNames[state.ai?.mode]|| (state.ai?.mode==='ollama_local'?'Локальный ИИ':'Обычная проверка'), state.ai?.mode==='heuristic'?'':'green')}</div><p class="muted">Выбирайте, где анализировать резюме. Облачные API оплачиваются отдельно; текст резюме отправляется только после вашего подтверждения. ChatGPT Plus через JSON-файлы остаётся доступен без API.</p><div class="hint">${e(state.ai?.message||'Проверяем настройки…')}</div><div class="actions" style="margin-top:12px;flex-wrap:wrap"><button class="button secondary" data-action="mode-basic">Обычная проверка</button><button class="button secondary" data-action="mode-local">Локальный ИИ</button><button class="button secondary" data-action="mode-openai">OpenAI API</button>${Object.keys(cloudNames).filter(k=>providerAllowed(k)).map(k=>`<button class="button secondary" data-action="mode-provider" data-provider="${e(k)}">${e(cloudNames[k])}</button>`).join('')}</div><div class="actions" style="margin-top:12px;flex-wrap:wrap"><button class="button ghost" data-action="setup-openai">⚙ Ключ OpenAI ${isConfigured('openai_api')?'✓':''}</button>${Object.keys(cloudNames).filter(k=>providerAllowed(k)).map(k=>`<button class="button ghost" data-action="setup-provider" data-provider="${e(k)}">⚙ ${e(cloudNames[k])} ${isConfigured(k)?'✓':''}</button>`).join('')}</div><p class="note" style="margin-top:10px">API-ключи сохраняются в защищённом хранилище Windows. Перед использованием реальных резюме проверьте право на передачу персональных данных каждому выбранному поставщику.</p></div>`:''}
  ${state.authMode==='local'?`<div class="card" style="margin-bottom:22px"><h2>Сохранность ваших данных</h2><p class="muted">Сохраните зашифрованную копию вакансий и резюме на флешку или другой носитель. Для восстановления понадобится придуманный вами пароль.</p><div class="actions"><button class="button secondary" data-action="make-backup">↓ Скачать резервную копию</button><button class="button secondary" data-action="verify-backup">✓ Проверить копию</button><button class="button secondary" data-action="start-restore">↻ Восстановить из копии</button></div><div class="note" style="margin-top:10px">Не храните единственную резервную копию на том же ноутбуке. Если забыть пароль, расшифровать копию не получится.</div></div>`:''}
  <div class="section-head"><h2>Ваши вакансии</h2><span class="muted">${state.vacancies.length} всего</span></div>${state.vacancies.length?`<div class="vacancy-list">${state.vacancies.map(v=>`<button class="vacancy-card" data-action="open-vacancy" data-id="${e(v.id)}"><div class="split">${tag(statusVacancy[v.status]||v.status, v.status==='open'?'green':'')}<span class="muted">↗</span></div><h3 class="space-top">${e(v.title)}</h3><div class="meta"><span>⌁ ${e(v.department||'Без отдела')}</span><span>⌖ ${e(v.location||'Не указана')}</span></div><div class="vacancy-bottom split"><span class="muted">${v.criteria.length} критериев</span><span class="muted">${date(v.created_at)}</span></div></button>`).join('')}</div>`:empty('▤','Вакансий пока нет','Создайте первую вакансию, чтобы начать оценку кандидатов.')}`;
}
function qualityView(){
  const providerLabels={heuristic:'Обычная проверка',ollama_local:'Локальная Qwen3 4B',...cloudNames};
  const result=state.qualityReport;
  const job=state.qualityStatus;
  const m=result?.summary;
  return `<button class="back-link" data-action="dashboard">← На главную</button>
  <div class="eyebrow">Диагностика · Только вымышленные резюме</div>
  <div class="headline"><div><h1>Проверка качества ИИ</h1><p>Проверяем не только оценку, но и неподтверждённые утверждения и ошибки в цитатах.</p></div></div>
  <div class="card" style="margin-bottom:18px"><h2>Запустить проверку</h2><p class="muted">Для проверки используются ${e(state.qualityCases.length)} вымышленных примера. Настоящие резюме из вашей базы НЕ отправляются.</p>
  <div class="field"><label for="quality-provider">Какую модель проверить?</label><select id="quality-provider">
  ${Object.entries(providerLabels).map(([id,label])=>`<option value="${e(id)}" ${state.qualityProvider===id?'selected':''}>${e(label)}</option>`).join('')}</select></div>
  <div class="actions" style="flex-wrap:wrap"><button class="button" data-action="quality-test-six" ${job?.status==='running'||job?.status==='queued'?'disabled':''}>Проверить 6 примеров</button><button class="button secondary" data-action="quality-test-all" ${job?.status==='running'||job?.status==='queued'?'disabled':''}>Проверить все ${e(state.qualityCases.length)}</button></div>
  <p class="note">Облачные модели требуют отдельного подтверждения и могут списать деньги с API-баланса. Для них допускается максимум 6 примеров за один тест. Проверка не меняет кандидатов и вакансии.</p>
  ${job?.status==='running'||job?.status==='queued'?`<div class="hint" role="status">Проверка: ${e(job.completed_cases||0)} из ${e(job.total_cases||'?')}. Не закрывайте Vikora до окончания теста.</div>`:''}
  </div>
  ${result&&m?`<div class="card" style="margin-bottom:18px"><div class="section-head"><h2>Результат: ${e(providerLabels[result.provider]||result.provider)}</h2>${tag(result.status==='failed'?'Не удалось сохранить':'Завершено',result.status==='failed'?'yellow':'green')}</div>
  <div class="stats"><div class="stat"><strong>${e(m.agreement_percent_on_assessed ?? '—')}${m.agreement_percent_on_assessed===null?'':'%'}</strong><small>Совпадение с эталоном*</small></div>
  <div class="stat"><strong>${e(m.cases_completed)}/${e(m.cases_total)}</strong><small>Обработано примеров</small></div><div class="stat"><strong>${e(m.met_overclaims)}</strong><small>Ошибочно подтверждённые навыки</small></div></div>
  <div class="hint">Другие ошибки: непризнанный явный опыт — ${e(m.missed_clear_experience)}; утверждения при отсутствии сведений — ${e(m.unsupported_claims_on_unknown)}; ошибки обработки или цитат — ${e(m.cases_failed)}.</div>
  <p class="note">*Это согласие только на маленьком учебном наборе. Не доказательство точности на реальных кандидатах и не основание для автоматических отказов.</p>
  <table class="data-table"><thead><tr><th>Ситуация</th><th>Ожидаемое</th><th>Результат</th><th>Статус</th></tr></thead><tbody>${result.results.map(row=>`<tr><td>${e(row.label)}</td><td>${e(Object.values(row.expected).join(', '))}</td><td>${e(Object.values(row.predicted).join(', ')||row.error||'—')}</td><td>${tag(row.status!=='completed'?'Ошибка':row.correctly_matched?'Совпало':'Проверить',row.correctly_matched?'green':'yellow')}</td></tr>`).join('')}</tbody></table>
  <div class="actions"><button class="button secondary" data-action="quality-download">↓ Скачать отчёт JSON</button></div></div>`:''}
  <div class="card"><h2>Предыдущие проверки</h2>${state.qualityReports.length?`<table class="data-table"><thead><tr><th>Модель</th><th>Дата</th><th>Совпадение*</th><th></th></tr></thead><tbody>${state.qualityReports.map(r=>`<tr><td>${e(providerLabels[r.provider]||r.provider)}</td><td>${date(r.generated_at)}</td><td>${e(r.summary.agreement_percent_on_assessed ?? '—')}%</td><td><button class="button ghost sm" data-action="quality-view" data-id="${e(r.run_id)}">Посмотреть</button></td></tr>`).join('')}</tbody></table>`:'<p class="muted">Проверок пока нет.</p>'}</div>`;
}
async function openQuality(){
  clearInterval(poll);state.qualityOpen=true;state.vacancy=null;state.candidate=null;state.modal=null;
  const [cases,reports,status]=await Promise.all([api('/api/v1/local/quality/cases'),api('/api/v1/local/quality/runs'),api('/api/v1/local/quality/runs/current')]);
  state.qualityCases=cases.cases;state.qualityReports=reports.reports;state.qualityStatus=status;
  if(status?.status==='completed')state.qualityReport=status;
  render();
  if(status?.status==='queued'||status?.status==='running')startQualityPolling();
}
function startQualityPolling(){
  clearInterval(qualityPoll);
  qualityPoll=setInterval(async()=>{
    if(!state.qualityOpen){clearInterval(qualityPoll);return;}
    try{
      const status=await api('/api/v1/local/quality/runs/current');state.qualityStatus=status;
      if(status.status==='completed'||status.status==='failed'){
        state.qualityReport=status;state.qualityReports=(await api('/api/v1/local/quality/runs')).reports;
        clearInterval(qualityPoll);
      }
      render();
    }catch(err){clearInterval(qualityPoll);notify(err.message,true);}
  },2500);
}
function vacancyView() {
  const v=state.vacancy;
  if (!v)return dashboardView();
  const queueMap = new Map(state.queue.map(x=>[x.application_id,x]));
  const cards=state.applications.map(app=>{
    const q=queueMap.get(app.id);
    const score=(q && q.overall_score!==null)? `${q.overall_score}/100`:'—';
    return `<tr data-candidate-row data-name="${e(app.candidate.full_name.toLowerCase())}" data-stage="${e(app.stage)}" data-action="open-candidate" data-id="${e(app.id)}" tabindex="0" role="button" aria-label="Открыть кандидата ${e(app.candidate.full_name)}"><td><label class="exchange-check"><input type="checkbox" name="exchange-choice" value="${e(app.id)}" ${state.selectedApps.includes(app.id)?"checked":""} aria-label="Выбрать ${e(app.candidate.full_name)}" /> Выбрать</label></td><td><div class="person"><span class="avatar">${initials(app.candidate.full_name)}</span><div><div class="person-name">${e(app.candidate.full_name)}</div><div class="tiny">${e(app.candidate.email||'Контакты не указаны')}</div></div></div></td><td>${tag(stageNames[app.stage]||app.stage,stageColors[app.stage]||'')}</td><td>${q?.status?tag(evalNames[q.status]||q.status,q.status==='completed'?'green':'yellow'):'<span class="muted">Не запускалась</span>'}${q?.needs_reassessment?'<div class="tiny" style="color:#aa6127">↻ Требуется переоценка</div>':''}</td><td><b>${score}</b>${q?.coverage_pct != null?`<div class="tiny">Покрытие ${q.coverage_pct}%</div>`:''}</td><td class="muted">${date(app.created_at)}</td></tr>`;
  });
  return `<button class="back-link" data-action="dashboard">← Все вакансии</button><div class="eyebrow">Карточка вакансии</div><div class="headline"><div><div class="split" class="align-left"><h1 class="flush-bottom">${e(v.title)}</h1>${tag(statusVacancy[v.status]||v.status, v.status==='open'?'green':'')}</div><p>${e([v.department,v.location].filter(Boolean).join(' · ')||'Без подразделения')}</p></div>${canEdit()?`<button class="button" data-action="new-candidate">＋ Добавить кандидата</button>${state.authMode==='local'?'<button class="button secondary" data-action="bulk-upload">⇧ Загрузить несколько резюме</button><button class="button secondary" data-action="edit-vacancy">✎ Редактировать вакансию</button><button class="button secondary" data-action="ai-edit-vacancy">✧ Уточнить через ИИ</button>':''}`:''}</div><p class="description">${e(v.description)}</p><div class="criteria">${v.criteria.length?v.criteria.map(c=>`<span class="criterion">${c.importance==='must'?'★':'○'} ${e(c.label)} · ${c.weight}</span>`).join(''):'<span class="note">Критерии не заданы — оценка недоступна.</span>'}</div>${state.authMode==='local'?hhBlock():''}${state.authMode==='local'?`<div class="card" style="margin:22px 0"><div class="section-head"><h2>Словарь технологий и терминов</h2><button class="button secondary sm" data-action="new-term">＋ Добавить термин</button></div><p class="muted">Ваши подтверждённые синонимы учитываются при новых оценках. Само наличие слова в резюме не доказывает опыт. После редактирования словаря или требований переоцените нужных кандидатов.</p>${state.glossary.length?`<div class="eval-details">${state.glossary.map(t=>`<div class="eval-item"><div class="split"><b>${e(t.name)}</b><span class="tiny">${t.vacancy_id?'Для вакансии':'Общий'}</span></div><p class="muted">${e(t.aliases.join(', ')||'Без синонимов')} · ${e(t.explanation||'Без пояснения')}</p><div class="actions"><button class="button ghost sm" data-action="edit-term" data-id="${e(t.id)}">Изменить</button><button class="button ghost sm" data-action="remove-term" data-id="${e(t.id)}">Удалить</button></div></div>`).join('')}</div>`:'<p class="note">Словарь пока пуст. Например: Kubernetes → K8s.</p>'}</div>`:''}${state.authMode==='local'?`<div class="card" style="margin:22px 0"><h2>ChatGPT Plus через файл (без API)</h2><p class="muted">Отметьте кандидатов в таблице ниже и скачайте задание. Затем отправьте файл в этот чат. После анализа импортируйте полученный файл с результатами — Vikora сама разнесёт оценки по карточкам.</p><div class="actions" style="flex-wrap:wrap"><button class="button secondary" data-action="select-exchange-all">☑ Выбрать всех</button><button class="button" data-action="export-exchange">↓ Скачать задание для ChatGPT</button><button class="button secondary" data-action="import-exchange">↑ Импортировать результаты</button></div><p class="note">Не более 20 резюме в одном файле. При массовом экспорте берётся последнее успешно разобранное резюме каждого выбранного кандидата. ВНИМАНИЕ: в файле может быть личная информация кандидатов. Выбирайте только данные, которые имеете право передавать в ChatGPT.</p></div>`:''}${state.authMode==='local'?`<div class="card" style="margin:22px 0"><h2>Массовая работа с резюме</h2><p class="muted">Загрузите до 50 PDF/DOCX одновременно, либо импортируйте таблицу JSON/CSV или TXT. После извлечения текста отметьте нужных кандидатов в таблице: их можно поставить в очередь ИИ одним действием. Результаты можно сохранить в таблицу CSV для Excel.</p><div class="actions" style="flex-wrap:wrap"><button class="button secondary" data-action="bulk-upload">⇧ PDF/DOCX</button><button class="button secondary" data-action="structured-upload">⇧ JSON / CSV / TXT / ZIP</button><button class="button" data-action="bulk-evaluate">✧ Оценить / переоценить выбранных</button><button class="button secondary" data-action="download-csv">↓ Таблица результатов (CSV)</button></div><p class="note">Оценка не отправляет отказов и не меняет этап кандидата. Для облачного ИИ вы подтвердите передачу выбранных резюме отдельно.</p></div>`:''}
  ${state.bulkReport?`<div class="card" style="margin:18px 0"><h3>Результат загрузки</h3><p>Загружено: ${e(state.bulkReport.imported?.length||0)} · Уже были в вакансии: ${e(state.bulkReport.duplicates?.length||0)} · Ошибок: ${e(state.bulkReport.errors?.length||0)}</p>${(state.bulkReport.errors||[]).map(item=>`<p class="note"><b>${e(item.filename)}:</b> ${e(item.reason)}</p>`).join('')}<button class="button ghost sm" data-action="dismiss-bulk-report">Понятно</button></div>`:''}
  <div class="section-head"><h2>Отклики <span class="muted">${state.applications.length}</span></h2><button data-action="refresh-vacancy" class="button secondary sm">↻ Обновить</button></div><div class="toolbar"><input id="candidate-search" type="search" aria-label="Поиск кандидата" placeholder="Поиск кандидата…"/><select id="stage-filter" aria-label="Этап кандидата"><option value="">Все этапы</option>${Object.entries(stageNames).map(([k,v])=>`<option value="${k}">${e(v)}</option>`).join('')}</select></div><div class="card table-scroll">${cards.length?`<table class="table"><thead><tr><th>Выбрать</th><th>Кандидат</th><th>Этап</th><th>AI-оценка</th><th>Балл*</th><th>Добавлен</th></tr></thead><tbody>${cards.join('')}</tbody></table>`:empty('♙','Откликов пока нет','Добавьте тестового кандидата и загрузите его резюме.')}</div><div class="footer">* Балл отображается только при достаточном покрытии критериев; не является рекомендацией нанимать или отказывать.</div>`;
}

function hhBlock(){
 const h=state.hh||{}, connected=!!h.status?.connected;
 const option=(items, nameProp='name')=>(items||[]).map(item=>`<option value="${e(item.id)}">${e(item[nameProp])}</option>`).join('');
 return `<div class="card" style="margin:22px 0"><div class="section-head"><h2>Отклики с hh.ru</h2>${tag(connected?'Подключён':'Не подключён',connected?'green':'')}</div>
 <p class="muted">Импорт только по вашему запросу. Vikora не отправляет приглашений, отказов и не меняет статусы на hh.ru. Доступ зависит от прав аккаунта работодателя.</p>
 <div class="actions" style="flex-wrap:wrap"><button class="button secondary" data-action="hh-settings">⚙ Настроить hh.ru</button>${h.status?.configured?`<button class="button secondary" data-action="hh-connect">Подключить аккаунт</button>`:''}${connected?`<button class="button secondary" data-action="hh-load-vacancies">Загрузить вакансии hh.ru</button><button class="button ghost" data-action="hh-disconnect">Отключить</button>`:''}</div>
 ${h.link?.hh_vacancy_id?`<p class="note">Связана с вакансией hh.ru №${e(h.link.hh_vacancy_id)}</p>`:''}
 ${h.vacancies?.length?`<div class="field"><label>Выберите соответствующую вакансию hh.ru</label><select id="hh-vacancy-select">${option(h.vacancies)}</select><button class="button secondary sm" data-action="hh-link">Связать с этой вакансией Vikora</button></div>`:''}
 ${h.link?.hh_vacancy_id?`<div class="actions"><button class="button secondary" data-action="hh-collections">Показать группы откликов</button></div>`:''}
 ${h.collections?.length?`<div class="field"><label>Группа откликов</label><select id="hh-collection-select">${option(h.collections)}</select><button class="button secondary sm" data-action="hh-preview">Предпросмотр до 50 откликов</button></div>`:''}
 ${h.preview?.length?`<p class="note">Страница ${Number(h.page||0)+1}. Импорт выбранных резюме может отметить их просмотренными на hh.ru.</p><div class="table-scroll"><table class="table"><thead><tr><th>Выбрать</th><th>Название резюме</th><th>Доступ</th></tr></thead><tbody>${h.preview.map(x=>`<tr><td><input name="hh-choice" type="checkbox" value="${e(x.id)}" ${x.has_resume?'':'disabled'} /></td><td>${e(x.title)}</td><td>${x.has_resume?'Текст доступен':'Нет доступа'}</td></tr>`).join('')}</tbody></table></div><div class="actions"><button class="button" data-action="hh-import">Импортировать выбранных</button><button class="button secondary" data-action="hh-next">Следующая страница</button>${h.page>0?'<button class="button ghost" data-action="hh-prev">Предыдущая</button>':''}</div>`:''}
 <p class="note">Vikora не раскрывает платные контакты и не обходит ограничения hh.ru. Полное резюме загружается только после вашего подтверждения.</p></div>`;
}

function candidateView() {
  const a=state.candidate;
  const v=state.vacancy;
  if(!a||!v)return vacancyView();
  const evaluation=state.evaluations[0];
  const snapshot=Object.fromEntries((evaluation?.criteria_snapshot?.criteria||[]).map(c=>[c.key,c]));
  const extracted=state.parsedText?.pages;
  const stageSelect=`<label for="stage-select">Этап найма</label><select id="stage-select" ${canEdit()?'':'disabled'}>${Object.entries(stageNames).map(([k,label])=>`<option value="${k}" ${a.stage===k?'selected':''}>${e(label)}</option>`).join('')}</select><div class="note" class="space-small">Изменение этапа — ручное действие рекрутера.</div>`;
  return `<button class="back-link" data-action="back-to-vacancy">← ${e(v.title)}</button><div class="eyebrow">Карточка кандидата</div><div class="headline"><div><h1>${e(a.candidate.full_name)}</h1>${state.authMode==='local'?'<button class="button ghost sm" data-action="rename-candidate">✎ Исправить имя</button>':''}<p>${e(a.candidate.email||'Email не указан')} ${a.candidate.phone?' · '+e(a.candidate.phone):''}</p></div>${tag(stageNames[a.stage]||a.stage,stageColors[a.stage]||'')}</div><div class="candidate-grid"><div><div class="card"><div class="section-head"><h2>Резюме</h2>${canEdit()?'<button class="button secondary sm" data-action="upload-resume">＋ Загрузить</button>':''}</div>${state.resumes.length?state.resumes.map(r=>`<div class="resume-row"><div><div class="resume-name">${e(r.original_filename)}</div><div class="tiny">${date(r.created_at)} · ${tag(r.parse_status==='parsed'?'Текст извлечён':r.parse_status==='pending'?'Обработка…':r.parse_status,r.parse_status==='parsed'?'green':'yellow')}</div></div><div class="actions"><button class="button ghost sm" data-action="view-text" data-id="${e(r.id)}" ${r.parse_status==='parsed'?'':'disabled'}>Текст</button>${state.authMode==='local'&&r.parse_status==='parsed'?`<button class="button ghost sm" data-action="copy-resume-plus" data-id="${e(r.id)}">Запрос для Plus</button>`:''}${state.authMode==='local'&&r.parse_status==='parsed'?`<button class="button secondary sm" data-action="export-resume-exchange" data-id="${e(r.id)}">↓ Файл для ChatGPT</button>`:''}${r.mime_type!=='text/plain'?`<button class="button ghost sm" data-action="download" data-id="${e(r.id)}">↓</button>`:''}${canEdit()?`<button class="button secondary sm" data-action="evaluate" data-id="${e(r.id)}" ${r.parse_status==='parsed'&&v.criteria.length?'':'disabled'}>Оценить</button>`:''}</div></div>`).join(''):empty('▤','Резюме пока нет','Загрузите PDF или DOCX (до 10 МБ).')}${extracted?`<h3 class="space-top">Извлечённый текст</h3>${extracted.map(p=>`<p class="muted">Страница ${e(p.page)}</p><div class="content-text">${e(p.text)}</div>`).join('')}`:''}</div><div class="card evaluation"><div class="section-head"><h2>Результат оценки</h2><button class="button ghost sm" data-action="refresh-candidate">↻ Обновить</button></div>${evaluation?`<div class="split"><div>${tag(evalNames[evaluation.status]||evaluation.status,evaluation.status==='completed'?'green':evaluation.status==='failed'?'red':'yellow')}<div class="tiny">${e(evaluation.model_name)} · ${date(evaluation.created_at)}</div></div><div><div class="score">${evaluation.overall_score==null?'—':`${evaluation.overall_score}/100`}</div><div class="tiny">Покрытие ${evaluation.coverage_pct??'—'}%</div></div></div>${evaluation.explanation?`<div class="muted-card">${e(evaluation.explanation)}</div>`:''}${evaluation.error_message?`<div class="errorbox">${e(evaluation.error_message)}</div>`:''}${evaluation.needs_reassessment?'<div class="muted-card">↻ Требования вакансии или словарь изменились после этой оценки. При необходимости запустите оценку заново.</div>':''}<div class="eval-details">${evaluation.results.map(r=>`<div class="eval-item"><div class="split"><b>${e(snapshot[r.criterion_key]?.label||r.criterion_key)}</b>${tag(levelNames[r.match_level]||r.match_level,levelColors[r.match_level]||'')}</div><p>${e(r.rationale)}</p>${(r.evidence||[]).map(ev=>`<div class="quote"><b>Страница ${e(ev.page)}</b><br>${e(ev.excerpt)}</div>`).join('')}${evaluation.expert_corrections?.filter(x=>x.criterion_key===r.criterion_key).map(x=>`<div class="muted-card"><b>Ваша поправка: ${e(levelNames[x.corrected_level]||x.corrected_level)}</b><p>${e(x.note)}</p></div>`).join('')||''}${canEdit()?`<button class="button ghost sm" data-action="correct-evaluation" data-id="${e(r.criterion_key)}">✎ Уточнить результат</button>`:''}</div>`).join('')}</div>${evaluation.status==='pending'||evaluation.status==='processing'?'<div class="muted-card">Обработка продолжается. Результат обновляется автоматически.</div>':''}`:empty('✧','Оценки пока нет','Когда текст резюме извлечён, нажмите «Оценить».')}</div></div><div><div class="card"><h2>Работа с кандидатом</h2><div class="field" class="space-top-large">${stageSelect}</div><div class="muted-card">AI-оценка не переводит кандидатов на другой этап автоматически. Проверяйте подтверждающие фрагменты перед решением.</div></div><div class="card"><h3>Источник и сведения</h3><div class="meta">${e(a.candidate.source)} · добавлен ${date(a.created_at)}</div><p class="note" class="space-top-medium">Данные доступны только пользователям с доступом к вакансии.</p><div class="retention-panel"><div class="tiny">Срок хранения: <b>${a.candidate.retention_until?date(a.candidate.retention_until):'Не установлен — требуется проверка'}</b></div>${state.user?.role==='admin'?`<div class="actions space-top-medium"><button class="button secondary sm" data-action="change-retention">Изменить срок</button><button class="button danger sm" data-action="delete-candidate">Удалить данные кандидата</button></div><p class="note">Удаление затронет все отклики, связанные с этой карточкой кандидата. Совпадающие дубликаты нужно искать отдельно.</p>`:''}</div></div></div></div>`;
}
function criterionRow(i, c={}) {return `<div class="criterion-row" data-criterion-row><div class="key"><label>Ключ</label><input name="criterion_key" value="${e(c.key||`skill_${i}`)}" required minlength="2" pattern="[a-z][a-z0-9_]*" /></div><div><label>Требование</label><input name="criterion_label" placeholder="Например, Python" value="${e(c.label||'')}" required minlength="2" /></div><div><label>Важность</label><select name="criterion_importance"><option value="must" ${c.importance==='must'?'selected':''}>Обязательно</option><option value="nice" ${c.importance==='nice'?'selected':''}>Желательно</option></select></div><div><label>Вес 1–10</label><input name="criterion_weight" type="number" min="1" max="10" value="${e(c.weight||5)}" required /></div><button type="button" class="button ghost" data-action="remove-criterion" aria-label="Удалить критерий">×</button><div class="criterion-note"><label>Пояснение к критерию (необязательно)</label><input name="criterion_description" value="${e(c.description||'')}" maxlength="3000" placeholder="Что именно нужно уметь или знать" /></div></div>`;}
function modalView() {
  if(!state.modal)return '';
  if(state.modal==='vacancy')return `<div class="backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><h2 id="modal-title">${state.aiDraftTarget?'Уточнение вакансии':'Новая вакансия'}</h2><p>${state.aiDraftTarget?'Проверьте черновик от ИИ перед сохранением изменений.':'Добавьте критерии для сопоставления с резюме.'}</p></div><button class="button ghost" data-action="close-modal" aria-label="Закрыть">✕</button></div><form id="vacancy-form"><div class="field-grid"><div class="field"><label>Название</label><input name="title" required minlength="3" maxlength="255" placeholder="Backend-разработчик" value="${e(state.aiDraft?.title|| (state.aiDraftTarget?state.vacancy?.title:'') ||'')}" /></div><div class="field"><label>Отдел</label><input name="department" maxlength="120" placeholder="Разработка" value="${e(state.aiDraftTarget?state.vacancy?.department||'':'')}" /></div><div class="field"><label>Локация</label><input name="location" maxlength="180" placeholder="Удалённо" value="${e(state.aiDraftTarget?state.vacancy?.location||'':'')}" /></div><div class="field"><label>Статус</label><select name="status"><option value="draft" ${state.aiDraftTarget && state.vacancy?.status==='draft'?'selected':''}>Черновик</option><option value="open" ${state.aiDraftTarget && state.vacancy?.status==='open'?'selected':''}>Открыта</option><option value="paused" ${state.aiDraftTarget && state.vacancy?.status==='paused'?'selected':''}>Пауза</option><option value="closed" ${state.aiDraftTarget && state.vacancy?.status==='closed'?'selected':''}>Закрыта</option></select></div></div><div class="field"><label>Описание вакансии (от 10 символов)</label><textarea name="description" required minlength="10" maxlength="30000" placeholder="Задачи, команда, условия…">${e(state.aiDraft?.description||(state.aiDraftTarget?state.vacancy?.description:'')||'')}</textarea></div><div class="section-head"><h3>Критерии</h3><button type="button" class="button secondary sm" data-action="add-criterion">＋ Добавить</button></div><div id="criteria-rows">${state.aiDraft?.criteria?.length ? state.aiDraft.criteria.map((c,i)=>criterionRow(i+1,c)).join('') : (state.aiDraftTarget && state.vacancy?.criteria?.length?state.vacancy.criteria.map((c,i)=>criterionRow(i+1,c)).join(''):criterionRow(1))}</div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">${state.aiDraftTarget?'Сохранить изменения':'Создать вакансию'}</button></div></form></section></div>`;
  if(state.modal==='knowledge-term')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><h2>${state.editingTerm?'Изменить термин':'Добавить термин'}</h2><button class="button ghost" data-action="close-modal">✕</button></div><form id="knowledge-term-form"><div class="field"><label>Название термина</label><input name="name" required minlength="2" maxlength="120" value="${e(state.editingTerm?.name||'')}" placeholder="Например, Kubernetes" /></div><div class="field"><label>Синонимы через запятую</label><input name="aliases" maxlength="1200" value="${e(state.editingTerm?.aliases.join(', ')||'')}" placeholder="K8s" /></div><div class="field"><label>Пояснение (необязательно)</label><textarea name="explanation" maxlength="1000">${e(state.editingTerm?.explanation||'')}</textarea></div>${!state.editingTerm?`<div class="field"><label><input type="checkbox" name="global" /> Использовать для всех вакансий</label></div>`:''}<div class="hint">Указывайте только проверенные значения, не добавляйте в словарь информацию о кандидатах.</div><div class="form-actions"><button class="button secondary" type="button" data-action="close-modal">Отмена</button><button class="button" type="submit">Сохранить</button></div></form></section></div>`;
  if(state.modal==='expert-correction')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><h2>Ваша поправка к оценке</h2><button class="button ghost" data-action="close-modal">✕</button></div><form id="expert-correction-form"><p>Критерий: <b>${e(state.correctCriterion||'')}</b></p><div class="field"><label>Как правильнее оценить?</label><select name="corrected_level">${Object.entries(levelNames).map(([k,v])=>`<option value="${k}">${e(v)}</option>`).join('')}</select></div><div class="field"><label>Почему? (не менее 5 символов)</label><textarea name="note" required minlength="5" maxlength="2000" placeholder="Например, здесь лишь упоминание инструмента, опыт не подтверждён"></textarea></div><div class="hint">Эта заметка не меняет исходную оценку ИИ и не обучает нейросеть автоматически.</div><div class="form-actions"><button class="button secondary" type="button" data-action="close-modal">Отмена</button><button class="button" type="submit">Сохранить замечание</button></div></form></section></div>`;
  if(state.modal==='openai-key')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><h2>Подключить OpenAI API</h2><button class="button ghost" data-action="close-modal">✕</button></div><form id="openai-key-form"><div class="hint">ChatGPT Plus не содержит API-ключ. Для автоматической работы нужен отдельный API-аккаунт с оплатой. Ключ сохраняется в хранилище Windows и не входит в резервные копии.</div><div class="field"><label>Ключ OpenAI API (sk-…)</label><input name="api_key" type="password" autocomplete="off" required minlength="20" maxlength="260" /></div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Сохранить ключ</button></div></form></section></div>`;
  if(state.modal==='provider-key'&&providerAllowed(state.cloudProvider))return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><h2>Подключить ${e(cloudNames[state.cloudProvider])}</h2><button class="button ghost" data-action="close-modal">✕</button></div><form id="provider-key-form"><div class="hint">Понадобится ключ API от выбранного сервиса. Подписки на веб-чат не заменяют API-доступ. Ключ сохранится в Windows, не в резервной копии Vikora.</div><div class="field"><label>${state.cloudProvider==='gigachat_api'?'Ключ авторизации Сбера (Base64)':'Ключ API'}</label><input name="api_key" type="password" autocomplete="off" required minlength="12" maxlength="500" /></div>${state.cloudProvider==='alice_api'?'<div class="field"><label>Идентификатор каталога Yandex AI Studio (Folder ID)</label><input name="folder_id" required minlength="6" maxlength="80" /></div>':''}<div class="form-actions">${isConfigured(state.cloudProvider)?'<button type="button" class="button danger" data-action="forget-provider" data-provider="'+e(state.cloudProvider)+'">Удалить ключ</button>':''}<button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Сохранить настройки</button></div></form></section></div>`;
  if(state.modal==='ai-vacancy')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><h2>Помощь с вакансией</h2><button class="button ghost" data-action="close-modal">✕</button></div><form id="ai-vacancy-form"><div class="field"><label>Какого специалиста ищем?</label><input name="role" minlength="3" maxlength="200" required placeholder="Например, менеджер по продажам" value="${e(state.aiDraftTarget?state.vacancy?.title||'':'')}" /></div><div class="field"><label>Что важно знать о работе?</label><textarea name="notes" minlength="10" maxlength="4000" required placeholder="Задачи, условия, опыт, необходимые навыки…">${e(state.aiDraftTarget?state.vacancy?.description?.slice(0,4000)||'':'')}</textarea></div><div class="field"><label>Какая нейросеть подготовит черновик?</label><select name="provider">${Object.entries(cloudNames).map(([key,name])=>`<option value="${e(key)}" ${state.ai?.mode===key?'selected':''}>${e(name)}${isConfigured(key)?' ✓':' (не подключена)'}</option>`).join('')}</select></div><div class="hint">Выбранный провайдер получит только название роли и ваши заметки, без резюме. Результат можно отредактировать перед сохранением. Для Plus без API используйте кнопку «Скопировать для ChatGPT».</div><div class="form-actions"><button type="button" class="button secondary" data-action="copy-plus-prompt">Скопировать для ChatGPT Plus</button><button class="button" type="submit">Создать черновик через API</button></div></form></section></div>`;

  if(state.modal==='hh-settings')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>Подключение hh.ru</h2><p>Нужен зарегистрированный проект API HeadHunter и права работодателя.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="hh-settings-form"><div class="field"><label>Client ID приложения hh.ru</label><input name="client_id" minlength="8" maxlength="128" required autocomplete="off"></div><div class="field"><label>Client Secret</label><input name="client_secret" type="password" minlength="12" required autocomplete="off"></div><div class="field"><label>Контактный email разработчика</label><input name="contact_email" type="email" required autocomplete="off"></div><p class="note">При регистрации приложения в dev.hh.ru необходимо указать точный Redirect URI для локальной Vikora: http://127.0.0.1:18467/api/v1/local/hh/oauth/callback (если используется стандартный порт). Сам hh.ru должен разрешить такой адрес.</p><div class="form-actions"><button class="button secondary" type="button" data-action="close-modal">Отмена</button><button class="button" type="submit">Сохранить настройки</button></div></form></section></div>`;
  if(state.modal==='candidate')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><h2 id="modal-title">Добавить кандидата</h2><p>Используйте вымышленные данные для пилота.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="candidate-form"><div class="field"><label>ФИО</label><input name="full_name" required minlength="2" maxlength="255" placeholder="Иван Тестовый" /></div><div class="field"><label>Email</label><input name="email" type="email" maxlength="320" /></div><div class="field"><label>Телефон</label><input name="phone" maxlength="50" /></div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Добавить</button></div></form></section></div>`;
  if(state.modal==='backup')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><h2 id="modal-title">Сохранить копию Vikora</h2><p>Копия будет защищена паролем и скачана на ваш ноутбук.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="backup-form"><div class="field"><label>Придумайте пароль (минимум 12 символов)</label><input type="password" name="password" minlength="12" maxlength="256" required autocomplete="new-password" /></div><div class="field"><label>Повторите пароль</label><input type="password" name="repeat" minlength="12" maxlength="256" required autocomplete="new-password" /></div><div class="hint">Запишите пароль и храните отдельно от ноутбука. Без пароля копию невозможно восстановить. Скачанный файл лучше скопировать на внешнюю флешку.</div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Скачать защищённую копию</button></div></form></section></div>`;
  if(state.modal==='verify-backup')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><h2 id="modal-title">Проверить резервную копию</h2><p>Убедимся, что копия целая и пароль подходит. Рабочие данные не изменятся.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="verify-backup-form"><div class="field"><label>Файл .vikora</label><input type="file" name="file" accept=".vikora" required /></div><div class="field"><label>Пароль копии</label><input name="password" type="password" minlength="12" required /></div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Проверить</button></div></form></section></div>`;
  if(state.modal==='restore')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><h2 id="modal-title">Восстановить Vikora</h2><p>Возврат к данным на дату копии заменит текущие вакансии и резюме.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="restore-form"><div class="field"><label>Файл резервной копии (.vikora)</label><input type="file" name="file" accept=".vikora" required /></div><div class="field"><label>Пароль резервной копии</label><input type="password" name="password" minlength="12" required /></div><div class="field"><label>Для подтверждения напишите ВОССТАНОВИТЬ</label><input name="confirmation" required autocomplete="off" /></div><div class="hint">Vikora сначала проверит файл, затем закроется и выполнит восстановление. После этого откройте программу через ярлык снова. Текущие данные сохранятся в отдельной зашифрованной страховочной копии.</div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button danger" type="submit">Восстановить данные</button></div></form></section></div>`;
  if(state.modal==='import-exchange')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>Импорт результатов ChatGPT</h2><p>Выберите JSON-файл, который ChatGPT вернул после обработки задания.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="exchange-import-form"><div class="field"><label>Файл Vikora_результаты.json</label><input type="file" name="file" accept=".json,application/json" required /></div><div class="hint">Перед записью Vikora сверит резюме, требования, страницы и точные цитаты. Этапы найма не изменятся.</div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Проверить и импортировать</button></div></form></section></div>`;
  if(state.modal==='structured-upload')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>Импорт текстовых резюме</h2><p>Выберите один JSON или CSV с максимум 50 кандидатами, один TXT либо ZIP с максимум 50 TXT-файлами.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="structured-upload-form"><div class="field"><label>Файл данных (до 8 МБ)</label><input type="file" name="file" accept=".json,.csv,.txt,.zip" required /></div><div class="hint">CSV: колонки full_name и resume_text; JSON: список объектов с теми же полями. Исходный файл не сохраняется, текст остаётся в карточках. Проверьте ФИО и контакты после импорта.</div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Импортировать резюме</button></div></form></section></div>`;
  if(state.modal==='bulk-upload')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>Загрузить несколько резюме</h2><p>Выберите до 50 файлов PDF или DOCX (не более 10 МБ каждый, общий объём до 80 МБ).</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="bulk-upload-form"><div class="field"><label>Файлы резюме</label><input type="file" name="files" accept=".pdf,.docx" multiple required /></div><div class="hint">Каждое резюме создаёт отдельную карточку с временным именем из названия файла. Обязательно проверьте имя перед дальнейшей работой.</div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button type="submit" class="button">Загрузить выбранные файлы</button></div></form></section></div>`;
  if(state.modal==='upload')return `<div class="backdrop"><section class="modal narrow" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><div><h2 id="modal-title">Загрузка резюме</h2><p>Только PDF/DOCX, максимум 10 МБ.</p></div><button class="button ghost" data-action="close-modal">✕</button></div><form id="upload-form"><div class="field"><label>Файл резюме</label><input name="file" type="file" accept=".pdf,.docx" required /></div><div class="form-actions"><button type="button" class="button secondary" data-action="close-modal">Отмена</button><button class="button" type="submit">Загрузить</button></div></form></section></div>`;
  return '';
}
function render(){
  if(!state.user){root.innerHTML=loginView();return;}
  const content=state.qualityOpen?qualityView():state.candidate?candidateView():state.vacancy?vacancyView():dashboardView();
  root.innerHTML=shell(content);
}
async function openDashboard(){
  clearInterval(poll);clearInterval(qualityPoll);state.qualityOpen=false;state.vacancy=null;state.candidate=null;state.parsedText=null;state.modal=null;state.bulkReport=null;
  const [vacancies,privacyOverview,aiState]=await Promise.all([
    api('/api/v1/vacancies'),
    state.user?.role==='admin'?api('/api/v1/privacy/overview'):Promise.resolve(null),
    state.authMode==='local'?api('/api/v1/local/ai/status').catch(()=>null):Promise.resolve(null)
  ]);
  state.vacancies=vacancies;state.privacyOverview=privacyOverview;state.ai=aiState;render();
}
async function loadAllPages(endpoint) {
  const all=[];
  for(let offset=0;offset<20000;offset+=200){
    const rows=await api(`${endpoint}?limit=200&offset=${offset}`);
    all.push(...rows);
    if(rows.length<200)return all;
  }
  throw new Error('Слишком много карточек для одного экрана. Обратитесь к разработчику.');
}
async function openVacancy(id) {
  clearInterval(poll);const seq=++activeLoad;
  if(state.vacancy?.id!==id){state.bulkReport=null;state.hh={status:null,link:null,vacancies:[],collections:[],preview:[],page:0,collection:null};}
  state.candidate=null;state.parsedText=null;state.modal=null;
  const [vacancy,applications,queue,glossary]=await Promise.all([api(`/api/v1/vacancies/${id}`),loadAllPages(`/api/v1/vacancies/${id}/applications`),loadAllPages(`/api/v1/vacancies/${id}/review-queue`),state.authMode==='local'?api(`/api/v1/local/knowledge/terms?vacancy_id=${id}`):Promise.resolve([])]);
  if(seq!==activeLoad)return;
  Object.assign(state,{vacancy,applications,queue,glossary,resumes:[],evaluations:[],selectedApps:[]});
  if(state.authMode==='local'){const [hs,hl]=await Promise.all([api('/api/v1/local/hh/status').catch(()=>null),api(`/api/v1/local/hh/vacancies/${id}/link`).catch(()=>null)]);if(seq!==activeLoad)return;state.hh.status=hs;state.hh.link=hl;}
  render();
}
async function openCandidate(id,silent=false){
  const vacancyId=state.vacancy?.id;if(!vacancyId)return;
  const seq=++activeLoad;
  const base=`/api/v1/vacancies/${vacancyId}/applications/${id}`;
  const [resumes,evaluations]=await Promise.all([api(`${base}/resumes`),api(`${base}/evaluations`)]);
  if(seq!==activeLoad)return;
  state.candidate=state.applications.find(a=>a.id===id)||null;
  state.resumes=resumes;state.evaluations=evaluations;
  if(!silent)state.parsedText=null;
  render();
  clearInterval(poll);
  if(resumes.some(r=>r.parse_status==='pending')||evaluations.some(r=>['pending','processing'].includes(r.status))) {
    poll=setInterval(()=>{if(state.candidate?.id===id)openCandidate(id,true).catch(err=>notify(err.message,true));},4000);
  }
}
async function submitHandler(event){
  const form=event.target;if(!form?.id)return;event.preventDefault();
  const button=form.querySelector('button[type="submit"]');if(button)button.disabled=true;
  try {
    const data=new FormData(form);
    if(form.id==='login-form') {
      const token=String(data.get('token')||'').trim().replace(/^Bearer\s+/i,'');
      if(!token)throw new Error('Нужен токен доступа');
      state.token=token;state.user=await api('/api/v1/me');state.error='';await openDashboard();
    } else if(form.id==='openai-key-form') {
      await api('/api/v1/local/ai/key',{method:'POST',body:JSON.stringify({api_key:String(data.get('api_key')).trim()})});
      state.modal=null;state.ai=await api('/api/v1/local/ai/status');render();notify('Ключ сохранён в Windows');
    } else if(form.id==='provider-key-form') {
      if(!providerAllowed(state.cloudProvider))throw new Error('Неизвестный сервис');
      const body={api_key:String(data.get('api_key')||'').trim()};
      if(state.cloudProvider==='alice_api')body.folder_id=String(data.get('folder_id')||'').trim();
      await api(`/api/v1/local/ai/providers/${state.cloudProvider}/credentials`,{method:'POST',body:JSON.stringify(body)});
      state.modal=null;state.ai=await api('/api/v1/local/ai/status');render();notify('Настройки API сохранены в Windows');
    } else if(form.id==='ai-vacancy-form') {
      const provider=String(data.get('provider'));
      if(!cloudMode(provider))throw new Error('Выберите AI-провайдера');
      if(!window.confirm(`Передать название роли и заметки в ${cloudNames[provider]}? Это облачная услуга с отдельными условиями и тарифами.`))return;
      const result=await api('/api/v1/local/ai/vacancy-draft',{method:'POST',body:JSON.stringify({role:String(data.get('role')),notes:String(data.get('notes')),provider,send_to_cloud:true})});
      state.aiDraft=result;state.modal='vacancy';render();notify('Черновик готов. Проверьте текст и требования перед сохранением.');
    } else if(form.id==='knowledge-term-form') {
      const name=String(data.get('name')||'').trim();
      const aliases=String(data.get('aliases')||'').split(',').map(x=>x.trim()).filter(Boolean);
      const explanation=String(data.get('explanation')||'').trim();
      const editing=state.editingTerm;
      await api(editing?`/api/v1/local/knowledge/terms/${editing.id}`:'/api/v1/local/knowledge/terms',
        {method:editing?'PATCH':'POST',body:JSON.stringify(editing?{name,aliases,explanation}:{name,aliases,explanation,vacancy_id:data.get('global')?null:state.vacancy.id})});
      state.editingTerm=null;await openVacancy(state.vacancy.id);
      notify('Словарь обновлён. Проверьте, какие оценки требуют пересмотра.');
    } else if(form.id==='expert-correction-form') {
      await api(`/api/v1/local/knowledge/vacancies/${state.vacancy.id}/evaluations/${state.evaluations[0].id}/corrections`,
        {method:'POST',body:JSON.stringify({criterion_key:state.correctCriterion,corrected_level:String(data.get('corrected_level')),note:String(data.get('note')).trim()})});
      state.modal=null;await openCandidate(state.candidate.id,true);
      notify('Ваша поправка сохранена отдельно от AI-оценки');
    } else if(form.id==='vacancy-form') {
      const criteria=[...form.querySelectorAll('[data-criterion-row]')].map((row,i)=>({
        key:row.querySelector('[name="criterion_key"]').value.trim(),label:row.querySelector('[name="criterion_label"]').value.trim(),
        importance:row.querySelector('[name="criterion_importance"]').value,weight:Number(row.querySelector('[name="criterion_weight"]').value),sort_order:i,description:row.querySelector('[name="criterion_description"]').value.trim()||null,
      }));
      const payload={title:String(data.get('title')),description:String(data.get('description')),
        department:String(data.get('department'))||null,location:String(data.get('location'))||null,
        status:String(data.get('status')),criteria};
      const editing=Boolean(state.aiDraftTarget);
      const v=await api(editing?`/api/v1/vacancies/${state.aiDraftTarget}`:'/api/v1/vacancies',
        {method:editing?'PATCH':'POST',body:JSON.stringify(payload)});
      state.modal=null;state.aiDraft=null;state.aiDraftTarget=null;await openVacancy(v.id);
      notify(editing?'Вакансия обновлена':'Вакансия создана');
    } else if(form.id==='hh-settings-form') {
      const cfg={client_id:String(data.get('client_id')).trim(),client_secret:String(data.get('client_secret')),contact_email:String(data.get('contact_email')).trim()};
      await api('/api/v1/local/hh/settings',{method:'POST',body:JSON.stringify(cfg)});state.hh.status=await api('/api/v1/local/hh/status');state.modal=null;render();notify('Настройки сохранены. Подключите аккаунт hh.ru.');
    } else if(form.id==='candidate-form') {
      const payload={full_name:String(data.get('full_name')),email:String(data.get('email'))||null,phone:String(data.get('phone'))||null,source:'manual'};
      await api(`/api/v1/vacancies/${state.vacancy.id}/applications`,{method:'POST',body:JSON.stringify(payload)});
      state.modal=null;await openVacancy(state.vacancy.id);notify('Кандидат добавлен');
    } else if(form.id==='backup-form') {
      const password=String(data.get('password')||'');
      if(password!==String(data.get('repeat')||''))throw new Error('Пароли не совпадают');
      const response=await api('/api/v1/local/backup',{method:'POST',body:JSON.stringify({password})});
      const blob=await response.blob(),url=URL.createObjectURL(blob),anchor=document.createElement('a');
      anchor.href=url;anchor.download=`Vikora_backup_${new Date().toISOString().slice(0,10)}.vikora`;
      document.body.append(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
      state.modal=null;render();notify('Зашифрованная копия скачана. Сохраните её вне ноутбука.');
    } else if(form.id==='verify-backup-form') {
      const result=await api('/api/v1/local/verify-backup',{method:'POST',body:data});
      state.modal=null;render();notify(`Копия проверена: всё в порядке, файлов резюме — ${result.files}.`);
    } else if(form.id==='restore-form') {
      if(String(data.get('confirmation'))!=='ВОССТАНОВИТЬ')throw new Error('Для подтверждения напишите ВОССТАНОВИТЬ');
      if(!window.confirm('Текущие данные будут заменены состоянием из копии. Продолжить?'))return;
      const result=await api('/api/v1/local/restore',{method:'POST',body:data});
      clearInterval(poll);
      document.body.innerHTML=`<main style="max-width:620px;margin:12vh auto;padding:35px;font:17px system-ui"><h1>Восстановление Vikora</h1><p>${e(result.message)}</p><p>После завершения запустите программу через её значок на рабочем столе.</p></main>`;
      return;
    } else if(form.id==='exchange-import-form') {
      const file=data.get('file');
      if(!(file instanceof File)||!file.name||!file.name.toLowerCase().endsWith('.json'))throw new Error('Выберите JSON-файл результатов');
      if(file.size>4_000_000)throw new Error('Файл результатов слишком большой');
      const body=new FormData();body.append('file',file);
      const result=await api('/api/v1/local/chatgpt-exchange/import',{method:'POST',body});
      state.modal=null;await openVacancy(state.vacancy.id);
      notify(`Импортировано оценок: ${result.count}. Проверьте их перед решением по кандидатам.`);
    } else if(form.id==='structured-upload-form') {
      const file=data.get('file');
      if(!(file instanceof File)||!file.name)throw new Error('Выберите файл');
      if(file.size>8*1024*1024)throw new Error('Файл больше 8 МБ');
      if(!/\.(json|csv|txt|zip)$/i.test(file.name))throw new Error('Разрешены JSON, CSV, TXT и ZIP');
      const payload=new FormData();payload.append('file',file);
      const vacancyId=state.vacancy.id;
      const result=await api(`/api/v1/local/bulk/vacancies/${vacancyId}/structured`,{method:'POST',body:payload});
      state.modal=null;await openVacancy(vacancyId);state.bulkReport=result;render();
      notify(`Импортировано ${result.imported.length} текстовых резюме. Проверьте имена кандидатов.`);
    } else if(form.id==='bulk-upload-form') {
      const files=[...form.querySelector('[name="files"]').files];
      if(!files.length||files.length>50)throw new Error('Выберите от 1 до 50 файлов');
      if(files.reduce((sum,file)=>sum+file.size,0)>80*1024*1024)throw new Error('Общий размер больше 80 МБ');
      for(const file of files){
        if(file.size>10*1024*1024)throw new Error(`${file.name}: размер больше 10 МБ`);
        if(!/\.(docx|pdf)$/i.test(file.name))throw new Error(`${file.name}: разрешены только PDF и DOCX`);
      }
      const upload=new FormData();files.forEach(file=>upload.append('files',file));
      const result=await api(`/api/v1/local/bulk/vacancies/${state.vacancy.id}/resumes`,{method:'POST',body:upload});
      const vacancyId=state.vacancy.id;
      state.modal=null;await openVacancy(vacancyId);state.bulkReport=result;render();
      notify(`Загружено: ${result.imported.length}, ошибок: ${result.errors.length}. Проверьте имена кандидатов.`);
    } else if(form.id==='upload-form') {
      const file=data.get('file');
      if(!(file instanceof File)||!file.name)throw new Error('Выберите файл');
      if(file.size>10*1024*1024)throw new Error('Размер файла превышает 10 МБ');
      if(!/\.(docx|pdf)$/i.test(file.name))throw new Error('Разрешены только PDF и DOCX');
      const formData=new FormData();formData.append('file',file);
      const id=state.candidate.id;
      await api(`/api/v1/vacancies/${state.vacancy.id}/applications/${id}/resumes`,{method:'POST',body:formData});
      state.modal=null;await openCandidate(id);notify('Резюме загружено. Извлечение текста выполняется в фоне.');
    }
  } catch(err){if(form.id==='login-form'){state.error=err.message;state.user=null;state.token=null;render();}else notify(err.message,true);}
  finally{if(button?.isConnected)button.disabled=false;}
}
async function clickHandler(event){
  const btn=event.target.closest('[data-action]');if(!btn)return;
  if(btn.tagName==='TR'&&event.target.closest('button,select,input,a'))return;
  const action=btn.dataset.action,id=btn.dataset.id;
  if(['open-candidate','open-vacancy'].includes(action)&&!id)return;
  try{
    if(action==='logout'){
      if(state.authMode==='local') {
        await api('/api/v1/local/quit',{method:'POST'});
        sessionStorage.removeItem('vikora-desktop-session');
        clearInterval(poll);
        document.body.innerHTML='<main style="max-width:600px;margin:12vh auto;font:18px system-ui;padding:30px"><h1>Vikora завершает работу</h1><p>Можете закрыть вкладку. Чтобы продолжить, откройте Vikora через ярлык на рабочем столе.</p></main>';
        return;
      }
      if(state.authMode==='oidc') await api('/api/v1/auth/logout',{method:'POST'});
      state.token=null;state.csrf=null;state.user=null;state.vacancy=null;state.candidate=null;
      clearInterval(poll);render();
    }
    if(action==='dashboard')await openDashboard();
    if(action==='quality-open'&&state.authMode==='local'){await openQuality();return;}
    if(['quality-test-six','quality-test-all'].includes(action)&&state.authMode==='local'){
      const provider=document.getElementById('quality-provider')?.value||'heuristic';state.qualityProvider=provider;
      const cloud=cloudMode(provider);
      if(cloud&&!window.confirm('Проверить 6 ВЫМЫШЛЕННЫХ резюме через '+(cloudNames[provider]||provider)+'? Возможна оплата запросов по API. Настоящие резюме не передаются.'))return;
      if(cloud&&action==='quality-test-all')throw new Error('Для облачного ИИ выбирайте проверку 6 примеров (ограничение расходов).');
      const count=action==='quality-test-six'?6:state.qualityCases.length;
      state.qualityReport=null;
      state.qualityStatus=await api('/api/v1/local/quality/runs',{method:'POST',body:JSON.stringify({provider,case_ids:state.qualityCases.slice(0,count).map(c=>c.id),confirm_paid_cloud_test:cloud})});
      render();startQualityPolling();notify('Проверка началась. Резюме кандидатов не используются.');return;
    }
    if(action==='quality-view'&&state.authMode==='local'){
      state.qualityReport=await api(`/api/v1/local/quality/runs/${encodeURIComponent(id)}`);render();return;
    }
    if(action==='quality-download'&&state.qualityReport){
      const content=JSON.stringify(state.qualityReport,null,2),blob=new Blob([content],{type:'application/json'});
      const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Vikora_quality_'+state.qualityReport.provider+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;
    }


    if(action==='hh-settings'&&state.authMode==='local'){state.modal='hh-settings';render();}
    if(action==='hh-disconnect'&&state.authMode==='local'){
      if(!window.confirm('Отключить hh.ru? Уже импортированные кандидаты останутся в Vikora.'))return;
      await api('/api/v1/local/hh/connection',{method:'DELETE'});state.hh={status:await api('/api/v1/local/hh/status'),link:state.hh.link,vacancies:[],collections:[],preview:[],page:0,collection:null};render();notify('Аккаунт hh.ru отключён');
    }
    if(action==='hh-connect'&&state.authMode==='local'){
      const popup=window.open('about:blank','vikora-hh-connect');
      try{const result=await api('/api/v1/local/hh/authorize',{method:'POST'});
        if(popup)popup.location.href=result.url;else window.location.href=result.url;
        notify('Войдите в hh.ru и вернитесь в Vikora. Затем обновите страницу.');
      }catch(ex){popup?.close();throw ex;}
    }
    if(action==='hh-load-vacancies'&&state.authMode==='local'){
      const result=await api('/api/v1/local/hh/vacancies');state.hh.vacancies=result.items;render();
      notify(`Доступных вакансий hh.ru: ${result.items.length}`);
    }
    if(action==='hh-link'&&state.authMode==='local'){
      const hhId=document.getElementById('hh-vacancy-select')?.value;
      if(!hhId)throw new Error('Выберите вакансию hh.ru');
      const response=await api(`/api/v1/local/hh/vacancies/${state.vacancy.id}/link`,{method:'POST',body:JSON.stringify({hh_vacancy_id:hhId})});
      state.hh.link=response;state.hh.collections=[];state.hh.preview=[];render();notify('Вакансия hh.ru связана с Vikora');
    }
    if(action==='hh-collections'&&state.authMode==='local'){
      const response=await api(`/api/v1/local/hh/vacancies/${state.vacancy.id}/collections`);
      state.hh.collections=response.items;state.hh.preview=[];render();notify('Выберите группу откликов');
    }
    if(action==='hh-preview'&&state.authMode==='local'){
      state.hh.collection=document.getElementById('hh-collection-select')?.value;
      if(!state.hh.collection)throw new Error('Выберите группу откликов');state.hh.page=0;
      const response=await api(`/api/v1/local/hh/vacancies/${state.vacancy.id}/preview?collection_id=${encodeURIComponent(state.hh.collection)}&page=0`);
      state.hh.preview=response.items;render();notify(`Найдено откликов на странице: ${response.items.length}`);
    }
    if(['hh-next','hh-prev'].includes(action)&&state.authMode==='local'){
      state.hh.page=Math.max(0,state.hh.page+(action==='hh-next'?1:-1));
      const response=await api(`/api/v1/local/hh/vacancies/${state.vacancy.id}/preview?collection_id=${encodeURIComponent(state.hh.collection)}&page=${state.hh.page}`);
      state.hh.preview=response.items;render();notify(`Откликов на странице: ${response.items.length}`);
    }
    if(action==='hh-import'&&state.authMode==='local'){
      const selected=[...document.querySelectorAll('input[name="hh-choice"]:checked')].map(el=>el.value);
      if(!selected.length)throw new Error('Отметьте нужные отклики');
      if(selected.length>50)throw new Error('За один раз можно импортировать до 50 резюме');
      if(!window.confirm(`Получить полные тексты ${selected.length} резюме с hh.ru? Это может отметить отклики просмотренными. Продолжить?`))return;
      const result=await api(`/api/v1/local/hh/vacancies/${state.vacancy.id}/import`,{method:'POST',body:JSON.stringify({collection_id:state.hh.collection,page:state.hh.page,negotiation_ids:selected,confirm_resume_view:true})});
      const vacancyId=state.vacancy.id;await openVacancy(vacancyId);
      notify(`Импортировано: ${result.imported.length}; дубли: ${result.duplicates.length}; пропущено: ${result.skipped.length}`);
      state.bulkReport={imported:result.imported,duplicates:result.duplicates,errors:result.skipped.map(x=>({filename:'hh.ru: '+x.negotiation_id,reason:x.reason}))};render();
    }
    if(action==='ai-vacancy'&&state.authMode==='local'){state.aiDraftTarget=null;state.modal='ai-vacancy';render();}
    if(action==='ai-edit-vacancy'&&state.authMode==='local'){state.aiDraftTarget=state.vacancy.id;state.modal='ai-vacancy';render();}
    if(action==='setup-openai'&&state.authMode==='local'){state.modal='openai-key';render();}
    if(action==='setup-provider'&&state.authMode==='local'&&providerAllowed(btn.dataset.provider)){
      state.cloudProvider=btn.dataset.provider;state.modal='provider-key';render();
    }
    if(action==='forget-provider'&&state.authMode==='local'&&providerAllowed(btn.dataset.provider)){
      if(!window.confirm(`Удалить ключ ${cloudNames[btn.dataset.provider]} из Vikora?`))return;
      await api(`/api/v1/local/ai/providers/${btn.dataset.provider}/credentials`,{method:'DELETE'});
      state.modal=null;state.ai=await api('/api/v1/local/ai/status');render();notify('Ключ удалён');
    }
    if(action==='mode-provider'&&state.authMode==='local'&&providerAllowed(btn.dataset.provider)){
      if(!window.confirm(`Выбрать ${cloudNames[btn.dataset.provider]} для обработки резюме? Каждый документ будет отправлен только после отдельного подтверждения.`))return;
      await api('/api/v1/local/ai/mode',{method:'POST',body:JSON.stringify({mode:btn.dataset.provider})});
      state.ai=await api('/api/v1/local/ai/status');render();notify('AI-провайдер выбран');
    }

    if(action==='copy-resume-plus'&&state.authMode==='local'){
      if(!window.confirm('Скопировать шаблон запроса для ChatGPT Plus? В нём НЕТ текста резюме. Для анализа вы вставите обезличенное резюме вручную, только если это разрешено.'))return;
      const criteria=state.vacancy?.criteria.map(c=>`- ${c.label} (${c.importance==='must'?'обязательное':'желательное'})`).join('\n')||'';
      const prompt=`Ты помощник HR. Сравни резюме с требованиями вакансии «${state.vacancy.title}».\nТребования:\n${criteria}\n\nДля каждого требования укажи: подтверждено / частично / неизвестно, короткую точную цитату и вопросы для интервью. Не делай автоматических решений о найме. Если информации нет, пиши «неизвестно». Не используй возраст, пол, происхождение или здоровье.\n\nДалее я самостоятельно вставлю ОБЕЗЛИЧЕННЫЙ текст резюме (уберу ФИО, контакты и другую ненужную личную информацию):`;
      await navigator.clipboard.writeText(prompt);notify('Запрос скопирован. Вставьте его в ChatGPT, затем обезличенный текст резюме.');
    }
    if(action==='copy-plus-prompt'&&state.authMode==='local'){
      const form=document.getElementById('ai-vacancy-form');
      const role=form?.querySelector('[name="role"]')?.value||'';
      const notes=form?.querySelector('[name="notes"]')?.value||'';
      if(role.length<3||notes.length<10)throw new Error('Сначала заполните оба поля');
      const prompt=`Ты помощник HR. Создай на русском языке подробное, но правдивое описание вакансии «${role}» на основе данных: ${notes}. Отдельно укажи 5–10 проверяемых критериев отбора, разделяя обязательные и желательные. Не придумывай факты и не используй дискриминационные критерии. Результат я вручную перенесу в Vikora.`;
      await navigator.clipboard.writeText(prompt);notify('Запрос скопирован. Откройте ChatGPT и вставьте его.');
    }
    if(action==='mode-basic'&&state.authMode==='local'){
      await api('/api/v1/local/ai/mode',{method:'POST',body:JSON.stringify({mode:'heuristic'})});
      state.ai=await api('/api/v1/local/ai/status');render();notify('Обычная проверка включена');
    }
    if(action==='mode-local'&&state.authMode==='local'){
      await api('/api/v1/local/ai/mode',{method:'POST',body:JSON.stringify({mode:'ollama_local'})});
      state.ai=await api('/api/v1/local/ai/status');render();notify('Локальный ИИ включён');
    }
    if(action==='mode-openai'&&state.authMode==='local'){
      if(!window.confirm('Включить OpenAI API? За каждый запрос API может взиматься плата отдельно от ChatGPT Plus. При оценке резюме вы будете подтверждать отправку текста.'))return;
      await api('/api/v1/local/ai/mode',{method:'POST',body:JSON.stringify({mode:'openai_api'})});
      state.ai=await api('/api/v1/local/ai/status');render();notify('OpenAI API выбран.');
    }
    if(action==='forget-openai'&&state.authMode==='local'){
      if(!window.confirm('Удалить API-ключ из Vikora?'))return;
      await api('/api/v1/local/ai/key',{method:'DELETE'});
      state.ai=await api('/api/v1/local/ai/status');render();notify('API-ключ удалён');
    }
    if(action==='refresh-ai' && state.authMode==='local'){
      state.ai=await api('/api/v1/local/ai/status');render();notify('Проверка локальной модели завершена');
    }
    if(action==='enable-ai' && state.authMode==='local'){
      if(!window.confirm('Включить локальный ИИ? Резюме будет обрабатываться на этом ноутбуке. Проверьте, что Ollama установлена и доступна только на локальном адресе.'))return;
      await api('/api/v1/local/ai/mode',{method:'POST',body:JSON.stringify({enabled:true})});
      state.ai=await api('/api/v1/local/ai/status');render();notify('Локальная нейросеть включена');
    }
    if(action==='disable-ai' && state.authMode==='local'){
      await api('/api/v1/local/ai/mode',{method:'POST',body:JSON.stringify({enabled:false})});
      state.ai=await api('/api/v1/local/ai/status');render();notify('Включена обычная проверка');
    }
    if(action==='refresh-privacy'&&state.user?.role==='admin'){state.privacyOverview=await api('/api/v1/privacy/overview');render();}
    if(action==='new-term'&&state.authMode==='local'){state.editingTerm=null;state.modal='knowledge-term';render();}
    if(action==='edit-term'&&state.authMode==='local'){
      state.editingTerm=state.glossary.find(x=>x.id===id);
      if(!state.editingTerm)throw new Error('Термин не найден');
      state.modal='knowledge-term';render();
    }
    if(action==='remove-term'&&state.authMode==='local'){
      if(!window.confirm('Удалить термин? Старые оценки останутся в истории, но потребуется новая оценка.'))return;
      await api(`/api/v1/local/knowledge/terms/${id}`,{method:'DELETE'});
      await openVacancy(state.vacancy.id);notify('Термин удалён');
    }
    if(action==='correct-evaluation'&&state.authMode==='local'){
      state.correctCriterion=id;state.modal='expert-correction';render();
    }
    if(action==='edit-vacancy'){
      state.aiDraft=null;state.aiDraftTarget=state.vacancy.id;state.modal='vacancy';render();
    }
    if(action==='open-vacancy')await openVacancy(id);
    if(action==='back-to-vacancy')await openVacancy(state.vacancy.id);
    if(action==='refresh-vacancy')await openVacancy(state.vacancy.id);
    if(action==='open-candidate')await openCandidate(id);
    if(action==='refresh-candidate')await openCandidate(state.candidate.id,true);
    if(action==='new-vacancy'){state.aiDraft=null;state.aiDraftTarget=null;state.modal='vacancy';render();}
    if(action==='make-backup'&&state.authMode==='local'){state.modal='backup';render();}
    if(action==='start-restore'&&state.authMode==='local'){state.modal='restore';render();}
    if(action==='verify-backup'&&state.authMode==='local'){state.modal='verify-backup';render();}
    if(action==='select-exchange-all'&&state.authMode==='local'){
      const visible=[...document.querySelectorAll('tr[data-candidate-row]:not([hidden]) input[name="exchange-choice"]')];
      if(!visible.length)throw new Error('Нет кандидатов для выбора');
      const select=!visible.every(item=>item.checked);
      visible.forEach(item=>{item.checked=select;});
      state.selectedApps=[...document.querySelectorAll('input[name="exchange-choice"]:checked')].map(item=>item.value);
      notify(`Выбрано кандидатов: ${state.selectedApps.length}`);
    }
    if(action==='export-exchange'&&state.authMode==='local'){
      if(!state.selectedApps.length)throw new Error('Отметьте галочками кандидатов в таблице');
      if(state.selectedApps.length>20)throw new Error('Для файла ChatGPT Plus выберите до 20 кандидатов (для обычной оценки — до 50)');
      if(!window.confirm(`Скачать файл с текстами ${state.selectedApps.length} резюме? Файл может содержать личные данные. После загрузки в ChatGPT информация покинет ваш ноутбук. Продолжить?`))return;
      const response=await api('/api/v1/local/chatgpt-exchange/export',{method:'POST',body:JSON.stringify({vacancy_id:state.vacancy.id,application_ids:state.selectedApps})});
      const blob=await response.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');
      link.href=url;link.download=`Vikora_задание_${new Date().toISOString().slice(0,10)}.json`;
      document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
      notify('Задание скачано. Загрузите его в ChatGPT и попросите вернуть Vikora_результаты.json.');
    }
    if(action==='export-resume-exchange'&&state.authMode==='local'){
      if(!window.confirm('Скачать задание с текстом выбранного резюме? После загрузки в ChatGPT содержащаяся в нём информация покинет ваш ноутбук. Продолжить?'))return;
      const response=await api('/api/v1/local/chatgpt-exchange/export',{method:'POST',body:JSON.stringify({
        vacancy_id:state.vacancy.id,selections:[{application_id:state.candidate.id,resume_id:id}]
      })});
      const blob=await response.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');
      link.href=url;link.download=`Vikora_задание_${new Date().toISOString().slice(0,10)}.json`;
      document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
      notify('Файл задания скачан. Прикрепите его к этому чату.');
    }
    if(action==='import-exchange'&&state.authMode==='local'){state.modal='import-exchange';render();}
    if(action==='bulk-upload'&&state.authMode==='local'){state.modal='bulk-upload';render();}
    if(action==='structured-upload'&&state.authMode==='local'){state.modal='structured-upload';render();}
    if(action==='dismiss-bulk-report'){state.bulkReport=null;render();}
    if(action==='rename-candidate'&&state.authMode==='local'&&state.candidate){
      const name=window.prompt('Введите правильное имя кандидата (проверьте его по резюме):',state.candidate.candidate.full_name);
      if(name!==null){
        if(name.trim().length<2||name.trim().length>255)throw new Error('Имя должно содержать от 2 до 255 символов');
        const result=await api(`/api/v1/local/bulk/vacancies/${state.vacancy.id}/applications/${state.candidate.id}/candidate`,
          {method:'PATCH',body:JSON.stringify({full_name:name.trim()})});
        state.candidate.candidate.full_name=result.full_name;
        state.applications=state.applications.map(a=>a.id===state.candidate.id?state.candidate:a);
        render();notify('Имя обновлено');
      }
    }
    if(action==='download-csv'&&state.authMode==='local'){
      if(!window.confirm('Скачать таблицу результатов? Она содержит имена кандидатов. Сохраните файл в защищённом месте.'))return;
      const response=await api(`/api/v1/local/bulk/vacancies/${state.vacancy.id}/results.csv`);
      const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');
      a.href=url;a.download=`Vikora_результаты_${new Date().toISOString().slice(0,10)}.csv`;
      document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
      notify('Таблица скачана. Откройте её в Excel.');
    }
    if(action==='bulk-evaluate'&&state.authMode==='local'){
      if(!state.selectedApps.length)throw new Error('Сначала отметьте кандидатов в таблице');
      if(state.selectedApps.length>50)throw new Error('За один раз можно оценить не более 50 кандидатов');
      const mode=state.ai?.mode||'heuristic',cloud=cloudMode(mode);
      if(!state.vacancy.criteria.length)throw new Error('Укажите требования вакансии перед оценкой');
      const message=cloud
        ? `Передать тексты ${state.selectedApps.length} выбранных резюме в ${cloudNames[mode]}? Резюме могут содержать персональные данные. Убедитесь, что имеете право их передать, и учтите стоимость API.`
        : `Поставить ${state.selectedApps.length} выбранных резюме в очередь оценки?`;
      if(!window.confirm(message))return;
      const response=await api(`/api/v1/local/bulk/vacancies/${state.vacancy.id}/assessments`,
        {method:'POST',body:JSON.stringify({application_ids:state.selectedApps,allow_cloud_transmission:cloud})});
      const vacancyId=state.vacancy.id;
      await openVacancy(vacancyId);
      notify(`В очереди: ${response.queued.length}. Пока не готовы к оценке: ${response.skipped.length}.`);
      if(response.skipped.length)state.bulkReport={imported:[],duplicates:[],errors:response.skipped.map(v=>({filename:'Кандидат '+v.application_id.slice(0,8),reason:v.reason}))};
      render();
      if(response.queued.length){
        let checks=0;clearInterval(poll);
        poll=setInterval(async()=>{
          if(state.vacancy?.id!==vacancyId||state.candidate){clearInterval(poll);return;}
          try{
            state.queue=await api(`/api/v1/vacancies/${vacancyId}/review-queue`);render();
            checks++;
            if(checks>=30||!state.queue.some(q=>['pending','processing'].includes(q.status)))clearInterval(poll);
          }catch(error){clearInterval(poll);notify(error.message,true);}
        },5000);
      }
    }
    if(action==='new-candidate'){state.modal='candidate';render();}
    if(action==='upload-resume'){state.modal='upload';render();}
    if(action==='close-modal'){state.modal=null;render();}
    if(action==='add-criterion'){
      const holder=document.getElementById('criteria-rows');
      const next=holder.querySelectorAll('[data-criterion-row]').length+1;
      holder.insertAdjacentHTML('beforeend',criterionRow(next));
    }
    if(action==='remove-criterion')btn.closest('[data-criterion-row]')?.remove();
    if(action==='change-retention' && state.user?.role==='admin' && state.candidate){
      const candidateId=state.candidate.candidate.id;
      const value=window.prompt('Новый срок хранения в днях (0–730). Ноль означает удаление при следующем запуске очистки:','180');
      if(value!==null){
        if(!/^\d{1,4}$/.test(value.trim())||Number(value)>730)throw new Error('Введите целое число от 0 до 730');
        const response=await api(`/api/v1/privacy/candidates/${candidateId}/retention`,
          {method:'PATCH',body:JSON.stringify({days:Number(value)})});
        state.candidate.candidate.retention_until=response.retention_until;
        render();notify('Срок хранения обновлён');
      }
    }
    if(action==='delete-candidate' && state.user?.role==='admin' && state.candidate){
      const candidate=state.candidate.candidate;
      const confirmation=window.prompt(`Удалить данные кандидата «${candidate.full_name}» из всех связанных вакансий? Для подтверждения введите ФИО точно:`, '');
      if(confirmation!==null){
        if(confirmation!==candidate.full_name)throw new Error('Удаление отменено: ФИО не совпало');
        btn.disabled=true;
        const result=await api(`/api/v1/privacy/candidates/${candidate.id}?reason=administrative`,{
          method:'DELETE',headers:{'X-Confirm-Candidate-Id':candidate.id}});
        const previousVacancy=state.vacancy.id;
        await openVacancy(previousVacancy);
        notify(result.state==='completed'?'Кандидат и файлы удалены':'Записи удалены. Очистка файлов ещё выполняется; код операции: '+result.request_id);
      }
    }
    if(action==='evaluate'){
      btn.disabled=true;
      const provider=state.authMode==='local'?state.ai?.mode:null;
      const cloud=cloudMode(provider);
      if(cloud&&!window.confirm(`Отправить ТЕКСТ этого резюме в ${cloudNames[provider]}? Возможны персональные данные кандидата. Подтвердите, что имеете право их передавать. Плата за API — по тарифу провайдера.`))return;
      await api(`/api/v1/vacancies/${state.vacancy.id}/applications/${state.candidate.id}/evaluations`,{method:'POST',body:JSON.stringify({resume_id:id,send_resume_to_openai:provider==='openai_api',send_resume_to_cloud:provider!=='openai_api'&&cloud})});
      notify('Оценка поставлена в очередь');await openCandidate(state.candidate.id,true);
    }
    if(action==='view-text'){
      const res=await api(`/api/v1/vacancies/${state.vacancy.id}/applications/${state.candidate.id}/resumes/${id}/text`);
      state.parsedText=res;render();
    }
    if(action==='download'){
      const r=state.resumes.find(r=>r.id===id);
      const response=await api(`/api/v1/vacancies/${state.vacancy.id}/applications/${state.candidate.id}/resumes/${id}/download`);
      const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');
      a.href=url;a.download=r?.original_filename||'resume';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }
  } catch(err){notify(err.message,true);}
}
function filterCandidates(){
  const needle=(document.getElementById('candidate-search')?.value||'').trim().toLowerCase();
  const stage=document.getElementById('stage-filter')?.value||'';
  document.querySelectorAll('[data-candidate-row]').forEach(row=>{
    row.hidden=!(row.dataset.name.includes(needle)&&(!stage||row.dataset.stage===stage));
  });
}
async function changeHandler(event){
  if(event.target?.name==='exchange-choice'){
    state.selectedApps=[...document.querySelectorAll('input[name="exchange-choice"]:checked')].map(el=>el.value);
    return;
  }
  if(['stage-filter','candidate-search'].includes(event.target.id)){filterCandidates();return;}
  if(event.target.id==='stage-select'&&state.candidate){
    const candidateId=state.candidate.id;
    const target=event.target;target.disabled=true;
    try{
      const result=await api(`/api/v1/vacancies/${state.vacancy.id}/applications/${candidateId}`,{method:'PATCH',body:JSON.stringify({stage:target.value})});
      state.candidate=result;state.applications=state.applications.map(a=>a.id===candidateId?result:a);
      render();notify('Этап кандидата обновлён');
    }catch(err){target.disabled=false;notify(err.message,true);}
  }
}
root.addEventListener('submit',submitHandler);
root.addEventListener('click',clickHandler);
root.addEventListener('change',changeHandler);
root.addEventListener('input',event=>{if(event.target.id==='candidate-search')filterCandidates();});
root.addEventListener('keydown',event=>{
  if(event.target?.matches('[data-candidate-row]')&&['Enter',' '].includes(event.key)){
    event.preventDefault();openCandidate(event.target.dataset.id).catch(err=>notify(err.message,true));
  }
  if(event.key==='Escape'&&state.modal){state.modal=null;render();}
});
window.addEventListener('pagehide',()=>{clearInterval(poll);clearInterval(qualityPoll);});
async function bootstrap() {
  try {
    const method = await api('/api/v1/auth/method');
    state.authMode = method.mode;
    if(state.authMode==='local') {
      const fragment = new URLSearchParams(window.location.hash.slice(1));
      const launchedToken = fragment.get('vikora');
      if(launchedToken) {
        history.replaceState(null, '', window.location.pathname + window.location.search);
        sessionStorage.setItem('vikora-desktop-session', launchedToken);
      }
      state.token = launchedToken || sessionStorage.getItem('vikora-desktop-session');
      if(state.token) {
        try {
          state.user = await api('/api/v1/me');
          state.error='';
          await openDashboard();
          return;
        } catch(err) {
          sessionStorage.removeItem('vikora-desktop-session');
          state.token=null;
          state.error='Сессия завершилась. Запустите программу через ярлык ещё раз.';
        }
      }
      render();
      return;
    }
    if(state.authMode==='oidc') {
      try {
        const session = await api('/api/v1/auth/session');
        state.csrf = session.csrf_token;
        state.user = session.user;
        await openDashboard();
        return;
      } catch(err) {
        if(!/No valid browser session/.test(err.message)) state.error=err.message;
      }
    }
  } catch(err) {state.error='Не удалось проверить режим авторизации: '+err.message;}
  render();
}
bootstrap();
