"""Async DB worker for queued Vikora assessments. For a demo run one worker.

PostgreSQL SKIP LOCKED supports multiple concurrent workers; SQLite is for tests.
"""
import logging
import time
from datetime import datetime, timezone

from sqlalchemy import select

from app.core.config import settings
from app.db import SessionLocal
from app.models import CriterionEvaluation, Evaluation, Resume
from app.services.evaluate import (EvaluationFailure, heuristic_assess, model_assess,
                                   score_results, summary_text, validate_grounding)

log = logging.getLogger("vikora-evaluation-worker")


def process_next() -> bool:
    with SessionLocal.begin() as db:
        assessment = db.scalar(select(Evaluation).where(Evaluation.status == "pending")
                               .order_by(Evaluation.created_at, Evaluation.id)
                               .with_for_update(skip_locked=True).limit(1))
        if assessment is None:
            return False
        assessment.status = "processing"
        evaluation_id = assessment.id
        resume_id = assessment.resume_id
        model_name = assessment.model_name
        snapshot = assessment.criteria_snapshot
        provider = snapshot.get("provider", "heuristic" if assessment.model_name == "local-exact-match-v1" else "openai_compatible")

    # In-flight assessment must follow the originally enqueued provider/version.
    try:
        if provider == "ollama_local" and settings.ai_provider != provider:
            raise EvaluationFailure("Локальный AI отключён. Включите его и запустите оценку заново.")
        if provider == "openai_compatible" and (settings.ai_provider != provider or not settings.ai_allow_resume_transmission):
            raise EvaluationFailure("Configured AI provider is no longer available")
        if provider == "openai_api" and (settings.ai_provider != provider or not snapshot.get("cloud_consent")):
            raise EvaluationFailure("Облачная оценка отключена или не подтверждена")
        if provider in {"deepseek_api", "gigachat_api", "alice_api"} and (settings.ai_provider != provider or not snapshot.get("cloud_consent")):
            raise EvaluationFailure("Облачная оценка отключена или не подтверждена")
        with SessionLocal() as db:
            resume = db.get(Resume, resume_id)
            if resume is None or resume.parse_status != "parsed" or not (resume.parsed_fields or {}).get("pages"):
                raise EvaluationFailure("Resume is no longer available for evaluation")
            pages = resume.parsed_fields["pages"]
        criteria = snapshot["criteria"]
        if not criteria:
            raise EvaluationFailure("Assessment criteria snapshot is empty")
        if provider == "heuristic":
            response = heuristic_assess(criteria, pages)
        elif provider == "ollama_local":
            from app.services.local_ai import ollama_assess
            response = ollama_assess(criteria, pages, model_name)
        elif provider == "openai_compatible":
            response = model_assess(criteria, pages, model_name)
        elif provider == "openai_api":
            from app.services.openai_bridge import evaluate_resume_with_api
            response = evaluate_resume_with_api(criteria, pages, model_name)
        elif provider in {"deepseek_api", "gigachat_api", "alice_api"}:
            from app.services.cloud_providers import evaluate_resume
            response = evaluate_resume(provider, criteria, pages, model_name)
        else:
            raise EvaluationFailure("Неизвестный режим оценки")
        results = validate_grounding(response, criteria, pages)
        known_score, coverage = score_results(criteria, results)
        score = known_score if coverage >= 60 else None
        summary = summary_text(score, coverage, provider)
    except EvaluationFailure as exc:
        log.warning("Evaluation failed id=%s (%s)", evaluation_id, type(exc).__name__)
        failure = str(exc)
        results, score, summary = [], None, None
    except Exception:
        log.exception("Unexpected failure during evaluation id=%s", evaluation_id)
        failure = "Unexpected evaluation processing error"
        results, score, summary = [], None, None
    else:
        failure = None

    with SessionLocal.begin() as db:
        evaluation = db.get(Evaluation, evaluation_id)
        if evaluation is None:
            return True
        # Do not resurrect cancelled/deleted assessments.
        if evaluation.status != "processing":
            return True
        if failure is None:
            for item in results:
                db.add(CriterionEvaluation(evaluation_id=evaluation_id, criterion_key=item.criterion_key,
                                           match_level=item.match_level,
                                           evidence=[p.model_dump() for p in item.evidence], rationale=item.rationale))
            evaluation.overall_score = score
            evaluation.explanation = summary
            evaluation.status = "completed"
        else:
            evaluation.status = "failed"
            evaluation.error_message = failure[:500]
        evaluation.finished_at = datetime.now(timezone.utc)
    return True


def main():
    logging.basicConfig(level=logging.INFO)
    log.info("Vikora evaluation worker started")
    while True:
        try:
            found = process_next()
        except Exception:
            log.exception("Evaluation worker error; will retry")
            found = False
        if not found:
            time.sleep(2)


if __name__ == "__main__":
    main()
