"""Retention and private-file cleanup worker. Run after API/DB are ready.

Usage:
    python -m app.worker.lifecycle --once
    python -m app.worker.lifecycle --report
    python -m app.worker.lifecycle        # scheduled loop
"""
from __future__ import annotations

import argparse
import logging
import time
from datetime import datetime, timedelta, timezone
from sqlalchemy import delete, or_
from app.models import OIDCLoginAttempt, WebSession

from app.db import SessionLocal
from app.services.privacy import (
    cleanup_one_blob, prune_old_receipts, purge_expired_batch, retention_overview,
)

log = logging.getLogger("vikora-privacy-worker")


def run_once() -> tuple[int, int]:
    with SessionLocal() as db:
        requests = purge_expired_batch(db)
    cleaned = 0
    with SessionLocal() as db:
        for _ in range(200):
            if not cleanup_one_blob(db):
                break
            cleaned += 1
        prune_old_receipts(db)
        # Expired pre-login requests and revoked sessions should not grow forever.
        now = datetime.now(timezone.utc)
        db.execute(delete(OIDCLoginAttempt).where(OIDCLoginAttempt.expires_at < now))
        db.execute(delete(WebSession).where(or_(
            WebSession.expires_at < now - timedelta(days=1),
            WebSession.revoked_at < now - timedelta(days=1),
        )))
        db.commit()
    return len(requests), cleaned


def main():
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--report", action="store_true")
    args = parser.parse_args()
    if args.report:
        with SessionLocal() as db:
            print(retention_overview(db))  # aggregate counts only: no identifying fields
        return
    if args.once:
        purged, cleaned = run_once()
        print(f"Expired candidates purged: {purged}; private files cleaned: {cleaned}")
        return
    log.info("Vikora privacy retention worker started")
    while True:
        try:
            purged, cleaned = run_once()
            if purged or cleaned:
                log.info("Lifecycle run: %d expired candidate purges, %d file removals", purged, cleaned)
        except Exception:
            log.exception("Lifecycle worker failed; retrying next cycle")
        time.sleep(60)


if __name__ == "__main__":
    main()
