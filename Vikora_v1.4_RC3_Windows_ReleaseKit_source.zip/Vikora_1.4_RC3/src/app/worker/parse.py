"""Run with `python -m app.worker.parse`: DB-backed worker for the internal MVP.

PostgreSQL SELECT FOR UPDATE SKIP LOCKED enables multiple safe workers. For the
initial prototype this intentionally avoids external queue infrastructure.
"""
import logging
import time
from datetime import datetime, timezone

from sqlalchemy import select

from app.db import SessionLocal
from app.models import Resume
from app.services.parse_resume import ParseFailure, extract_pages
from app.services.uploads import blob_path

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("resume-worker")


def process_next() -> bool:
    with SessionLocal.begin() as db:
        resume = db.scalar(select(Resume).where(Resume.parse_status == "pending")
                           .order_by(Resume.created_at, Resume.id)
                           .with_for_update(skip_locked=True).limit(1))
        if resume is None:
            return False
        resume.parse_status = "processing"
        resume_id = resume.id
        storage_key = resume.storage_key
        mime = resume.mime_type
    try:
        pages = extract_pages(blob_path(storage_key), mime)
        state = "parsed"
        fields = {"pages": pages, "char_count": sum(len(p["text"]) for p in pages)}
    except (ParseFailure, OSError, ValueError, RuntimeError) as exc:
        log.warning("Could not parse resume %s: %s", resume_id, type(exc).__name__)
        state = "failed"
        fields = {"error": str(exc) if isinstance(exc, ParseFailure) else "Processing failure"}
    with SessionLocal.begin() as db:
        resume = db.get(Resume, resume_id)
        if resume is None:
            return True  # record deleted after claim
        resume.parse_status = state
        resume.parsed_fields = fields
    return True


def main():
    log.info("Resume parser worker started")
    while True:
        try:
            found = process_next()
        except Exception:
            log.exception("Worker error; will retry")
            found = False
        if not found:
            time.sleep(2)


if __name__ == "__main__":
    main()
