"""A synthetic, isolated user/token/database set for each test."""
import os
os.environ["APP_ENV"] = "development"
os.environ["AUTH_MODE"] = "dev"
os.environ["MALWARE_SCAN_MODE"] = "disabled"
os.environ["DEV_AUTH_SECRET"] = "tests-only-local-development-secret-please-never-reuse-this-00001"

from datetime import datetime, timedelta, timezone
import jwt
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app import models  # noqa: F401
from app.core import config
from app.db import Base, get_db
from app.main import app


@pytest.fixture
def client(tmp_path, monkeypatch):
    engine = create_engine(
        "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )

    @event.listens_for(engine, "connect")
    def enable_fk(dbapi_conn, _):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    subjects = {
        "owner": ("owner@example.invalid", "recruiter"),
        "other": ("other@example.invalid", "recruiter"),
        "reviewer": ("reviewer@example.invalid", "reviewer"),
        "admin": ("admin@example.invalid", "admin"),
    }
    with Session.begin() as db:
        users = {}
        for subject, (email, role) in subjects.items():
            user = models.UserAccount(email=email, full_name=subject.title(),
                                      role=role, sso_subject=subject)
            db.add(user)
            db.flush()
            users[subject] = user.id

    def token(subject):
        now = datetime.now(timezone.utc)
        return jwt.encode({"sub": subject, "iat": now,
                           "exp": now + timedelta(minutes=60),
                           "iss": "internal-ai-recruiter-dev",
                           "aud": "internal-ai-recruiter-api"},
                          config.settings.dev_auth_secret, algorithm="HS256")

    def override_db():
        with Session() as session:
            yield session

    monkeypatch.setattr(config.settings, "upload_dir", str(tmp_path / "private"))
    app.dependency_overrides[get_db] = override_db
    try:
        with TestClient(app) as client:
            client.headers.update({"Authorization": f"Bearer {token('owner')}"})
            client.tokens = {name: token(name) for name in subjects}
            client.user_ids = users
            client.test_sessionmaker = Session
            yield client
    finally:
        app.dependency_overrides.clear()
        Base.metadata.drop_all(engine)
        engine.dispose()
