from io import BytesIO
from functools import lru_cache
import uuid
from pathlib import Path

from docx import Document

from app.models import AuditEvent, Resume, VacancyAccess
from app.worker import parse as worker


def _vacancy(client):
    response = client.post("/api/v1/vacancies", json={
        "title": "Python developer", "description": "Development of an internal backend API",
        "criteria": [{"key": "python", "label": "Python", "importance": "must", "weight": 8}],
    })
    assert response.status_code == 201, response.text
    return response.json()["id"]


def _application(client, vacancy):
    response = client.post(f"/api/v1/vacancies/{vacancy}/applications", json={
        "full_name": "Synthetic Candidate", "email": "test@example.invalid", "source": "manual",
    })
    assert response.status_code == 201, response.text
    return response.json()["id"]


@lru_cache(maxsize=1)
def _docx():
    buffer = BytesIO()
    doc = Document()
    doc.add_paragraph("Built REST APIs using Python and FastAPI in a test project")
    doc.save(buffer)
    return buffer.getvalue()


def _upload(client, vacancy, application, data=None, filename="resume.docx", content_type=None):
    url = f"/api/v1/vacancies/{vacancy}/applications/{application}/resumes"
    return client.post(url, files={"file": (filename, data or _docx(), content_type or
                             "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})


def _auth(client, subject):
    return {"Authorization": f"Bearer {client.tokens[subject]}"}


def test_no_token_and_invalid_token_are_rejected(client):
    client.headers.pop("Authorization")
    assert client.get("/api/v1/vacancies").status_code == 401
    assert client.get("/api/v1/vacancies", headers={"Authorization": "Bearer forged"}).status_code == 401
    assert client.get("/health").status_code == 200


def test_users_see_only_owned_or_assigned_vacancies(client):
    vacancy = _vacancy(client)
    assert client.get("/api/v1/vacancies", headers=_auth(client, "other")).json() == []
    assert client.get(f"/api/v1/vacancies/{vacancy}", headers=_auth(client, "other")).status_code == 404
    assert client.post("/api/v1/vacancies", json={"title": "A test", "description": "A very long test description"},
                       headers=_auth(client, "reviewer")).status_code == 403
    assign = client.post(f"/api/v1/vacancies/{vacancy}/access", json={
        "user_id": str(client.user_ids["reviewer"]), "role": "viewer"})
    assert assign.status_code == 201
    assert len(client.get("/api/v1/vacancies", headers=_auth(client, "reviewer")).json()) == 1
    assert client.patch(f"/api/v1/vacancies/{vacancy}", json={"status": "open"},
                        headers=_auth(client, "reviewer")).status_code == 403
    assert client.post(f"/api/v1/vacancies/{vacancy}/applications", json={"full_name": "Test"},
                       headers=_auth(client, "reviewer")).status_code == 403
    assert client.post(f"/api/v1/vacancies/{vacancy}/access", json={
        "user_id": str(client.user_ids["other"]), "role": "editor"},
        headers=_auth(client, "reviewer")).status_code == 404


def test_recruiter_editor_can_create_applications(client):
    vacancy = _vacancy(client)
    grant = client.post(f"/api/v1/vacancies/{vacancy}/access", json={
        "user_id": str(client.user_ids["other"]), "role": "editor"})
    assert grant.status_code == 201
    add = client.post(f"/api/v1/vacancies/{vacancy}/applications", json={
        "full_name": "Synthetic Candidate"}, headers=_auth(client, "other"))
    assert add.status_code == 201
    applicant_id = add.json()["id"]
    result = client.patch(f"/api/v1/vacancies/{vacancy}/applications/{applicant_id}",
                          json={"stage": "interview"}, headers=_auth(client, "other"))
    assert result.status_code == 200
    assert result.json()["stage"] == "interview"
    assert client.patch(f"/api/v1/vacancies/{vacancy}/applications/{applicant_id}",
                        json={"stage": "robot_auto_reject"}).status_code == 422


def test_upload_parse_deduplicate_and_download_audit(client, monkeypatch):
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    first = _upload(client, vacancy, application)
    assert first.status_code == 201, first.text
    resume = first.json()
    assert resume["parse_status"] == "pending"
    again = _upload(client, vacancy, application)
    assert again.status_code == 201
    assert again.json()["id"] == resume["id"]

    monkeypatch.setattr(worker, "SessionLocal", client.test_sessionmaker)
    assert worker.process_next() is True
    assert worker.process_next() is False

    root = f"/api/v1/vacancies/{vacancy}/applications/{application}/resumes/{resume['id']}"
    text_result = client.get(root + "/text")
    assert text_result.status_code == 200
    assert text_result.json()["parse_status"] == "parsed"
    assert "FastAPI" in text_result.json()["pages"][0]["text"]
    download = client.get(root + "/download")
    assert download.status_code == 200
    assert download.content == _docx()
    assert download.headers["cache-control"] == "no-store"
    with client.test_sessionmaker() as db:
        assert db.query(Resume).count() == 1
        actions = [event.action for event in db.query(AuditEvent).all()]
        assert "resume.downloaded" in actions and "resume.text.read" in actions


def test_other_user_cannot_access_resumes_even_if_id_known(client):
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    resume = _upload(client, vacancy, application).json()
    url = f"/api/v1/vacancies/{vacancy}/applications/{application}/resumes/{resume['id']}"
    assert client.get(url + "/download", headers=_auth(client, "other")).status_code == 404
    assert client.get(url + "/text", headers=_auth(client, "other")).status_code == 404
    assert client.get(f"/api/v1/vacancies/{vacancy}/applications", headers=_auth(client, "other")).status_code == 404


def test_reject_oversized_wrong_mime_and_masquerading_zip(client, monkeypatch):
    from app.core.config import settings
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    monkeypatch.setattr(settings, "max_upload_bytes", 40)
    assert _upload(client, vacancy, application).status_code == 413
    monkeypatch.setattr(settings, "max_upload_bytes", 10 * 1024 * 1024)
    assert _upload(client, vacancy, application, b"not a pdf", "fake.pdf", "application/pdf").status_code == 415
    assert _upload(client, vacancy, application, b"PK\x03\x04junk", "fake.docx").status_code == 415
    assert _upload(client, vacancy, application, b"hello", "fake.txt", "text/plain").status_code == 415
    with client.test_sessionmaker() as db:
        assert db.query(Resume).count() == 0
    from app.core.config import settings
    assert not list(Path(settings.upload_dir).rglob(".incoming-*"))


def test_worker_marks_unreadable_pdf_failed(client, monkeypatch):
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    result = _upload(client, vacancy, application, b"%PDF-1.7 broken\n", "broken.pdf", "application/pdf")
    assert result.status_code == 201
    monkeypatch.setattr(worker, "SessionLocal", client.test_sessionmaker)
    assert worker.process_next() is True
    with client.test_sessionmaker() as db:
        assert db.get(Resume, uuid.UUID(result.json()["id"])).parse_status == "failed"


def test_reviewer_can_read_granted_resume_but_not_edit(client):
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    resume_id = _upload(client, vacancy, application).json()["id"]
    grant = client.post(f"/api/v1/vacancies/{vacancy}/access", json={
        "user_id": str(client.user_ids["reviewer"]), "role": "viewer"})
    assert grant.status_code == 201
    route = f"/api/v1/vacancies/{vacancy}/applications/{application}/resumes"
    assert client.get(route, headers=_auth(client, "reviewer")).status_code == 200
    assert client.get(route + f"/{resume_id}/download", headers=_auth(client, "reviewer")).status_code == 200
    assert _upload(client, vacancy, application, content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document").status_code == 201
    assert client.post(route, files={"file": ("cv.docx", _docx())},
                       headers=_auth(client, "reviewer")).status_code == 403


def test_revocation_removes_vacancy_and_candidate_visibility(client):
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    grant = client.post(f"/api/v1/vacancies/{vacancy}/access", json={
        "user_id": str(client.user_ids["reviewer"]), "role": "viewer"})
    assert grant.status_code == 201
    assert client.get(f"/api/v1/vacancies/{vacancy}/applications", headers=_auth(client, "reviewer")).status_code == 200
    revoked = client.delete(f"/api/v1/vacancies/{vacancy}/access/{client.user_ids['reviewer']}")
    assert revoked.status_code == 204
    assert client.get(f"/api/v1/vacancies/{vacancy}/applications", headers=_auth(client, "reviewer")).status_code == 404


def test_antivirus_fails_closed_when_service_unavailable(client, monkeypatch):
    from app.core.config import settings
    vacancy = _vacancy(client)
    application = _application(client, vacancy)
    monkeypatch.setattr(settings, "malware_scan_mode", "clamav")
    monkeypatch.setattr(settings, "clamav_host", "127.0.0.1")
    monkeypatch.setattr(settings, "clamav_port", 9)
    response = _upload(client, vacancy, application)
    assert response.status_code == 503
    assert "Antivirus" in response.json()["detail"]
    with client.test_sessionmaker() as db:
        assert db.query(Resume).count() == 0
