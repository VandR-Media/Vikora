"""Batch import/assessment tests use invented résumés; no cloud requests."""
import csv
import io
import uuid

from docx import Document
from sqlalchemy import select

from app.core.config import settings
from app.main import app
from app.models import Application, Evaluation, Resume
from app.routes.bulk import router
from app.worker import parse as parse_worker, evaluate as eval_worker

# The actual product mounts these routes only for local desktop; tests run in dev.
app.include_router(router)


def make_docx(text):
    doc = Document()
    doc.add_paragraph(text)
    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()


def vacancy(client):
    response = client.post('/api/v1/vacancies', json={
        'title': 'Backend Developer', 'description': 'Тестовая вакансия для проверок',
        'criteria': [{'key':'python','label':'Python','weight':5,'importance':'must'}],
    })
    assert response.status_code == 201, response.text
    return response.json()['id']


def upload(client, vacancy_id, *items):
    return client.post(f'/api/v1/local/bulk/vacancies/{vacancy_id}/resumes',
                       files=[('files', (name, data, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' if name.endswith('.docx') else 'application/pdf'))
                              for name,data in items])


def queue(client, vacancy_id, ids, consent=False):
    return client.post(f'/api/v1/local/bulk/vacancies/{vacancy_id}/assessments', json={
        'application_ids': ids, 'allow_cloud_transmission': consent,
    })


def test_two_files_parse_assess_and_export_csv(client, monkeypatch):
    vacancy_id=vacancy(client)
    result=upload(client, vacancy_id,
                  ('first.docx', make_docx('Работа с Python в команде разработки.')),
                  ('second.docx', make_docx('Работа с Java и БД, без Python.')))
    assert result.status_code == 200, result.text
    body=result.json()
    assert len(body['imported']) == 2
    assert len(body['errors']) == 0
    assert body['imported'][0]['candidate_name'].startswith('Из файла:')
    ids=[item['application_id'] for item in body['imported']]
    monkeypatch.setattr(parse_worker, 'SessionLocal', client.test_sessionmaker)
    assert parse_worker.process_next() is True
    assert parse_worker.process_next() is True
    assert parse_worker.process_next() is False
    monkeypatch.setattr(settings, 'ai_provider', 'heuristic')
    response=queue(client, vacancy_id, ids)
    assert response.status_code == 200, response.text
    assert len(response.json()['queued'])==2
    monkeypatch.setattr(eval_worker, 'SessionLocal', client.test_sessionmaker)
    assert eval_worker.process_next() is True
    assert eval_worker.process_next() is True
    assert eval_worker.process_next() is False
    queue_rows=client.get(f'/api/v1/vacancies/{vacancy_id}/review-queue').json()
    assert len(queue_rows)==2
    assert all(row['status']=='completed' for row in queue_rows)
    assert all(row['stage']=='new' for row in queue_rows)
    result=client.get(f'/api/v1/local/bulk/vacancies/{vacancy_id}/results.csv')
    assert result.status_code==200
    assert result.content.startswith(b'\xef\xbb\xbf')
    rows=list(csv.reader(io.StringIO(result.content.decode('utf-8-sig')), delimiter=';'))
    assert len(rows)==3 and rows[0][1]=='Кандидат' and rows[1][3]=='completed'


def test_duplicate_same_file_rejected_without_duplicate_candidate(client):
    vacancy_id=vacancy(client)
    file=make_docx('Пример уникального резюме.')
    first=upload(client, vacancy_id, ('resume.docx',file))
    assert first.status_code==200
    second=upload(client, vacancy_id,('another_name.docx',file))
    assert second.status_code==200
    assert len(second.json()['duplicates'])==1
    assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json())==1


def test_partial_failure_does_not_rollback_good_files(client):
    vacancy_id=vacancy(client)
    result=upload(client, vacancy_id, ('one.docx', make_docx('Допустимый файл')),
                  ('bad.pdf', b'not-a-pdf'), ('two.docx', make_docx('Второй допустимый файл')))
    assert result.status_code==200, result.text
    assert len(result.json()['imported'])==2
    assert len(result.json()['errors'])==1
    assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json())==2


def test_nonparsed_or_missing_candidate_is_skipped(client):
    vacancy_id=vacancy(client)
    imported=upload(client,vacancy_id,('resume.docx',make_docx('Python'))).json()['imported'][0]
    response=queue(client,vacancy_id,[imported['application_id'],str(uuid.uuid4())])
    assert response.status_code==200
    assert len(response.json()['skipped'])==2
    assert not response.json()['queued']


def test_cross_vacancy_scoping_and_permission(client):
    first, second=vacancy(client), vacancy(client)
    imported=upload(client,first,('resume.docx',make_docx('Python'))).json()['imported'][0]
    response=queue(client,second,[imported['application_id']])
    assert response.status_code==200 and len(response.json()['skipped'])==1
    response=client.patch(f'/api/v1/local/bulk/vacancies/{second}/applications/{imported["application_id"]}/candidate',
                          json={'full_name':'Новая фамилия'})
    assert response.status_code==404
    client.headers.update({'Authorization':f'Bearer {client.tokens["other"]}'})
    assert upload(client,first,('different.docx',make_docx('Тест'))).status_code in (403,404)
    assert client.get(f'/api/v1/local/bulk/vacancies/{first}/results.csv').status_code in (403,404)


def test_manual_name_edit_and_spreadsheet_injection_escape(client):
    vacancy_id=vacancy(client)
    imported=upload(client,vacancy_id,('resume.docx',make_docx('Python'))).json()['imported'][0]
    application=imported['application_id']
    response=client.patch(f'/api/v1/local/bulk/vacancies/{vacancy_id}/applications/{application}/candidate',
                          json={'full_name':'=HYPERLINK("bad")'})
    assert response.status_code==200
    assert response.json()['full_name'].startswith('=')
    csv_data=client.get(f'/api/v1/local/bulk/vacancies/{vacancy_id}/results.csv').content.decode('utf-8-sig')
    rows=list(csv.reader(io.StringIO(csv_data),delimiter=';'))
    assert rows[1][1].startswith("'=")


def test_cloud_requires_explicit_batch_confirmation(client, monkeypatch):
    vacancy_id=vacancy(client)
    imported=upload(client,vacancy_id,('resume.docx',make_docx('Python'))).json()['imported'][0]
    monkeypatch.setattr(parse_worker,'SessionLocal',client.test_sessionmaker)
    parse_worker.process_next()
    monkeypatch.setattr(settings,'ai_provider','deepseek_api')
    assert queue(client,vacancy_id,[imported['application_id']]).status_code==422
    # With consent but no configured key, job is safely skipped, not sent.
    result=queue(client,vacancy_id,[imported['application_id']], consent=True)
    assert result.status_code==200
    assert result.json()['skipped']


def test_bad_batch_size_and_duplicate_ids(client):
    vacancy_id=vacancy(client)
    assert upload(client,vacancy_id).status_code in (422,400)
    file=make_docx('X')
    assert upload(client,vacancy_id,*[(f'{i}.docx',file) for i in range(51)]).status_code==422
    id=str(uuid.uuid4())
    assert queue(client,vacancy_id,[id,id]).status_code==422


def structured(client, vacancy_id, filename, content):
    return client.post(f'/api/v1/local/bulk/vacancies/{vacancy_id}/structured',
                       files={'file': (filename, content, 'application/octet-stream')})


def test_50_text_candidates_import_evaluate_and_read_in_card(client, monkeypatch):
    import json
    vacancy_id = vacancy(client)
    entries = [{'full_name': f'Кандидат {idx}', 'external_id': f'TEST-{idx}',
                'resume_text': f'Вымышленное резюме {idx}. Есть опыт Python и SQL.'}
               for idx in range(50)]
    response = structured(client, vacancy_id, 'all.json', json.dumps({'candidates': entries}, ensure_ascii=False).encode())
    assert response.status_code == 200, response.text
    data = response.json()
    assert len(data['imported']) == 50 and not data['duplicates'] and not data['errors']
    assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json()) == 50
    with client.test_sessionmaker() as db:
        resumes = db.scalars(select(Resume)).all()
        assert len(resumes) == 50
        assert all(r.storage_key and r.parse_status == 'parsed' for r in resumes)
        assert all(r.parsed_fields['pages'][0]['text'].startswith('Вымышленное') for r in resumes)
        from app.services.uploads import blob_path
        assert all(blob_path(r.storage_key).read_text(encoding='utf-8').startswith('Вымышленное') for r in resumes)
    imported = data['imported'][0]
    text = client.get(f'/api/v1/vacancies/{vacancy_id}/applications/{imported["application_id"]}/resumes/{imported["resume_id"]}/text')
    assert text.status_code == 200 and 'Python' in text.json()['pages'][0]['text']
    binary = client.get(f'/api/v1/vacancies/{vacancy_id}/applications/{imported["application_id"]}/resumes/{imported["resume_id"]}/download')
    assert binary.status_code == 200 and 'Python' in binary.text
    monkeypatch.setattr(settings, 'ai_provider', 'heuristic')
    result = queue(client, vacancy_id, [item['application_id'] for item in data['imported']])
    assert result.status_code == 200 and len(result.json()['queued']) == 50
    monkeypatch.setattr(eval_worker, 'SessionLocal', client.test_sessionmaker)
    assert all(eval_worker.process_next() is True for _ in range(50))
    assert eval_worker.process_next() is False
    assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/review-queue').json()) == 50


def test_structured_bad_rows_duplicate_and_limit(client):
    import json
    vacancy_id = vacancy(client)
    body = {'candidates': [
        {'full_name': 'Первый', 'external_id': 'ID-1', 'resume_text': 'Проверяемая запись Python.'},
        {'full_name': 'Второй', 'resume_text': ''},
        {'full_name': 'Третий', 'resume_text': 'Другая запись Java.'},
    ]}
    first = structured(client, vacancy_id, 'x.json', json.dumps(body, ensure_ascii=False).encode()).json()
    assert len(first['imported']) == 2 and len(first['errors']) == 1
    second = structured(client, vacancy_id, 'x.json', json.dumps(body, ensure_ascii=False).encode()).json()
    assert len(second['duplicates']) == 2 and not second['imported']
    changed = {'candidates': [{'external_id': 'ID-1', 'resume_text': 'Изменённая запись'}]}
    result = structured(client, vacancy_id, 'changed.json', json.dumps(changed).encode()).json()
    assert len(result['duplicates']) == 1
    over = {'candidates': [{'resume_text': f'Текст {i}'} for i in range(51)]}
    response = structured(client, vacancy_id, 'too_many.json', json.dumps(over).encode())
    assert response.status_code == 422
    assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json()) == 2


def test_text_zip_csv_and_unsafe_zip(client):
    import zipfile
    vacancy_id = vacancy(client)
    csv_bytes = ('ФИО;Текст резюме;Email\nМаша;Python аналитика;test@example.invalid\n'
                 'Иван;SQL и отчеты;ivan@example.invalid\n').encode('utf-8-sig')
    response = structured(client, vacancy_id, 'table.csv', csv_bytes)
    assert response.status_code == 200 and len(response.json()['imported']) == 2
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('first.txt', 'Тестовый текст первого резюме')
        z.writestr('second.txt', 'Тестовый текст второго резюме')
    response = structured(client, vacancy_id, 'resumes.zip', archive.getvalue())
    assert response.status_code == 200 and len(response.json()['imported']) == 2
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('../escape.txt', 'Скрытый текст')
    response = structured(client, vacancy_id, 'attack.zip', archive.getvalue())
    assert response.status_code == 422
    assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json()) == 4


def test_structured_cross_vacancy_and_manual_cloud_consent(client, monkeypatch):
    import json
    first = vacancy(client)
    request = {'candidates':[{'full_name':'Тестовый кандидат', 'resume_text':'Python 3.12'}]}
    response=structured(client, first, 'one.json', json.dumps(request, ensure_ascii=False).encode())
    application_id=response.json()['imported'][0]['application_id']
    second = vacancy(client)
    assert len(queue(client, second, [application_id]).json()['skipped']) == 1
    monkeypatch.setattr(settings, 'ai_provider', 'gigachat_api')
    assert queue(client, first, [application_id]).status_code == 422
    client.headers.update({'Authorization':f'Bearer {client.tokens["other"]}'})
    assert structured(client, first, 'x.txt', b'python').status_code in (403, 404)


def test_structured_import_does_not_save_source_file(client, tmp_path):
    vacancy_id = vacancy(client)
    result = structured(client, vacancy_id, 'resume.txt', 'Python и FastAPI'.encode())
    assert result.status_code == 200
    assert len(result.json()['imported']) == 1
    from pathlib import Path
    assert not list((Path(settings.upload_dir)).glob('.vikora-import-*'))


def test_text_import_included_in_encrypted_backup_and_privacy_purge(client, tmp_path):
    """Regression: converted TXT must remain protected by existing backup/purge."""
    import sqlite3
    import shutil
    from pathlib import Path
    from app.models import Candidate, Application
    from app.services.backup import create_backup, verify_backup, restore_offline
    from app.services.privacy import schedule_candidate_purge, try_cleanup_request, receipt_status
    from app.services.uploads import blob_path

    vacancy_id = vacancy(client)
    response = structured(client, vacancy_id, 'synth.txt', 'Вымышленный опыт Python, Docker'.encode())
    assert response.status_code == 200, response.text
    row = response.json()['imported'][0]
    with client.test_sessionmaker() as db:
        application = db.get(Application, uuid.UUID(row['application_id']))
        candidate_id = application.candidate_id
        resume = db.get(Resume, uuid.UUID(row['resume_id']))
        key = resume.storage_key
    assert blob_path(key).read_text(encoding='utf-8').startswith('Вымышленный')

    # Materialize a matching on-disk SQLite snapshot for the desktop backup API.
    root = tmp_path / 'copydir'
    root.mkdir()
    shutil.copytree(Path(settings.upload_dir), root / 'files')
    with client.test_sessionmaker() as db:
        raw = db.connection().connection.driver_connection
        with sqlite3.connect(str(root / 'vikora.sqlite3')) as dest:
            raw.backup(dest)
    dest = tmp_path / 'encrypted.vikora'
    report = create_backup(root, dest, 'long-synthetic-password-2026')
    assert report['files'] == 1
    assert verify_backup(dest, 'long-synthetic-password-2026')['files'] == 1
    assert "Вымышленный".encode('utf-8') not in dest.read_bytes()
    with sqlite3.connect(str(root / 'vikora.sqlite3')) as con:
        con.execute('DELETE FROM criterion_evaluations')
        con.execute('DELETE FROM evaluations')
        con.execute('DELETE FROM resumes')
        con.execute('DELETE FROM applications')
        con.execute('DELETE FROM candidates')
    restore_offline(root, dest, 'long-synthetic-password-2026')
    assert (root / 'files' / key).read_text(encoding='utf-8').startswith('Вымышленный')

    with client.test_sessionmaker() as db:
        request_id = schedule_candidate_purge(db, candidate_id, actor_id=client.user_ids['admin'], reason='test_cleanup')
        try_cleanup_request(db, request_id)
        assert receipt_status(db, request_id)['state'] == 'completed'
        assert db.get(Resume, uuid.UUID(row['resume_id'])) is None
    assert not blob_path(key).exists()


def test_more_than_200_applications_can_be_paged(client):
    import json
    vacancy_id = vacancy(client)
    for step in range(5):
        records = [{'full_name':f'Тест {step}-{j}',
                    'resume_text':f'Синтетическое резюме Python номер {step}-{j}'} for j in range(50)]
        result = structured(client, vacancy_id, f'{step}.json', json.dumps(records, ensure_ascii=False).encode())
        assert result.status_code == 200 and len(result.json()['imported']) == 50
    left = client.get(f'/api/v1/vacancies/{vacancy_id}/applications?limit=200&offset=0').json()
    right = client.get(f'/api/v1/vacancies/{vacancy_id}/applications?limit=200&offset=200').json()
    assert len(left) == 200 and len(right) == 50
    assert not ({r['id'] for r in left} & {r['id'] for r in right})
    qleft = client.get(f'/api/v1/vacancies/{vacancy_id}/review-queue?limit=200&offset=0').json()
    qright = client.get(f'/api/v1/vacancies/{vacancy_id}/review-queue?limit=200&offset=200').json()
    assert len(qleft) == 200 and len(qright) == 50
