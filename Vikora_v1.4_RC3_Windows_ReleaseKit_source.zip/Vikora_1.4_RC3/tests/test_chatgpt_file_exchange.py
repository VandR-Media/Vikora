"""Synthetic fixtures only. No calls to ChatGPT or third-party services."""
from __future__ import annotations

import copy
import json
import uuid
from io import BytesIO

from docx import Document
from sqlalchemy import select

from app.main import app
from app.models import Application, AuditEvent, Evaluation
from app.routes.chatgpt_exchange import router
from app.worker import parse as parse_worker

# Under test auth_mode=dev, local-only router must be mounted explicitly.
app.include_router(router)


def _make(client, monkeypatch, text='Разрабатывала API на Python и FastAPI три года.'):
    vacancy = client.post('/api/v1/vacancies', json={
        'title': 'Python developer', 'description': 'Внутренний продукт: API и сервисы',
        'criteria': [
            {'key': 'python', 'label': 'Python', 'importance': 'must', 'weight': 8},
            {'key': 'docker', 'label': 'Docker', 'importance': 'nice', 'weight': 2},
        ],
    })
    assert vacancy.status_code == 201, vacancy.text
    vacancy_id = vacancy.json()['id']
    application_id, resume_id = _add_resume(client, vacancy_id, text)
    monkeypatch.setattr(parse_worker, 'SessionLocal', client.test_sessionmaker)
    assert parse_worker.process_next() is True
    return vacancy_id, application_id, resume_id


def _add_resume(client, vacancy_id, text):
    candidate = client.post(f'/api/v1/vacancies/{vacancy_id}/applications', json={
        'full_name': 'Тестовый кандидат', 'email': 'test@example.invalid',
    })
    assert candidate.status_code == 201, candidate.text
    app_id = candidate.json()['id']
    document = Document()
    document.add_paragraph(text)
    buffer = BytesIO();document.save(buffer)
    upload = client.post(
        f'/api/v1/vacancies/{vacancy_id}/applications/{app_id}/resumes',
        files={'file': ('synthetic.docx', buffer.getvalue(),
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document')},
    )
    assert upload.status_code == 201, upload.text
    return app_id, upload.json()['id']


def _export(client, vacancy_id, apps):
    response = client.post('/api/v1/local/chatgpt-exchange/export', json={
        'vacancy_id': vacancy_id, 'application_ids': apps,
    })
    assert response.status_code == 200, response.text
    return response.json()


def _response(job, matches=None):
    matches = matches or {}
    output = {
        'format': 'vikora-chatgpt-result', 'version': 1,
        'exchange_id': job['exchange_id'], 'vacancy_id': job['vacancy_id'],
        'source_hash': job['source_hash'], 'selections': job['selections'],
        'results': [],
    }
    for item in job['source']['candidates']:
        criteria = job['source']['vacancy']['criteria']
        assessments = []
        for c in criteria:
            if c['key'] == 'python' and matches.get('python', True):
                assessments.append({'criterion_key': c['key'], 'match_level': 'met',
                                    'evidence': [{'page': 1, 'excerpt': 'Разрабатывала API на Python'}],
                                    'rationale': 'Указан профессиональный опыт разработки.'})
            else:
                assessments.append({'criterion_key': c['key'], 'match_level': 'unknown',
                                    'evidence': [], 'rationale': 'В резюме нет подтверждения.'})
        output['results'].append({'application_id': item['application_id'], 'resume_id': item['resume_id'],
                                  'assessment': {'results': assessments}})
    return output


def _import(client, response):
    return client.post('/api/v1/local/chatgpt-exchange/import',
                       files={'file': ('Vikora_результаты.json',
                                       json.dumps(response, ensure_ascii=False).encode(), 'application/json')})


def test_manual_exchange_round_trip_writes_evaluation_not_stage(client, monkeypatch):
    vacancy, application, resume = _make(client, monkeypatch)
    request = _export(client, vacancy, [application])
    assert request['format'] == 'vikora-chatgpt-request'
    assert request['selections'][0]['resume_id'] == resume
    assert request['source']['candidates'][0]['resume_pages'][0]['text'].startswith('Разрабатывала API')
    imported = _import(client, _response(request))
    assert imported.status_code == 200, imported.text
    assert imported.json()['count'] == 1
    queue = client.get(f'/api/v1/vacancies/{vacancy}/review-queue').json()
    assert queue[0]['overall_score'] == 100 and queue[0]['coverage_pct'] == 80
    assert queue[0]['stage'] == 'new'
    with client.test_sessionmaker() as db:
        rows = db.scalars(select(Evaluation).where(Evaluation.model_name == 'chatgpt-plus-file')).all()
        assert len(rows) == 1
        assert rows[0].criteria_snapshot['exchange_id'] == request['exchange_id']
        assert db.get(Application, uuid.UUID(application)).stage == 'new'
        assert any(a.action == 'chatgpt.exchange.imported' for a in db.scalars(select(AuditEvent)))
    assert _import(client, _response(request)).status_code == 422


def test_export_does_not_require_configured_api(client, monkeypatch):
    vacancy, application, _ = _make(client, monkeypatch)
    request = _export(client, vacancy, [application])
    assert 'instructions_ru' in request
    assert len(request['instructions_ru']) >= 10
    assert 'api_key' not in json.dumps(request)


def test_export_rejects_missing_text_and_invalid_application(client, monkeypatch):
    vacancy, application, _ = _make(client, monkeypatch)
    new_app, _ = _add_resume(client, vacancy, 'Пока не разобрано')
    bad = client.post('/api/v1/local/chatgpt-exchange/export', json={
        'vacancy_id': vacancy, 'application_ids': [new_app]})
    assert bad.status_code == 422
    assert client.post('/api/v1/local/chatgpt-exchange/export', json={
        'vacancy_id': vacancy, 'application_ids': [str(uuid.uuid4())]}).status_code == 422
    assert client.post('/api/v1/local/chatgpt-exchange/export', json={
        'vacancy_id': vacancy, 'application_ids': [application, application]}).status_code == 422


def test_import_hallucinated_quote_rejected_and_not_written(client, monkeypatch):
    vacancy, application, _ = _make(client, monkeypatch)
    output = _response(_export(client, vacancy, [application]))
    output['results'][0]['assessment']['results'][0]['evidence'][0]['excerpt'] = 'Знаю Kubernetes 100 лет'
    rejected = _import(client, output)
    assert rejected.status_code == 422
    with client.test_sessionmaker() as db:
        assert db.query(Evaluation).count() == 0


def test_import_checks_current_criteria_and_resume(client, monkeypatch):
    vacancy, application, _ = _make(client, monkeypatch)
    output = _response(_export(client, vacancy, [application]))
    patch = client.patch(f'/api/v1/vacancies/{vacancy}', json={'description': 'Изменили описание работы'})
    assert patch.status_code == 200
    assert _import(client, output).status_code == 422


def test_import_unknown_candidate_and_duplicates_fail_closed(client, monkeypatch):
    vacancy, application, _ = _make(client, monkeypatch)
    output = _response(_export(client, vacancy, [application]))
    altered = copy.deepcopy(output)
    altered['results'][0]['application_id'] = str(uuid.uuid4())
    assert _import(client, altered).status_code == 422
    altered = copy.deepcopy(output)
    altered['results'][0]['assessment']['results'].append(
        copy.deepcopy(altered['results'][0]['assessment']['results'][0]))
    assert _import(client, altered).status_code == 422
    assert _import(client, output).status_code == 200


def test_import_rejects_extra_fields_bogus_version_and_duplicate_json_keys(client, monkeypatch):
    vacancy, application, _ = _make(client, monkeypatch)
    output = _response(_export(client, vacancy, [application]))
    extra = copy.deepcopy(output)
    extra['candidate_contact'] = 'should never be imported'
    assert _import(client, extra).status_code == 422
    extra = copy.deepcopy(output);extra['version'] = 99
    assert _import(client, extra).status_code == 422
    raw = b'{"version":1,"version":1}'
    assert client.post('/api/v1/local/chatgpt-exchange/import',
                       files={'file': ('a.json',raw,'application/json')}).status_code == 422


def test_import_is_atomic_across_multiple_candidates(client, monkeypatch):
    vacancy, app1, _ = _make(client, monkeypatch)
    app2, _ = _add_resume(client, vacancy, 'Разрабатывала API на Python и писала тесты.')
    monkeypatch.setattr(parse_worker, 'SessionLocal', client.test_sessionmaker)
    assert parse_worker.process_next() is True
    output = _response(_export(client, vacancy, [app1, app2]))
    output['results'][1]['assessment']['results'][0]['evidence'][0]['excerpt'] = 'НЕСУЩЕСТВУЮЩАЯ ЦИТАТА'
    assert _import(client, output).status_code == 422
    with client.test_sessionmaker() as db:
        assert db.query(Evaluation).count() == 0
    output['results'][1]['assessment']['results'][0]['evidence'][0]['excerpt'] = 'Разрабатывала API на Python'
    assert _import(client, output).status_code == 200
    with client.test_sessionmaker() as db:
        assert db.query(Evaluation).count() == 2


def test_import_refuses_oversized_file(client):
    huge = b' ' * 4_000_001
    response = client.post('/api/v1/local/chatgpt-exchange/import',
                           files={'file': ('huge.json', huge, 'application/json')})
    assert response.status_code == 422


def test_explicit_resume_selection_for_single_candidate(client, monkeypatch):
    vacancy, application, original_resume = _make(client, monkeypatch)
    doc = Document();doc.add_paragraph('Пишу аналитические отчёты на Excel, изучаю Python.')
    buffer = BytesIO();doc.save(buffer)
    new = client.post(
        f'/api/v1/vacancies/{vacancy}/applications/{application}/resumes',
        files={'file': ('v2.docx', buffer.getvalue(), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')},
    )
    assert new.status_code == 201
    monkeypatch.setattr(parse_worker, 'SessionLocal', client.test_sessionmaker)
    assert parse_worker.process_next() is True
    exported = client.post('/api/v1/local/chatgpt-exchange/export', json={
        'vacancy_id': vacancy,
        'selections': [{'application_id': application, 'resume_id': original_resume}],
    })
    assert exported.status_code == 200, exported.text
    assert exported.json()['selections'][0]['resume_id'] == original_resume
    assert 'Разрабатывала API' in exported.json()['source']['candidates'][0]['resume_pages'][0]['text']
    wrong = client.post('/api/v1/local/chatgpt-exchange/export', json={
        'vacancy_id': vacancy, 'selections': [{'application_id': application, 'resume_id': str(uuid.uuid4())}],
    })
    assert wrong.status_code == 422


def test_resume_modified_since_export_is_rejected(client, monkeypatch):
    vacancy, application, resume = _make(client, monkeypatch)
    output = _response(_export(client, vacancy, [application]))
    from app.models import Resume
    with client.test_sessionmaker.begin() as db:
        old_resume = db.get(Resume, uuid.UUID(resume))
        old_resume.parsed_fields = {'pages': [{'page': 1, 'text': 'Текст изменён после экспорта'}]}
    assert _import(client, output).status_code == 422
    with client.test_sessionmaker() as db:
        assert db.query(Evaluation).count() == 0
