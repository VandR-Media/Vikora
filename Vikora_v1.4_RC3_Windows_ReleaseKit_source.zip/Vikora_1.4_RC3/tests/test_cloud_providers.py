"""Vikora optional DeepSeek, GigaChat and Alice AI tests; strictly mocked HTTP."""
import json
import uuid

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.auth import current_user
from app.core.config import settings
from app.local_preferences import CLOUD_MODEL_TAGS, read_ai_preference, save_ai_preference
from app.models import UserAccount, Application
from app.routes import local_ai
from app.services import cloud_providers as cp
from app.services.evaluate import EvaluationFailure, validate_grounding
from app.worker import evaluate as assessment_worker
from test_evaluations import _create, _parse


@pytest.fixture
def cloud_secrets(monkeypatch):
    entries = {}
    monkeypatch.setattr(cp, 'get_credentials', lambda provider: entries.get(provider))
    monkeypatch.setattr(cp, 'set_credentials', lambda provider, key, folder_id=None: entries.update({provider:{'api_key':key,'folder_id':folder_id}}))
    monkeypatch.setattr(cp, 'delete_credentials', lambda provider: entries.pop(provider,None))
    return entries


def mock_http(monkeypatch, handler):
    original = httpx.Client
    def factory(*args,**kwargs):
        assert kwargs['trust_env'] is False and kwargs['follow_redirects'] is False
        assert kwargs['timeout'] == 120.0
        kwargs['transport'] = httpx.MockTransport(handler)
        return original(*args,**kwargs)
    monkeypatch.setattr(cp.httpx,'Client', factory)


def response_for(provider, content):
    raw=json.dumps(content,ensure_ascii=False)
    if provider=='alice_api':
        return httpx.Response(200,json={'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':raw}]}]})
    return httpx.Response(200,json={'choices':[{'message':{'content':raw}}]})


@pytest.mark.parametrize('provider',list(CLOUD_MODEL_TAGS))
def test_model_config_persists_with_no_secrets(tmp_path,monkeypatch,provider):
    monkeypatch.setenv('VIKORA_DATA_DIR',str(tmp_path))
    save_ai_preference(provider)
    assert read_ai_preference()==provider
    assert CLOUD_MODEL_TAGS[provider] in (tmp_path/'ai_preferences.json').read_text()
    save_ai_preference('heuristic')


@pytest.mark.parametrize('provider',list(CLOUD_MODEL_TAGS))
def test_api_request_uses_fixed_host_and_grounded_evidence(monkeypatch,cloud_secrets,provider):
    cloud_secrets[provider]={'api_key':'the-fake-test-key-12345','folder_id':'folder-test-123'}
    resume='Участвовала в создании API на Python. Почта: test@example.org.'
    criteria=[{'key':'python','label':'Python','weight':6}]
    pages=[{'page':1,'text':resume}]
    content={'results':[{'criterion_key':'python','match_level':'met',
                         'evidence':[{'page':1,'excerpt':'создании API на Python'}],
                         'rationale':'Явный опыт'}]}
    requests=[]
    def handler(req):
        requests.append(req)
        assert req.url.scheme=='https'
        if provider=='gigachat_api' and len(requests)==1:
            assert str(req.url)=='https://ngw.devices.sberbank.ru:9443/api/v2/oauth'
            assert req.headers['authorization']=='Basic the-fake-test-key-12345'
            assert 'GIGACHAT_API_PERS' in req.content.decode()
            assert uuid.UUID(req.headers['rquid'])
            return httpx.Response(200,json={'access_token':'TEMP_TEST_TOKEN'})
        payload=json.loads(req.content)
        assert 'test@example.org' not in str(payload)
        if provider=='alice_api':
            assert str(req.url)=='https://ai.api.cloud.yandex.net/v1/responses'
            assert req.headers['authorization']=='Api-Key the-fake-test-key-12345'
            assert payload['model']=='gpt://folder-test-123/aliceai-llm'
        else:
            expected='https://api.giga.chat/v1/chat/completions' if provider=='gigachat_api' else 'https://api.deepseek.com/chat/completions'
            assert str(req.url)==expected
            if provider=='gigachat_api':
                assert req.headers['authorization']=='Bearer TEMP_TEST_TOKEN'
            else:
                assert req.headers['authorization']=='Bearer the-fake-test-key-12345'
        return response_for(provider,content)
    mock_http(monkeypatch,handler)
    result=cp.evaluate_resume(provider,criteria,pages,CLOUD_MODEL_TAGS[provider])
    assert validate_grounding(result,criteria,pages)[0].match_level=='met'
    assert len(requests) == (2 if provider=='gigachat_api' else 1)


@pytest.mark.parametrize('provider',list(CLOUD_MODEL_TAGS))
def test_vacancy_proposal_only_unsaved_draft_and_validated(monkeypatch,cloud_secrets,provider):
    cloud_secrets[provider]={'api_key':'test-only-123456789','folder_id':'folder-test-123'}
    sample={'title':'Рекрутер','description':'Подбор персонала, интервью, сотрудничество с менеджерами.',
            'criteria':[{'key':'interviews','label':'Интервью','description':'Подтверждённый опыт интервью',
                         'importance':'must','weight':8,'sort_order':0}]}
    monkeypatch.setattr(cp,'_request',lambda *args,**kwargs:sample)
    got=cp.draft_vacancy(provider,'Рекрутер','Нужны интервью, коммуникация и поиск')
    assert got['status']=='draft' and got['criteria'][0]['key']=='interviews'
    sample['criteria'][0]['weight']=200
    with pytest.raises(EvaluationFailure): cp.draft_vacancy(provider,'Рекрутер','Нужны интервью, коммуникация и поиск')


def test_provider_credentials_keyring_format_and_validation(monkeypatch):
    data={}
    class Fake:
        def get_password(self,s,a):return data.get((s,a))
        def set_password(self,s,a,p):data[(s,a)]=p
        def delete_password(self,s,a):data.pop((s,a))
    import sys
    monkeypatch.setitem(sys.modules,'keyring',Fake())
    with pytest.raises(ValueError):cp.set_credentials('alice_api','test-only-key-12345',folder_id=None)
    with pytest.raises(ValueError):cp.set_credentials('deepseek_api','bad key with spaces')
    cp.set_credentials('alice_api','yandex-credential-12345','folder-test-123')
    assert cp.get_credentials('alice_api')['folder_id']=='folder-test-123'
    cp.delete_credentials('alice_api')
    assert cp.get_credentials('alice_api') is None


def test_routes_require_credentials_and_allow_per_vacancy_selection(tmp_path,monkeypatch,cloud_secrets):
    monkeypatch.setenv('VIKORA_DATA_DIR',str(tmp_path))
    monkeypatch.setattr(settings,'ai_provider','heuristic')
    monkeypatch.setattr(local_ai,'probe_ollama',lambda: {'service_running':False,'model_installed':False})
    app=FastAPI();app.include_router(local_ai.router)
    app.dependency_overrides[current_user]=lambda:UserAccount(role='admin',full_name='Owner')
    with TestClient(app) as client:
        assert client.post('/api/v1/local/ai/mode',json={'mode':'deepseek_api'}).status_code==409
        assert client.post('/api/v1/local/ai/providers/alice_api/credentials',json={'api_key':'some-test-key-123'}).status_code==422
        assert client.post('/api/v1/local/ai/providers/deepseek_api/credentials',json={'api_key':'some-test-key-123'}).status_code==200
        assert 'some-test-key-123' not in client.get('/api/v1/local/ai/status').text
        assert client.post('/api/v1/local/ai/mode',json={'mode':'deepseek_api'}).status_code==200
        assert read_ai_preference()=='deepseek_api'
        endpoint='/api/v1/local/ai/vacancy-draft'
        sample={'role':'Рекрутер','notes':'Интервью, аналитика, переговоры и обратная связь', 'provider':'deepseek_api'}
        assert client.post(endpoint,json=sample).status_code==422
        sample['send_to_cloud']=True
        with pytest.MonkeyPatch.context() as patch:
            patch.setattr(cp,'draft_vacancy',lambda *args: {'title':'Draft','description':'valid','criteria':[]})
            assert client.post(endpoint,json=sample).status_code==200
        assert client.delete('/api/v1/local/ai/providers/deepseek_api/credentials').status_code==200
        assert read_ai_preference()=='heuristic'


@pytest.mark.parametrize('provider',list(CLOUD_MODEL_TAGS))
def test_resume_requires_consent_and_do_not_change_stage(client,monkeypatch,cloud_secrets,provider):
    vid, aid, rid = _create(client,text='Разрабатывала Python сервисы и API')
    _parse(client,monkeypatch)
    monkeypatch.setattr(settings,'ai_provider',provider)
    monkeypatch.setattr(settings,'ai_model',CLOUD_MODEL_TAGS[provider])
    endpoint=f'/api/v1/vacancies/{vid}/applications/{aid}/evaluations'
    assert client.post(endpoint,json={'resume_id':rid}).status_code==422
    assert client.post(endpoint,json={'resume_id':rid,'send_resume_to_cloud':True}).status_code==409
    cloud_secrets[provider]={'api_key':'some-valid-test-key-123','folder_id':'folder-test-123'}
    resp=client.post(endpoint,json={'resume_id':rid,'send_resume_to_cloud':True})
    assert resp.status_code==202,resp.text
    queued=resp.json()
    assert queued['criteria_snapshot']['cloud_consent'] is True
    assert queued['model_name']==CLOUD_MODEL_TAGS[provider]
    monkeypatch.setattr(cp,'evaluate_resume',lambda *args: {'results':[
        {'criterion_key':'python','match_level':'met','evidence':[{'page':1,'excerpt':'Разрабатывала Python'}],'rationale':'Опыт разработки'},
        {'criterion_key':'docker','match_level':'unknown','evidence':[],'rationale':'Не указано'}]})
    monkeypatch.setattr(assessment_worker,'SessionLocal',client.test_sessionmaker)
    assert assessment_worker.process_next()
    outcome=client.get(endpoint+'/'+queued['id']).json()
    assert outcome['status']=='completed' and outcome['results'][0]['match_level']=='met'
    with client.test_sessionmaker() as db:
        assert db.get(Application,uuid.UUID(aid)).stage=='new'


def test_switching_provider_blocks_queued_cloud_job(client,monkeypatch,cloud_secrets):
    vid, aid, rid = _create(client,text='Есть Python опыт')
    _parse(client,monkeypatch)
    cloud_secrets['alice_api']={'api_key':'some-test-key-123','folder_id':'folder-test-123'}
    monkeypatch.setattr(settings,'ai_provider','alice_api')
    monkeypatch.setattr(settings,'ai_model','aliceai-llm')
    endpoint=f'/api/v1/vacancies/{vid}/applications/{aid}/evaluations'
    queued=client.post(endpoint,json={'resume_id':rid,'send_resume_to_cloud':True}).json()['id']
    monkeypatch.setattr(settings,'ai_provider','heuristic')
    monkeypatch.setattr(assessment_worker,'SessionLocal',client.test_sessionmaker)
    assert assessment_worker.process_next()
    assert client.get(endpoint+'/'+queued).json()['status']=='failed'


def test_cloud_api_errors_do_not_echo_keys(monkeypatch,cloud_secrets):
    secret='demo-secret-do-not-leak-123'
    cloud_secrets['deepseek_api']={'api_key':secret}
    mock_http(monkeypatch,lambda req:httpx.Response(401,text=f'{secret} is invalid'))
    with pytest.raises(EvaluationFailure) as exc:
        cp.draft_vacancy('deepseek_api','Менеджер','Создать вакансию для тестового проекта')
    assert secret not in str(exc.value)
