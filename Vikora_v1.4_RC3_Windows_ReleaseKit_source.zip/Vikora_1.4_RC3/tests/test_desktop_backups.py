"""Verify encryption, completeness, tamper resistance and real offline restore."""
import hashlib
import io
from pathlib import Path
import sqlite3

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db import Base
from app.models import Candidate, Resume, UserAccount, Vacancy
from app.services.backup import BackupError, create_backup, restore_offline, verify_backup
from app.core import config
from app.local_runtime import LOCAL_SUBJECT

PASSWORD = "Только-для-тестов-пароль-2030"


def make_local_data(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    (root / "files" / "ab").mkdir(parents=True)
    payload = b"synthetic resume content only\x00\x01"
    key = "ab/" + "a" * 32
    (root / "files" / key).write_bytes(payload)
    engine = create_engine(f"sqlite:///{root / 'vikora.sqlite3'}")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        db.add(UserAccount(full_name="Test Owner", email="owner@vikora.invalid", role="admin", sso_subject=LOCAL_SUBJECT))
        db.add(Candidate(full_name="Вымышленный кандидат"))
        db.add(Vacancy(title="Тестовая вакансия", description="Только тестовые данные"))
        db.flush()
        candidate = db.query(Candidate).one()
        db.add(Resume(candidate_id=candidate.id, storage_key=key, mime_type="application/pdf",
                      original_filename="test.pdf", sha256=hashlib.sha256(payload).hexdigest()))
        db.commit()
    engine.dispose()
    return key, payload


def assert_snapshot_has_candidate(root: Path, count: int):
    with sqlite3.connect(root / "vikora.sqlite3") as db:
        assert db.execute("SELECT count(*) FROM candidates").fetchone()[0] == count


def test_backup_roundtrip_and_encrypted_payload(tmp_path):
    root = tmp_path / "data"
    key, payload = make_local_data(root)
    location = tmp_path / "Vikora.vikora"
    report = create_backup(root, location, PASSWORD)
    assert report["files"] == 1
    content = location.read_bytes()
    assert content.startswith(b"VIKORA8\x00")
    assert not content.startswith(b"PK\x03\x04")
    assert payload not in content
    assert b"test.pdf" not in content
    assert verify_backup(location, PASSWORD)["files"] == 1


def test_wrong_password_and_corrupted_backup_rejected(tmp_path):
    root = tmp_path / "data"
    make_local_data(root)
    location = tmp_path / "copy.vikora"
    create_backup(root, location, PASSWORD)
    with pytest.raises(BackupError, match="Неверный пароль"):
        verify_backup(location, "another-password-of-length-20")
    content = bytearray(location.read_bytes()); content[len(content)//2] ^= 1
    location.write_bytes(content)
    with pytest.raises(BackupError, match="повреждена"):
        verify_backup(location, PASSWORD)
    assert_snapshot_has_candidate(root, 1)


def test_backup_refuses_missing_or_modified_resume_without_creating_output(tmp_path):
    root = tmp_path / "data"
    key, _ = make_local_data(root)
    (root / "files" / key).write_bytes(b"file silently changed")
    dest = tmp_path / "incomplete.vikora"
    with pytest.raises(BackupError, match="изменился"):
        create_backup(root, dest, PASSWORD)
    assert not dest.exists()
    (root / "files" / key).unlink()
    with pytest.raises(BackupError, match="отсутствует"):
        create_backup(root, dest, PASSWORD)


def test_offline_restore_recovers_previous_record_and_files(tmp_path):
    root = tmp_path / "data"
    key, payload = make_local_data(root)
    location = tmp_path / "restore.vikora"
    create_backup(root, location, PASSWORD)
    with sqlite3.connect(root / "vikora.sqlite3") as db:
        db.execute("DELETE FROM resumes")
        db.execute("DELETE FROM candidates")
        db.commit()
    (root / "files" / key).unlink()
    assert_snapshot_has_candidate(root, 0)
    details = restore_offline(root, location, PASSWORD)
    assert_snapshot_has_candidate(root, 1)
    assert (root / "files" / key).read_bytes() == payload
    assert Path(details["emergency_backup"]).is_file()
    assert verify_backup(Path(details["emergency_backup"]), PASSWORD)["files"] == 0


def test_reject_corruption_before_touching_existing_data(tmp_path):
    root = tmp_path / "data"
    make_local_data(root)
    loc = tmp_path / "bad.vikora"
    create_backup(root, loc, PASSWORD)
    loc.write_bytes(loc.read_bytes()[:60] + b"X" * 20)
    with pytest.raises(BackupError):
        restore_offline(root, loc, PASSWORD)
    assert_snapshot_has_candidate(root, 1)


def test_backup_http_is_local_owner_only(client, tmp_path, monkeypatch):
    root = tmp_path / "local"
    make_local_data(root)
    monkeypatch.setenv("VIKORA_DATA_DIR", str(root))
    with client.test_sessionmaker.begin() as db:
        db.add(UserAccount(email="personal@vikora.invalid", full_name="Владелец Vikora",
                           sso_subject=LOCAL_SUBJECT, role="admin"))
    monkeypatch.setattr(config.settings, "auth_mode", "local")
    monkeypatch.setattr(config.settings, "app_env", "desktop")
    monkeypatch.setattr(config.settings, "vikora_local_token", "x" * 60)
    # The desktop-only router is loaded at import time only for AUTH_MODE=local;
    # mount it on a minimal test app to avoid changing the global dev app.
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from app.db import get_db
    from app.routes.local_backups import router
    api_app = FastAPI()
    api_app.include_router(router)
    def local_db():
        with client.test_sessionmaker() as session:
            yield session
    api_app.dependency_overrides[get_db] = local_db
    path = "/api/v1/local/backup"
    with TestClient(api_app) as local_client:
        assert local_client.post(path, json={"password": PASSWORD}).status_code == 401
        good = local_client.post(path, json={"password": PASSWORD}, headers={"Authorization": "Bearer " + "x" * 60})
        assert good.status_code == 200, good.text
        assert good.content.startswith(b"VIKORA8\x00")
        assert good.headers["cache-control"] == "no-store"
        download = tmp_path / "download.vikora"
        download.write_bytes(good.content)
        assert verify_backup(download, PASSWORD)["files"] == 1
        assert list((root / "backups" / ".temporary").glob("export-*.vikora")) == []
        assert local_client.post(path, json={"password": "short"}, headers={"Authorization": "Bearer " + "x" * 60}).status_code == 422


def test_desktop_rejects_upload_when_scanner_not_configured(tmp_path, monkeypatch):
    from fastapi import HTTPException
    from app.services.uploads import scan_for_malware
    f = tmp_path / 'test.pdf'; f.write_bytes(b'%PDF- fake synthetic')
    monkeypatch.setattr(config.settings, 'app_env', 'desktop')
    monkeypatch.setattr(config.settings, 'malware_scan_mode', 'disabled')
    with pytest.raises(HTTPException) as exc:
        scan_for_malware(f)
    assert exc.value.status_code == 503


def test_windows_defender_is_fail_closed_outside_windows(tmp_path, monkeypatch):
    from fastapi import HTTPException
    from app.services import uploads
    from app.services.uploads import scan_for_malware
    # Model a non-Windows platform even when the suite runs on Windows CI.
    # Do not patch sys.platform globally: other modules rely on that value.
    from types import SimpleNamespace
    monkeypatch.setattr(uploads, 'sys', SimpleNamespace(platform='linux'))
    f = tmp_path / 'test.pdf'; f.write_bytes(b'%PDF- fake synthetic')
    monkeypatch.setattr(config.settings, 'malware_scan_mode', 'windows_defender')
    with pytest.raises(HTTPException) as exc:
        scan_for_malware(f)
    assert exc.value.status_code == 503


def test_restore_api_requires_confirmation_and_validates_before_shutdown(client, tmp_path, monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from app.db import get_db
    import app.routes.local_backups as local_routes
    from app.local_runtime import cancel_restore, take_restore

    root = tmp_path / "local"
    make_local_data(root)
    archive = tmp_path / "previous.vikora"
    create_backup(root, archive, PASSWORD)
    monkeypatch.setenv("VIKORA_DATA_DIR", str(root))
    with client.test_sessionmaker.begin() as db:
        db.add(UserAccount(email="restore@vikora.invalid", full_name="Owner local",
                           sso_subject=LOCAL_SUBJECT, role="admin"))
    monkeypatch.setattr(config.settings, "auth_mode", "local")
    monkeypatch.setattr(config.settings, "app_env", "desktop")
    monkeypatch.setattr(config.settings, "vikora_local_token", "y" * 60)
    stopped = []
    monkeypatch.setattr(local_routes, "ask_to_shutdown", lambda: (stopped.append(True) or True))
    app = FastAPI()
    app.include_router(local_routes.router)
    def local_db():
        with client.test_sessionmaker() as session:
            yield session
    app.dependency_overrides[get_db] = local_db
    headers = {"Authorization": "Bearer " + "y" * 60}
    def parts(content: bytes):
        return {"file": ("previous.vikora", io.BytesIO(content), "application/octet-stream")}
    try:
        with TestClient(app) as local_client:
            incorrect = local_client.post("/api/v1/local/restore", headers=headers,
                files=parts(archive.read_bytes()), data={"password": PASSWORD,"confirmation":"ДА"})
            assert incorrect.status_code == 422
            wrong_password = local_client.post("/api/v1/local/restore", headers=headers,
                files=parts(archive.read_bytes()), data={"password":"wrong-password-with-length","confirmation":"ВОССТАНОВИТЬ"})
            assert wrong_password.status_code == 422
            assert not stopped
            accepted = local_client.post("/api/v1/local/restore", headers=headers,
                files=parts(archive.read_bytes()), data={"password": PASSWORD,"confirmation":"ВОССТАНОВИТЬ"})
            assert accepted.status_code == 200, accepted.text
            assert accepted.json()["status"] == "scheduled"
            assert stopped == [True]
            stage = take_restore()
            assert stage and stage[0].exists() and stage[1] == PASSWORD
            stage[0].unlink(missing_ok=True)
    finally:
        cancel_restore()


def test_verify_backup_api_does_not_change_current_data(client, tmp_path, monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from app.db import get_db
    from app.routes.local_backups import router
    root = tmp_path / "data"; make_local_data(root)
    path = tmp_path / "copy.vikora"; create_backup(root, path, PASSWORD)
    monkeypatch.setenv("VIKORA_DATA_DIR", str(root))
    with client.test_sessionmaker.begin() as db:
        db.add(UserAccount(email="verify@vikora.invalid", full_name="Owner local",
                           sso_subject=LOCAL_SUBJECT, role="admin"))
    monkeypatch.setattr(config.settings, "auth_mode", "local")
    monkeypatch.setattr(config.settings, "app_env", "desktop")
    monkeypatch.setattr(config.settings, "vikora_local_token", "z" * 60)
    app = FastAPI(); app.include_router(router)
    def get_local():
        with client.test_sessionmaker() as session: yield session
    app.dependency_overrides[get_db] = get_local
    with TestClient(app) as local_client:
        response = local_client.post("/api/v1/local/verify-backup", headers={"Authorization": "Bearer " + "z" * 60},
            files={"file": ("copy.vikora", io.BytesIO(path.read_bytes()), "application/octet-stream")},
            data={"password": PASSWORD})
        assert response.status_code == 200, response.text
        assert response.json()["status"] == "valid" and response.json()["files"] == 1
    assert_snapshot_has_candidate(root, 1)


def test_backup_restores_glossary_and_expert_notes(tmp_path):
    """New v1.2 tables are restored with private notes and previous assessments."""
    from app.models import Application, Evaluation, KnowledgeTerm, ExpertCorrection
    from sqlalchemy.orm import Session
    root = tmp_path / 'local'
    make_local_data(root)
    engine = create_engine(f"sqlite:///{root / 'vikora.sqlite3'}")
    with Session(engine) as db:
        v = db.query(Vacancy).one()
        person = db.query(Candidate).one()
        resume = db.query(Resume).one()
        db.add(KnowledgeTerm(vacancy_id=v.id, name='Kubernetes', normalized_name='kubernetes',
                             aliases=['K8s'], explanation='Confirmed alias'))
        app = Application(vacancy_id=v.id, candidate_id=person.id)
        db.add(app)
        db.flush()
        ev = Evaluation(application_id=app.id, resume_id=resume.id, status='completed',
                        model_name='synthetic-test', prompt_version='v1',
                        criteria_snapshot={'criteria':[{'key':'kube','label':'Kubernetes','importance':'must','weight':5}]})
        db.add(ev)
        db.flush()
        db.add(ExpertCorrection(evaluation_id=ev.id, criterion_key='kube',
                                corrected_level='unknown', note='Не подтверждено в тестовом резюме'))
        db.commit()
    engine.dispose()
    file = tmp_path / 'v12.vikora'
    create_backup(root, file, PASSWORD)
    with sqlite3.connect(root / 'vikora.sqlite3') as con:
        con.execute('DELETE FROM knowledge_terms')
        con.execute('DELETE FROM expert_corrections')
        con.commit()
    restore_offline(root, file, PASSWORD)
    with sqlite3.connect(root / 'vikora.sqlite3') as con:
        assert con.execute('SELECT aliases FROM knowledge_terms').fetchone()[0] == '["K8s"]'
        assert 'Не подтверждено' in con.execute('SELECT note FROM expert_corrections').fetchone()[0]
