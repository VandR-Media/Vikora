"""Read-only HeadHunter connector, all external API responses are fictional."""
from datetime import datetime, timezone
from urllib.parse import urlsplit, parse_qs
from types import SimpleNamespace
import uuid
import pytest
from app.main import app
from app.routes.hh_connector import router
from app.services import hh_connector as hh
from app.models import Candidate, Resume, Application
from sqlalchemy import select

# Product registers only for local personal mode; tests use isolated dev auth.
app.include_router(router)

@pytest.fixture
def hh_store(monkeypatch):
    store={}
    monkeypatch.setattr(hh,'keyring',SimpleNamespace(get_password=lambda service,name:store.get(name),
          set_password=lambda service,name,value:store.__setitem__(name,value),
          delete_password=lambda service,name:store.pop(name,None), errors=SimpleNamespace(PasswordDeleteError=KeyError)))
    hh._pending.clear()
    return store


def create_vacancy(client):
    r=client.post('/api/v1/vacancies',json={'title':'HR Специалист','description':'Вымышленная вакансия для тестирования',
        'criteria':[{'key':'hr','label':'Подбор персонала','importance':'must','weight':5}]})
    assert r.status_code==201,r.text
    return r.json()['id']


def fake_hh(monkeypatch):
    monkeypatch.setattr(hh,'list_vacancies',lambda:[{'id':'12345','name':'HR Специалист'}])
    monkeypatch.setattr(hh,'list_collections',lambda id:[{'id':'response','name':'Откликнувшиеся','url':'https://api.hh.ru/negotiations/response?vacancy_id=12345'}])
    monkeypatch.setattr(hh,'list_collection_page',lambda remote,collection,page:[
        {'id':'n1','resume_id':'resume1','title':'Рекрутер','resume_url':'https://api.hh.ru/resumes/resume1','has_resume':True},
        {'id':'n2','resume_id':'resume2','title':'Без резюме','resume_url':'','has_resume':False}])
    monkeypatch.setattr(hh,'fetch_resume',lambda url:({'first_name':'Мария','last_name':'Вымышленная'},
        'Вымышленный кандидат: 4 года занималась подбором персонала, проводила интервью и составляла профиль вакансии.'))


def test_urls_cannot_exfiltrate_authorization_header():
    for value in ['http://api.hh.ru/resumes/123','https://evil.example/resumes/1',
                  'https://api.hh.ru.evil.example/resumes/1','https://api.hh.ru@evil.example/resumes/1',
                  'https://api.hh.ru/%2e%2e/resumes/1','//api.hh.ru/resumes/1']:
        with pytest.raises(hh.HHError):hh._checked_url(value,('/resumes',))
    assert hh._checked_url('https://api.hh.ru/resumes/12',('/resumes',)) == 'https://api.hh.ru/resumes/12'


def test_oauth_state_single_use_and_expiration(hh_store):
    hh.save_config('id0123456789','secret_not_real_abcdef','dev@example.invalid',18467)
    url=hh.create_authorization_url()
    assert urlsplit(url).hostname=='hh.ru'
    state=parse_qs(urlsplit(url).query)['state'][0]
    hh.take_state(state)
    with pytest.raises(hh.HHError):hh.take_state(state)


def test_read_only_preview_link_import_dedup(client, monkeypatch, tmp_path):
    vacancy_id=create_vacancy(client)
    fake_hh(monkeypatch)
    if True:
        linked=client.post(f'/api/v1/local/hh/vacancies/{vacancy_id}/link',json={'hh_vacancy_id':'12345'})
        # Auth dependency is provided via test auth; local mode changed only after client initialized.
        assert linked.status_code==200,linked.text
        found=client.get(f'/api/v1/local/hh/vacancies/{vacancy_id}/collections')
        assert found.status_code==200 and found.json()['items'][0]['id']=='response'
        shown=client.get(f'/api/v1/local/hh/vacancies/{vacancy_id}/preview?collection_id=response&page=0')
        assert shown.status_code==200 and len(shown.json()['items'])==2
        endpoint=f'/api/v1/local/hh/vacancies/{vacancy_id}/import'
        body={'collection_id':'response','page':0,'negotiation_ids':['n1','n2'],'confirm_resume_view':True}
        assert client.post(endpoint,json={**body,'confirm_resume_view':False}).status_code==422
        assert client.post(endpoint,json={**body,'negotiation_ids':['spoof']}).status_code==409
        result=client.post(endpoint,json=body)
        assert result.status_code==200,result.text
        assert len(result.json()['imported'])==1
        assert len(result.json()['skipped'])==1
        duplicate=client.post(endpoint,json=body)
        assert len(duplicate.json()['duplicates'])==1
        assert len(client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json())==1
        with client.test_sessionmaker() as db:
            candidate=db.scalar(select(Candidate).where(Candidate.source=='hh.ru'))
            assert candidate and candidate.source_external_id=='resume1'
            resume=db.scalar(select(Resume).where(Resume.candidate_id==candidate.id))
            assert resume.parse_status=='parsed' and 'подбором персонала' in resume.parsed_fields['pages'][0]['text']


def test_no_cross_vacancy_import_and_max_50(client,monkeypatch):
    v=create_vacancy(client)
    fake_hh(monkeypatch)
    endpoint=f'/api/v1/local/hh/vacancies/{v}/import'
    assert client.post(endpoint,json={'collection_id':'response','page':0,
      'negotiation_ids':['n1']*51,'confirm_resume_view':True}).status_code==422
    client.headers['Authorization']='Bearer '+client.tokens['other']
    assert client.get(f'/api/v1/local/hh/vacancies/{v}/collections').status_code in (403,404)
    assert client.post(endpoint,json={'collection_id':'response','page':0,'negotiation_ids':['n1'],
       'confirm_resume_view':True}).status_code in (403,404)


def test_resume_to_text_only_professional_fields():
    text=hh.resume_to_text({'first_name':'Имя','birth_date':'2000-01-01','gender':{'name':'женский'},
       'title':'Менеджер по персоналу','experience':[{'company':'Вымышленная компания',
       'position':'HR менеджер','description':'Проводила 200 интервью в год'}]})
    assert 'интервью' in text and '2000-01-01' not in text and 'женский' not in text


def test_oauth_exchange_rejects_non_employer_and_replay(hh_store, monkeypatch):
    hh.save_config('id0123456789','secret_not_real_abcdef','dev@example.invalid',18467)
    request_url=hh.create_authorization_url()
    state=parse_qs(urlsplit(request_url).query)['state'][0]
    def token_exchange(payload):
        hh_store['oauth_tokens']='{"access_token":"invented", "expires_at":"2099-01-01T00:00:00+00:00"}'
        return {'access_token':'invented'}
    monkeypatch.setattr(hh,'_post_tokens',token_exchange)
    monkeypatch.setattr(hh,'api_get',lambda path,**kw:{'id':'employee-1','employer':None})
    with pytest.raises(hh.HHError) as exc:
        hh.exchange_code('fake_authorization_code',state)
    assert exc.value.status==403
    assert 'oauth_tokens' not in hh_store
    with pytest.raises(hh.HHError):
        hh.exchange_code('fake_authorization_code',state)


def test_config_change_invalidates_older_token(hh_store):
    hh.save_config('id0123456789','secret_not_real_abcdef','dev@example.invalid',18467)
    hh_store['oauth_tokens']='{"access_token":"old-token"}'
    hh.save_config('id0123456789','secret_not_real_abcdef','dev@example.invalid',18467)
    assert 'oauth_tokens' not in hh_store


def test_unavailable_resume_does_not_create_candidate(client,monkeypatch):
    vacancy_id=create_vacancy(client)
    fake_hh(monkeypatch)
    assert client.post(f'/api/v1/local/hh/vacancies/{vacancy_id}/link',
                       json={'hh_vacancy_id':'12345'}).status_code==200
    monkeypatch.setattr(hh,'fetch_resume',lambda url: (_ for _ in ()).throw(hh.HHError('Доступ к резюме закрыт',403)))
    response=client.post(f'/api/v1/local/hh/vacancies/{vacancy_id}/import',json={
        'collection_id':'response','page':0,'negotiation_ids':['n1'],
        'confirm_resume_view':True})
    assert response.status_code==200
    assert not response.json()['imported']
    assert response.json()['skipped'][0]['reason']=='Доступ к резюме закрыт'
    assert not client.get(f'/api/v1/vacancies/{vacancy_id}/applications').json()
