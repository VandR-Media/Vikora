"""Vikora 1.2 knowledge & human-feedback tests use only invented resumes."""
import io
import json
import uuid

from sqlalchemy import select

from app.core.config import settings
from app.main import app
from app.models import ExpertCorrection, KnowledgeTerm, Application
from app.routes.knowledge import router as knowledge_router
from app.services.evaluate import heuristic_assess
from app.worker import evaluate as eval_worker
from app.routes.bulk import router as bulk_router

# Mount local-only feature for the dev-mode integration fixture.
app.include_router(knowledge_router)


def vacancy(client, label="Kubernetes"):
    response = client.post('/api/v1/vacancies', json={
        'title': 'Test Platform Engineer', 'description': 'Synthetic job description',
        'criteria': [{'key': 'kube', 'label': label, 'importance': 'must', 'weight': 5}],
    })
    assert response.status_code == 201, response.text
    return response.json()['id']


def term(client, *, vacancy_id=None, name='Kubernetes', aliases=None, explanation='Container orchestration'):
    return client.post('/api/v1/local/knowledge/terms', json={
        'name': name, 'aliases': aliases if aliases is not None else ['K8s'],
        'explanation': explanation, 'vacancy_id': vacancy_id,
    })


def imported_resume(client, vacancy_id, resume='Участвовал в проекте K8s, детали работы не указаны.'):
    response = client.post(f'/api/v1/local/bulk/vacancies/{vacancy_id}/structured', files={
        'file': ('sample.json', json.dumps({'candidates': [
            {'full_name': 'Вымышленный Кандидат', 'external_id': str(uuid.uuid4()), 'resume_text': resume}
        ]}, ensure_ascii=False).encode('utf-8'), 'application/json'),
    })
    assert response.status_code == 200, response.text
    return response.json()['imported'][0]


def assess(client, monkeypatch, vacancy_id, imported):
    monkeypatch.setattr(settings, 'ai_provider', 'heuristic')
    response = client.post(f'/api/v1/vacancies/{vacancy_id}/applications/{imported["application_id"]}/evaluations',
                           json={'resume_id': imported['resume_id']})
    assert response.status_code == 202, response.text
    monkeypatch.setattr(eval_worker, 'SessionLocal', client.test_sessionmaker)
    assert eval_worker.process_next() is True
    return client.get(f'/api/v1/vacancies/{vacancy_id}/applications/{imported["application_id"]}/evaluations/{response.json()["id"]}').json()


def test_glossary_alias_reassessment_and_previous_snapshot(client, monkeypatch):
    vacancy_id = vacancy(client)
    imported = imported_resume(client, vacancy_id)
    old = assess(client, monkeypatch, vacancy_id, imported)
    assert old['results'][0]['match_level'] == 'unknown'
    assert old['needs_reassessment'] is False
    new_term = term(client, vacancy_id=vacancy_id)
    assert new_term.status_code == 201, new_term.text
    old_loaded = client.get(f'/api/v1/vacancies/{vacancy_id}/applications/{imported["application_id"]}/evaluations/{old["id"]}').json()
    assert old_loaded['needs_reassessment'] is True
    assert old_loaded['results'][0]['match_level'] == 'unknown'
    newer = assess(client, monkeypatch, vacancy_id, imported)
    assert newer['id'] != old['id']
    assert newer['needs_reassessment'] is False
    assert newer['results'][0]['match_level'] == 'partial'  # NOT 'met'
    assert 'K8s' in newer['results'][0]['evidence'][0]['excerpt']
    assert newer['criteria_snapshot']['criteria'][0]['aliases'] == ['K8s']
    rows = client.get(f'/api/v1/vacancies/{vacancy_id}/review-queue').json()
    assert rows[0]['status'] == 'completed'
    assert rows[0]['stage'] == 'new'


def test_glossary_edit_delete_and_invalid_aliases(client):
    v = vacancy(client)
    assert term(client, vacancy_id=v, aliases=['K8s', 'k8s']).status_code == 422
    created = term(client, vacancy_id=v).json()
    assert term(client, vacancy_id=v).status_code == 409
    updated = client.patch(f'/api/v1/local/knowledge/terms/{created["id"]}',
                           json={'aliases':['Kubernetes Engine', 'K8s'], 'explanation':'Approved aliases'})
    assert updated.status_code == 200 and len(updated.json()['aliases']) == 2
    listed = client.get(f'/api/v1/local/knowledge/terms?vacancy_id={v}').json()
    assert listed[0]['explanation'] == 'Approved aliases'
    assert client.delete(f'/api/v1/local/knowledge/terms/{created["id"]}').status_code == 204
    assert client.get(f'/api/v1/local/knowledge/terms?vacancy_id={v}').json() == []


def test_global_glossary_vacancy_override_isolation(client):
    a, b = vacancy(client), vacancy(client)
    global_term = term(client)
    assert global_term.status_code == 201
    custom = term(client, vacancy_id=a, aliases=['Kube'])
    assert custom.status_code == 201
    first = client.get(f'/api/v1/local/knowledge/terms?vacancy_id={a}').json()
    second = client.get(f'/api/v1/local/knowledge/terms?vacancy_id={b}').json()
    assert len(first) == len(second) == 1
    assert first[0]['aliases'] == ['Kube']
    assert second[0]['aliases'] == ['K8s']
    client.headers.update({'Authorization': f'Bearer {client.tokens["other"]}'})
    assert client.get(f'/api/v1/local/knowledge/terms?vacancy_id={a}').status_code == 404
    assert term(client, vacancy_id=a).status_code == 404
    assert client.delete(f'/api/v1/local/knowledge/terms/{custom.json()["id"]}').status_code == 404


def test_feedback_is_expert_annotation_not_silent_model_training(client, monkeypatch):
    v = vacancy(client)
    imported = imported_resume(client, v, 'Обучение на курсе, K8s не применял в работе')
    term(client, vacancy_id=v)
    evaluation = assess(client, monkeypatch, v, imported)
    response = client.post(f'/api/v1/local/knowledge/vacancies/{v}/evaluations/{evaluation["id"]}/corrections',
                           json={'criterion_key':'kube', 'corrected_level':'unknown',
                                 'note':'Термин только в контексте обучения; практики нет.'})
    assert response.status_code == 200, response.text
    loaded = client.get(f'/api/v1/vacancies/{v}/applications/{imported["application_id"]}/evaluations/{evaluation["id"]}').json()
    assert loaded['expert_corrections'][0]['corrected_level'] == 'unknown'
    assert loaded['overall_score'] == evaluation['overall_score']  # model output unchanged
    assert client.post(f'/api/v1/local/knowledge/vacancies/{v}/evaluations/{evaluation["id"]}/corrections',
        json={'criterion_key':'not_real', 'corrected_level':'unknown', 'note':'Wrong criterion'}).status_code == 422
    assert client.post(f'/api/v1/local/knowledge/vacancies/{v}/evaluations/{evaluation["id"]}/corrections',
        json={'criterion_key':'kube', 'corrected_level':'met', 'note':'Исправлено после собеседования'}).status_code == 200
    with client.test_sessionmaker() as db:
        assert db.query(ExpertCorrection).count() == 1
        assert db.get(Application, uuid.UUID(imported['application_id'])).stage == 'new'


def test_glossary_change_and_criteria_change_mark_evaluation_stale(client, monkeypatch):
    v = vacancy(client)
    imported = imported_resume(client, v)
    term_id = term(client, vacancy_id=v).json()['id']
    result = assess(client, monkeypatch, v, imported)
    assert not result['needs_reassessment']
    client.patch(f'/api/v1/local/knowledge/terms/{term_id}', json={'explanation':'New guidance'})
    old = client.get(f'/api/v1/vacancies/{v}/applications/{imported["application_id"]}/evaluations/{result["id"]}').json()
    assert old['needs_reassessment']
    new = assess(client, monkeypatch, v, imported)
    assert not new['needs_reassessment']
    modified = client.patch(f'/api/v1/vacancies/{v}', json={'criteria':[{
        'key':'kube', 'label':'Kubernetes', 'weight':9, 'importance':'must'
    }]})
    assert modified.status_code == 200
    again = client.get(f'/api/v1/vacancies/{v}/applications/{imported["application_id"]}/evaluations/{new["id"]}').json()
    assert again['needs_reassessment']


def test_glossary_alias_negation_and_nonmatching_tech():
    criteria = [{'key':'kube', 'label':'Kubernetes', 'aliases':['K8s']}]
    result = heuristic_assess(criteria, [{'page':1,'text':'Нет опыта K8s, только изучение.'}])
    assert result['results'][0]['match_level'] == 'unknown'
    result = heuristic_assess(criteria, [{'page':1,'text':'K8s упоминается как тема курса.'}])
    assert result['results'][0]['match_level'] == 'partial'
    other = heuristic_assess([{'key':'java','label':'Java','aliases':[]}], [{'page':1,'text':'JavaScript, без Java'}])
    assert other['results'][0]['match_level'] == 'unknown'


def test_glossary_change_invalidates_old_chatgpt_export(client):
    from app.services.chatgpt_exchange import make_request
    from app.models import Vacancy
    v = vacancy(client)
    imported = imported_resume(client, v)
    with client.test_sessionmaker() as db:
        request_before = make_request(db, db.get(Vacancy, uuid.UUID(v)), [uuid.UUID(imported['application_id'])])
    term(client, vacancy_id=v)
    with client.test_sessionmaker() as db:
        request_after = make_request(db, db.get(Vacancy, uuid.UUID(v)), [uuid.UUID(imported['application_id'])])
    assert request_before['source_hash'] != request_after['source_hash']
    assert request_after['source']['vacancy']['knowledge'][0]['name'] == 'Kubernetes'


def test_term_in_long_requirement_and_no_false_java_javascript_match(client):
    from app.models import Vacancy
    from app.services.knowledge import snapshot_for
    v = vacancy(client, label='Опыт Kubernetes в проектах')
    term(client, vacancy_id=v)
    with client.test_sessionmaker() as db:
        snap = snapshot_for(db, db.get(Vacancy, uuid.UUID(v)))
    assert 'K8s' in snap['criteria'][0]['aliases']
    assert len(snap['glossary_terms']) == 1
    j = vacancy(client, label='Опыт JavaScript')
    term(client, vacancy_id=j, name='Java', aliases=['JDK'])
    with client.test_sessionmaker() as db:
        snap = snapshot_for(db, db.get(Vacancy, uuid.UUID(j)))
    assert snap['glossary_terms'] == []
