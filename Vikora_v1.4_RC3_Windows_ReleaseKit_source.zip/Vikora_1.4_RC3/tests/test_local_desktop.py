"""Desktop-specific checks alongside the original corporate API regression tests."""
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

import httpx
import pytest
from sqlalchemy import select

from app.core import config
from app.local_runtime import LOCAL_SUBJECT, SingleInstanceLock, requeue_after_interrupted_shutdown
from app.models import Application, Candidate, Evaluation, Resume, UserAccount, Vacancy


def test_local_bearer_is_ephemeral_and_single_owner(client, monkeypatch):
    token = "temporary-desktop-only-secret-" + "x" * 44
    with client.test_sessionmaker.begin() as db:
        db.add(UserAccount(email="personal@vikora.invalid", full_name="Владелец Vikora",
                           sso_subject=LOCAL_SUBJECT, role="admin"))
    monkeypatch.setattr(config.settings, "auth_mode", "local")
    monkeypatch.setattr(config.settings, "app_env", "desktop")
    monkeypatch.setattr(config.settings, "vikora_local_token", token)
    assert client.get('/api/v1/me', headers={'Authorization': 'Bearer wrong'}).status_code == 401
    assert client.get('/api/v1/me', headers={'Authorization': f'Bearer {client.tokens["owner"]}'}).status_code == 401
    response = client.get('/api/v1/me', headers={'Authorization': f'Bearer {token}'})
    assert response.status_code == 200
    assert response.json()['role'] == 'admin'
    assert response.json()['full_name'] == 'Владелец Vikora'
    assert client.get('/api/v1/auth/method').json()['mode'] == 'local'


def test_single_instance_lock(tmp_path):
    location = tmp_path / 'vikora.lock'
    with SingleInstanceLock(location):
        with pytest.raises(RuntimeError, match='already running'):
            with SingleInstanceLock(location):
                pass
    with SingleInstanceLock(location):
        assert location.exists()


def test_interrupted_tasks_requeued(client, monkeypatch):
    from app import db as db_module
    monkeypatch.setattr(db_module, 'SessionLocal', client.test_sessionmaker)
    with client.test_sessionmaker.begin() as db:
        owner = db.scalar(select(UserAccount).where(UserAccount.sso_subject == 'owner'))
        vacancy = Vacancy(title='Test local', description='Example', owner_id=owner.id)
        candidate = Candidate(full_name='Тестовый Кандидат')
        db.add_all([vacancy, candidate]); db.flush()
        application = Application(vacancy_id=vacancy.id, candidate_id=candidate.id)
        resume = Resume(candidate_id=candidate.id, original_filename='test.pdf',
                        storage_key='a/b', mime_type='application/pdf', sha256='f'*64,
                        parse_status='processing')
        db.add_all([application, resume]); db.flush()
        evaluation = Evaluation(application_id=application.id, resume_id=resume.id,
                                status='processing', model_name='local-exact-match-v1',
                                prompt_version='1', criteria_snapshot={'criteria': []})
        db.add(evaluation)
        db.flush()
        ids = resume.id, evaluation.id
    assert requeue_after_interrupted_shutdown() == (1,1)
    assert requeue_after_interrupted_shutdown() == (0,0)
    with client.test_sessionmaker() as db:
        assert db.get(Resume, ids[0]).parse_status == 'pending'
        assert db.get(Evaluation, ids[1]).status == 'pending'


def test_launcher_initializes_local_sqlite(tmp_path):
    root = Path(__file__).resolve().parents[1]
    target = tmp_path / 'desktop-files'
    env = dict(os.environ, PYTHONPATH=str(root / 'src'), VIKORA_DATA_DIR=str(target))
    code = '''
from app.local_runner import configure_desktop
secret, root = configure_desktop()
from app.local_runtime import prepare_local_database
prepare_local_database()
from sqlalchemy import select
from app.db import SessionLocal
from app.models import UserAccount
with SessionLocal() as db:
    user = db.scalar(select(UserAccount).where(UserAccount.sso_subject == 'vikora-local-owner'))
    assert user and user.role == 'admin'
print('initialized')
'''
    for _ in range(2):
        completed = subprocess.run([sys.executable, '-c', code], cwd=root, env=env,
                                   text=True, capture_output=True, timeout=25)
        assert completed.returncode == 0, completed.stderr
        assert 'initialized' in completed.stdout
    assert (target/'vikora.sqlite3').is_file()
    assert (target/'files').is_dir()


def test_local_server_binds_loopback_and_rejects_without_token(tmp_path):
    root = Path(__file__).resolve().parents[1]
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0))
        port = sock.getsockname()[1]
    env = dict(os.environ, PYTHONPATH=str(root/'src'),
               VIKORA_DATA_DIR=str(tmp_path/'desktop'),
               VIKORA_DESKTOP_PORT=str(port), VIKORA_NO_BROWSER='1')
    proc = subprocess.Popen([sys.executable, '-m', 'app.local_runner'], cwd=root,
                            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        url=f'http://127.0.0.1:{port}'
        for _ in range(70):
            try:
                response=httpx.get(url+'/health', timeout=0.3)
                if response.status_code==200:
                    break
            except httpx.RequestError:
                pass
            if proc.poll() is not None:
                raise AssertionError(f'Desktop launcher exited unexpectedly: {proc.stderr.read()}')
            time.sleep(0.1)
        else:
            raise AssertionError('Desktop app did not start on loopback')
        assert response.json()['phase']=='single-user-desktop'
        assert httpx.get(url+'/api/v1/auth/method').json()['mode']=='local'
        assert httpx.get(url+'/api/v1/me').status_code==401
        assert httpx.get(url+'/api/v1/me', headers={'Host':'attacker.invalid'}).status_code==400
    finally:
        proc.terminate()
        try: proc.communicate(timeout=5)
        except subprocess.TimeoutExpired: proc.kill();proc.communicate()
