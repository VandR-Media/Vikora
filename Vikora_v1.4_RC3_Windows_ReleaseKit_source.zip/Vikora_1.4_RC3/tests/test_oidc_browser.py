"""Browser OIDC: proof of state binding, PKCE, nonce, cookie CSRF and revocation."""
import base64
import hashlib
import re
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qs, urlsplit

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from app.core.config import Settings, settings
from app.models import OIDCLoginAttempt, UserAccount, WebSession
from app.routes import auth_web


def enable_oidc(monkeypatch):
    overrides = {
        'auth_mode': 'oidc', 'oidc_issuer': 'https://idp.example.test/',
        'oidc_audience': 'vikora-api', 'oidc_jwks_url': 'https://idp.example.test/keys',
        'oidc_authorize_url': 'https://idp.example.test/authorize',
        'oidc_token_url': 'https://idp.example.test/token',
        'oidc_redirect_uri': 'http://localhost:8000/api/v1/auth/callback',
        'oidc_client_id': 'vikora-ui', 'oidc_client_secret': 'browser-confidential-secret',
        'public_origin': 'http://localhost:8000',
    }
    for key, val in overrides.items():
        monkeypatch.setattr(settings, key, val)


def start(client):
    response = client.get('/api/v1/auth/login', follow_redirects=False)
    assert response.status_code == 302
    params = parse_qs(urlsplit(response.headers['location']).query)
    return response, {k: v[0] for k, v in params.items()}


def callback(client, monkeypatch, params, *, subject='owner'):
    class FakeResponse:
        def raise_for_status(self): pass
        def json(self): return {'id_token': 'mock-id-token'}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            assert kwargs['follow_redirects'] is False
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def post(self, url, *, data, auth):
            assert url == 'https://idp.example.test/token'
            assert data['code_verifier']
            assert auth == ('vikora-ui', 'browser-confidential-secret')
            assert data['code'] == 'exchange-code'
            return FakeResponse()

    monkeypatch.setattr(auth_web.httpx, 'Client', FakeClient)
    monkeypatch.setattr(auth_web, '_jwt_id_token', lambda token, nonce: subject)
    return client.get(f"/api/v1/auth/callback?code=exchange-code&state={params['state']}", follow_redirects=False)


def test_oidc_config_fail_closed(monkeypatch):
    with pytest.raises(ValueError):
        Settings(_env_file=None, app_env='production', auth_mode='dev',
                 dev_auth_secret='valid-dev-secret-' * 3, malware_scan_mode='clamav')
    with pytest.raises(ValueError):
        Settings(_env_file=None, app_env='production', auth_mode='oidc', malware_scan_mode='disabled')
    with pytest.raises(ValueError):
        Settings(_env_file=None, app_env='production', auth_mode='oidc', malware_scan_mode='clamav',
                 oidc_issuer='https://idp.example.test/', oidc_jwks_url='https://idp.example.test/keys',
                 oidc_audience='vikora-api', oidc_client_id='vikora-ui',
                 oidc_authorize_url='https://idp.example.test/auth', oidc_token_url='https://idp.example.test/token',
                 public_origin='http://localhost:8000',
                 oidc_redirect_uri='http://localhost:8000/api/v1/auth/callback')


def test_dev_login_endpoint_disabled(client):
    assert client.get('/api/v1/auth/method').json()['mode'] == 'dev'
    assert client.get('/api/v1/auth/login').status_code == 404
    assert client.get('/api/v1/auth/session').status_code == 404


def test_oidc_redirect_pkce_and_binding(client, monkeypatch):
    enable_oidc(monkeypatch)
    resp, params = start(client)
    assert urlsplit(resp.headers['location']).scheme == 'https'
    assert params['response_type'] == 'code' and params['scope'].startswith('openid')
    assert params['code_challenge_method'] == 'S256'
    assert params['nonce'] and params['state']
    assert 'HttpOnly' in resp.headers['set-cookie'] and 'SameSite=lax' in resp.headers['set-cookie']
    assert 'vikora_dev_login=' in resp.headers['set-cookie']
    with client.test_sessionmaker() as db:
        attempt = db.get(OIDCLoginAttempt, hashlib.sha256(params['state'].encode()).hexdigest())
        assert attempt and attempt.state_hash != params['state']
        challenge = base64.urlsafe_b64encode(hashlib.sha256(attempt.code_verifier.encode()).digest()).rstrip(b'=').decode()
        assert challenge == params['code_challenge']
        assert params['nonce'] == attempt.nonce


def test_callback_requires_browser_cookie_and_is_one_time(client, monkeypatch):
    enable_oidc(monkeypatch)
    _, params = start(client)
    client.cookies.clear()
    assert client.get(f"/api/v1/auth/callback?code=exchange-code&state={params['state']}").status_code == 401
    _, params = start(client)
    response = callback(client, monkeypatch, params)
    assert response.status_code == 303
    assert response.headers['location'] == '/app'
    assert 'HttpOnly' in response.headers['set-cookie']
    assert 'SameSite=strict' in response.headers['set-cookie']
    repeat = callback(client, monkeypatch, params)
    assert repeat.status_code == 401


def test_session_protects_mutations_and_logout(client, monkeypatch):
    enable_oidc(monkeypatch)
    _, params = start(client)
    assert callback(client, monkeypatch, params).status_code == 303
    client.headers.pop('Authorization', None)
    session = client.get('/api/v1/auth/session')
    assert session.status_code == 200
    csrf = session.json()['csrf_token']
    assert len(csrf) == 64
    assert 'vikora_dev_session' not in str(session.json())
    assert client.get('/api/v1/me').json()['role'] == 'recruiter'
    vacancy = {'title':'QA инженер','description':'Поддержка автоматизированных тестов и API.', 'criteria': []}
    assert client.post('/api/v1/vacancies', json=vacancy).status_code == 403
    assert client.post('/api/v1/vacancies', json=vacancy, headers={'X-CSRF-Token': 'invalid'}).status_code == 403
    assert client.post('/api/v1/vacancies', json=vacancy,
                       headers={'X-CSRF-Token':csrf, 'Origin':'https://evil.example'}).status_code == 403
    good = client.post('/api/v1/vacancies', json=vacancy,
                       headers={'X-CSRF-Token':csrf, 'Origin':'http://localhost:8000'})
    assert good.status_code == 201, good.text
    assert client.post('/api/v1/auth/logout').status_code == 403
    logout = client.post('/api/v1/auth/logout', headers={'X-CSRF-Token':csrf})
    assert logout.status_code == 204
    assert client.get('/api/v1/me').status_code == 401
    with client.test_sessionmaker() as db:
        sessions = db.query(WebSession).all()
        assert len(sessions)==1 and sessions[0].revoked_at is not None


def test_disabled_user_cannot_use_existing_session(client, monkeypatch):
    enable_oidc(monkeypatch)
    _, params = start(client)
    assert callback(client, monkeypatch, params).status_code == 303
    client.headers.pop('Authorization', None)
    with client.test_sessionmaker.begin() as db:
        user = db.query(UserAccount).filter_by(sso_subject='owner').one()
        user.is_active = False
    assert client.get('/api/v1/me').status_code == 401


def test_unprovisioned_idp_account_rejected(client, monkeypatch):
    enable_oidc(monkeypatch)
    _, params = start(client)
    assert callback(client, monkeypatch, params, subject='stranger').status_code == 403
    assert client.get('/api/v1/auth/session').status_code == 401


def test_signed_id_token_rejects_wrong_nonce(monkeypatch):
    enable_oidc(monkeypatch)
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    class SigningKey:
        key = public_key
    class FakeJWKSClient:
        def __init__(self, *_args, **_kwargs): pass
        def get_signing_key_from_jwt(self, _token): return SigningKey()
    monkeypatch.setattr(auth_web.jwt, 'PyJWKClient', FakeJWKSClient)
    now = datetime.now(timezone.utc)
    payload = {'iss':'https://idp.example.test/','aud':'vikora-ui', 'sub':'owner',
               'nonce':'test-nonce','iat':now,'exp':now+timedelta(minutes=5)}
    token = jwt.encode(payload, private_key, algorithm='RS256')
    assert auth_web._jwt_id_token(token, 'test-nonce') == 'owner'
    from fastapi import HTTPException
    with pytest.raises(HTTPException) as err:
        auth_web._jwt_id_token(token, 'wrong-nonce')
    assert err.value.status_code == 401
