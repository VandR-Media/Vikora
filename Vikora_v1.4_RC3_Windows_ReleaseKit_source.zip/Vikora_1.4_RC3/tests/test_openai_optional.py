"""Opt-in cloud API tests: network calls are 100% mocked; synthetic candidate data only."""
import json
from pathlib import Path
import uuid

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.auth import current_user
from app.core.config import settings
from app.local_preferences import OPENAI_MODEL_TAG, read_ai_preference, save_ai_preference
from app.models import UserAccount, Application
from app.routes import local_ai
from app.services import openai_bridge
from app.services.evaluate import EvaluationFailure, validate_grounding
from app.worker import evaluate as evaluation_worker
from app.worker import parse as parse_worker
from test_evaluations import _create, _parse


@pytest.fixture
def fake_secret(monkeypatch):
    value = {'key': None}
    monkeypatch.setattr(openai_bridge, 'read_api_key', lambda: value['key'])
    monkeypatch.setattr(openai_bridge, 'write_api_key', lambda key: value.update(key=key))
    monkeypatch.setattr(openai_bridge, 'erase_api_key', lambda: value.update(key=None))
    return value


def test_preference_can_persist_api_without_key(tmp_path, monkeypatch):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    save_ai_preference('openai_api')
    assert read_ai_preference() == 'openai_api'
    raw = (tmp_path / 'ai_preferences.json').read_text()
    assert OPENAI_MODEL_TAG in raw and 'sk-' not in raw
    save_ai_preference('heuristic')
    assert read_ai_preference() == 'heuristic'


def test_openai_routes_require_setting_key_and_consent(tmp_path, monkeypatch, fake_secret):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    monkeypatch.setattr(local_ai, 'probe_ollama', lambda: {'service_running':False, 'model_installed':False})
    monkeypatch.setattr(settings, 'ai_provider', 'heuristic')
    app = FastAPI()
    app.include_router(local_ai.router)
    app.dependency_overrides[current_user] = lambda: UserAccount(role='admin', full_name='Owner')
    with TestClient(app) as client:
        assert client.post('/api/v1/local/ai/mode', json={'mode':'openai_api'}).status_code==409
        assert client.post('/api/v1/local/ai/vacancy-draft', json={'role':'HR manager','notes':'Умение вести интервью и согласовывать офферы'}).status_code==422
        assert client.post('/api/v1/local/ai/key',json={'api_key':'notkey'}).status_code==422
        key='sk-proj-'+'x'*34
        assert client.post('/api/v1/local/ai/key',json={'api_key':key}).status_code==200
        assert client.get('/api/v1/local/ai/status').json()['openai_configured'] is True
        assert key not in client.get('/api/v1/local/ai/status').text
        assert client.post('/api/v1/local/ai/mode',json={'mode':'openai_api'}).status_code==200
        assert read_ai_preference() == 'openai_api'
        assert client.delete('/api/v1/local/ai/key').status_code==200
        assert read_ai_preference() == 'heuristic'


def test_openai_fixed_endpoint_payload_and_response(monkeypatch, fake_secret):
    fake_secret['key']='sk-proj-'+'x'*30
    old=httpx.Client
    def handler(request):
        assert request.method == 'POST' and str(request.url)=='https://api.openai.com/v1/responses'
        assert request.headers['authorization']=='Bearer '+fake_secret['key']
        payload=json.loads(request.content)
        assert payload['model']==OPENAI_MODEL_TAG
        assert payload['store'] is False
        assert payload['text']['format']['type']=='json_schema'
        assert payload['text']['format']['strict'] is True
        assert 'person@example.com' not in json.dumps(payload)
        assert 'Python' in json.dumps(payload)
        result={'results':[{'criterion_key':'python','match_level':'met','evidence':[{'page':1,'excerpt':'Python в двух проектах'}],'rationale':'Подтверждено участие в проектах'}]}
        return httpx.Response(200,json={'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(result,ensure_ascii=False)}]}]})
    def factory(*args,**kwargs):
        assert kwargs['trust_env'] is False and kwargs['follow_redirects'] is False
        kwargs['transport']=httpx.MockTransport(handler)
        return old(*args,**kwargs)
    monkeypatch.setattr(openai_bridge.httpx,'Client',factory)
    pages=[{'page':1,'text':'Python в двух проектах. Контакт: person@example.com'}]
    criteria=[{'key':'python','label':'Python','weight':5}]
    result=openai_bridge.evaluate_resume_with_api(criteria,pages,OPENAI_MODEL_TAG)
    assert validate_grounding(result,criteria,pages)[0].match_level=='met'


def test_error_response_does_not_reveal_secret(monkeypatch,fake_secret):
    key='sk-proj-'+'a'*50
    fake_secret['key']=key
    original=httpx.Client
    def factory(*args,**kwargs):
        kwargs['transport']=httpx.MockTransport(lambda request:httpx.Response(401,text='Invalid '+key))
        return original(*args,**kwargs)
    monkeypatch.setattr(openai_bridge.httpx,'Client',factory)
    with pytest.raises(EvaluationFailure) as ctx:
        openai_bridge.draft_vacancy_with_api('HR manager','Подбор и адаптация сотрудников')
    assert key not in str(ctx.value)


def test_vacancy_draft_is_validated_not_saved(monkeypatch,fake_secret):
    fake_secret['key']='sk-proj-'+'x'*20
    fake={'title':'Рекрутер','description':'Подбор персонала для компании, интервью и отчётность.',
          'criteria':[{'key':'interviews','label':'Проведение интервью','description':'Опыт собеседований',
                       'importance':'must','weight':8,'sort_order':0}]}
    monkeypatch.setattr(openai_bridge,'_call_openai',lambda **kwargs:fake)
    result=openai_bridge.draft_vacancy_with_api('Рекрутер','Подбор, проведение интервью и обратная связь')
    assert result['title']=='Рекрутер' and result['status']=='draft'
    fake['criteria'][0]['weight']=200
    with pytest.raises(EvaluationFailure):
        openai_bridge.draft_vacancy_with_api('Рекрутер','Подбор и интервью сотрудников')


def test_cloud_resume_needs_explicit_flag_and_keeps_stage(client,monkeypatch,fake_secret):
    vacancy_id, app_id, resume_id=_create(client,text='Писала Python в двух проектах и отвечала за API')
    _parse(client,monkeypatch)
    monkeypatch.setattr(settings,'ai_provider','openai_api')
    monkeypatch.setattr(settings,'ai_model',OPENAI_MODEL_TAG)
    endpoint=f'/api/v1/vacancies/{vacancy_id}/applications/{app_id}/evaluations'
    assert client.post(endpoint,json={'resume_id':resume_id}).status_code==422
    assert client.post(endpoint,json={'resume_id':resume_id,'send_resume_to_openai':True}).status_code==409
    fake_secret['key']='sk-proj-'+'a'*30
    resp=client.post(endpoint,json={'resume_id':resume_id,'send_resume_to_openai':True})
    assert resp.status_code==202,resp.text
    assert resp.json()['criteria_snapshot']['provider']=='openai_api'
    assert resp.json()['criteria_snapshot']['cloud_consent'] is True
    def mock(criteria,pages,model):
        return {'results':[{'criterion_key':'python','match_level':'met',
                            'evidence':[{'page':1,'excerpt':'Python в двух проектах'}],
                            'rationale':'Прямой опыт в проектах'},
                           {'criterion_key':'docker','match_level':'unknown','evidence':[],'rationale':'Нет сведений о Docker'}]}
    monkeypatch.setattr(openai_bridge,'evaluate_resume_with_api',mock)
    monkeypatch.setattr(evaluation_worker,'SessionLocal',client.test_sessionmaker)
    assert evaluation_worker.process_next()
    result=client.get(endpoint+'/'+resp.json()['id']).json()
    assert result['status']=='completed' and result['results'][0]['match_level']=='met'
    with client.test_sessionmaker() as db:
        assert db.get(Application,uuid.UUID(app_id)).stage=='new'


def test_queued_cloud_job_is_blocked_when_switched_off(client,monkeypatch,fake_secret):
    fake_secret['key']='sk-proj-'+'a'*30
    vacancy_id,app_id,resume_id=_create(client)
    _parse(client,monkeypatch)
    monkeypatch.setattr(settings,'ai_provider','openai_api')
    monkeypatch.setattr(settings,'ai_model',OPENAI_MODEL_TAG)
    endpoint=f'/api/v1/vacancies/{vacancy_id}/applications/{app_id}/evaluations'
    q=client.post(endpoint,json={'resume_id':resume_id,'send_resume_to_openai':True}).json()['id']
    monkeypatch.setattr(settings,'ai_provider','heuristic')
    monkeypatch.setattr(evaluation_worker,'SessionLocal',client.test_sessionmaker)
    assert evaluation_worker.process_next()
    assert client.get(endpoint+'/'+q).json()['status']=='failed'
