"""Offline-only local AI tests: no downloads, real models or network requests."""
import json
import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.testclient import TestClient
import httpx
import pytest

from app.core.auth import current_user
from app.core.config import settings
from app.local_preferences import MODEL_TAG, read_ai_preference, save_ai_preference
from app.models import UserAccount
from app.routes import local_ai as ai_routes
from app.services import local_ai as ai
from app.services.evaluate import EvaluationFailure, validate_grounding


def test_preferences_default_and_atomic_round_trip(tmp_path, monkeypatch):
    monkeypatch.setenv("VIKORA_DATA_DIR", str(tmp_path))
    assert read_ai_preference() == "heuristic"
    save_ai_preference("ollama_local")
    assert read_ai_preference() == "ollama_local"
    assert (tmp_path / "ai_preferences.tmp").exists() is False
    save_ai_preference("heuristic")
    assert read_ai_preference() == "heuristic"
    with pytest.raises(ValueError):
        save_ai_preference("openai_compatible")
    (tmp_path / "ai_preferences.json").write_text('{"mode":"ollama_local", "model":"fake"}')
    assert read_ai_preference() == "heuristic"


def _mock_client(monkeypatch, handler):
    original = httpx.Client
    def factory(*args, **kwargs):
        assert kwargs["trust_env"] is False
        assert kwargs["timeout"] in (2.0, 300.0)
        kwargs["transport"] = httpx.MockTransport(handler)
        return original(*args, **kwargs)
    monkeypatch.setattr(ai.httpx, "Client", factory)


def test_ollama_metadata_probe_never_sends_resumes(monkeypatch):
    def respond(req):
        assert req.method == "GET" and str(req.url) == "http://127.0.0.1:11434/api/tags"
        return httpx.Response(200, json={"models": [{"name": MODEL_TAG}]})
    _mock_client(monkeypatch, respond)
    result = ai.probe_ollama()
    assert result["service_running"] is True and result["model_installed"] is True


def test_local_model_payload_is_loopback_and_citations_grounded(monkeypatch):
    criterion = [{"key": "python", "label": "Python", "description": "Python programming", "weight": 10}]
    pages = [{"page": 1, "text": "Разрабатывала API на Python и FastAPI более двух лет."}]
    def respond(request):
        assert str(request.url) == "http://127.0.0.1:11434/api/chat"
        posted = json.loads(request.content)
        assert posted["model"] == MODEL_TAG
        assert posted["stream"] is False and posted["think"] is False
        assert posted["format"] == "json"
        assert posted["options"]["num_ctx"] == 8192
        assert posted["messages"][1]["content"].find("Разрабатывала API") >= 0
        content = {"results": [{"criterion_key": "python", "match_level": "met",
                                "evidence": [{"page": 1, "excerpt": "Разрабатывала API на Python"}],
                                "rationale": "Подтверждён реальный опыт разработки"}]}
        return httpx.Response(200, json={"message": {"content": json.dumps(content, ensure_ascii=False)}})
    _mock_client(monkeypatch, respond)
    raw = ai.ollama_assess(criterion, pages, MODEL_TAG)
    results = validate_grounding(raw, criterion, pages)
    assert results[0].match_level == "met"


def test_hallucinated_quote_fails_closed(monkeypatch):
    criteria = [{"key": "python", "label": "Python", "weight": 5}]
    pages = [{"page": 1, "text": "Работала с Excel"}]
    def respond(req):
        content={"results":[{"criterion_key":"python","match_level":"met",
                             "evidence":[{"page":1,"excerpt":"Владею Python профессионально"}],
                             "rationale":"Найден Python"}]}
        return httpx.Response(200, json={"message":{"content":json.dumps(content,ensure_ascii=False)}})
    _mock_client(monkeypatch, respond)
    with pytest.raises(EvaluationFailure, match="excerpt not found"):
        ai.ollama_assess(criteria,pages)


def test_large_resume_is_split_without_silent_truncation(monkeypatch):
    criteria = [{"key":"excel","label":"Excel","weight":10}]
    pages = [{"page":1,"text":"Работала в Excel. " * 900}]
    seen = []
    def respond(req):
        posted=json.loads(req.content)
        seen.extend([p["text"] for p in json.loads(posted["messages"][1]["content"])["resume_pages"]])
        content={"results":[{"criterion_key":"excel","match_level":"unknown", "evidence":[],"rationale":"Недостаточно сведений"}]}
        return httpx.Response(200, json={"message":{"content":json.dumps(content,ensure_ascii=False)}})
    _mock_client(monkeypatch, respond)
    out = ai.ollama_assess(criteria,pages)
    assert len(seen) >= 2
    assert "".join(seen) == pages[0]["text"]
    assert out["results"][0]["match_level"] == "unknown"


def test_conflicting_evidence_requires_human_review():
    from app.services.evaluate import CriterionResult
    c = [{"key": "xx"}]
    r1 = CriterionResult(criterion_key="xx",match_level="met",evidence=[{"page":1,"excerpt":"Have Python"}],rationale="Meets")
    r2 = CriterionResult(criterion_key="xx",match_level="not_met",evidence=[{"page":2,"excerpt":"No experience"}],rationale="Contradiction")
    output=ai._combine(c,[[r1],[r2]])
    assert output["results"][0]["match_level"] == "unknown"
    assert output["results"][0]["evidence"] == []


def test_refuses_unknown_model_and_too_many_criteria():
    criteria=[{"key":"x","label":"X"}]
    pages=[{"page":1,"text":"Some longer document text"}]
    with pytest.raises(EvaluationFailure,match="Неизвестная"):
        ai.ollama_assess(criteria,pages,"other-model")
    with pytest.raises(EvaluationFailure,match="20 критериев"):
        ai.ollama_assess(criteria*21,pages)


def test_mode_api_is_opt_in_and_user_scoped(tmp_path, monkeypatch):
    monkeypatch.setenv("VIKORA_DATA_DIR", str(tmp_path))
    app=FastAPI()
    app.include_router(ai_routes.router)
    app.dependency_overrides[current_user] = lambda: UserAccount(role="admin",full_name="Owner")
    monkeypatch.setattr(settings,"ai_provider","heuristic")
    monkeypatch.setattr(ai_routes,"probe_ollama",lambda:{"service_running":False,"model_installed":False})
    with TestClient(app) as client:
        r=client.post("/api/v1/local/ai/mode",json={"enabled":True})
        assert r.status_code==409 and read_ai_preference()=="heuristic"
        monkeypatch.setattr(ai_routes,"probe_ollama",lambda:{"service_running":True,"model_installed":False})
        assert client.post("/api/v1/local/ai/mode",json={"enabled":True}).status_code==409
        monkeypatch.setattr(ai_routes,"probe_ollama",lambda:{"service_running":True,"model_installed":True})
        assert client.post("/api/v1/local/ai/mode",json={"enabled":True}).json()["mode"]=="ollama_local"
        assert read_ai_preference()=="ollama_local"
        assert client.get("/api/v1/local/ai/status").json()["ready"] is True
        assert client.post("/api/v1/local/ai/mode",json={"enabled":False}).json()["mode"]=="heuristic"
        assert read_ai_preference()=="heuristic"


def test_launcher_recovers_preference(tmp_path):
    # Launcher reads the explicit choice BEFORE Settings are first imported.
    import subprocess,sys
    root=Path(__file__).resolve().parents[1]
    env=dict(os.environ,PYTHONPATH=str(root/'src'),VIKORA_DATA_DIR=str(tmp_path))
    (tmp_path/'ai_preferences.json').write_text(json.dumps({"mode":"ollama_local","model":MODEL_TAG}))
    code="from app.local_runner import configure_desktop; configure_desktop(); from app.core.config import settings; print(settings.ai_provider,settings.ai_model)"
    result=subprocess.run([sys.executable,"-c",code],cwd=root,env=env,text=True,capture_output=True,timeout=25)
    assert result.returncode==0,result.stderr
    assert "ollama_local qwen3:4b" in result.stdout
