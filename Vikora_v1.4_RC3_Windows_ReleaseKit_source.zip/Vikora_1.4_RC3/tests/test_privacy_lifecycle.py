"""Privacy test suite uses only synthetic people and files."""
from datetime import datetime, timedelta, timezone
from io import BytesIO
from pathlib import Path
import uuid

from docx import Document
from sqlalchemy import select

from app.core.config import settings
from app.models import (
    Application, AuditEvent, Candidate, CriterionEvaluation, Evaluation,
    PurgeBlob, PurgeRequest, Resume,
)
from app.services import privacy
from app.services.uploads import blob_path


def auth(client, who="admin"):
    return {"Authorization": f"Bearer {client.tokens[who]}"}


def setup(client):
    vacancy = client.post("/api/v1/vacancies", json={
        "title": "Data engineer", "description": "Build a reliable internal data processing platform",
        "criteria": [{"key": "python", "label": "Python", "importance": "must", "weight": 8}],
    })
    assert vacancy.status_code == 201
    vid = vacancy.json()["id"]
    a = client.post(f"/api/v1/vacancies/{vid}/applications", json={
        "full_name": "Synthetic Example", "email": "synthetic@example.invalid",
    })
    assert a.status_code == 201, a.text
    return vid, a.json()["id"], a.json()["candidate_id"]


def synthetic_docx():
    stream = BytesIO()
    doc = Document()
    doc.add_paragraph("Used Python for a sample internal project")
    doc.save(stream)
    return stream.getvalue()


def upload(client, vacancy, app):
    response = client.post(f"/api/v1/vacancies/{vacancy}/applications/{app}/resumes",
        files={"file": ("demo.docx", synthetic_docx(),
               "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert response.status_code == 201, response.text
    return response.json()["id"]


def purge(client, candidate, who="admin", confirm=True):
    headers = auth(client, who)
    headers["X-Confirm-Candidate-Id"] = candidate if confirm else str(uuid.uuid4())
    return client.delete(f"/api/v1/privacy/candidates/{candidate}", headers=headers)


def test_new_candidates_get_a_deadline(client):
    vid, app, cid = setup(client)
    item = client.get(f"/api/v1/vacancies/{vid}/applications").json()[0]
    deadline = datetime.fromisoformat(item["candidate"]["retention_until"])
    now = datetime.now(timezone.utc)
    assert now + timedelta(days=179) < deadline < now + timedelta(days=181)
    assert client.get("/api/v1/privacy/overview", headers=auth(client)).json()["missing_retention_deadline"] == 0


def test_purge_rejects_non_admin_and_mismatched_confirmation(client):
    vid, app, cid = setup(client)
    assert purge(client, cid, "owner").status_code == 403
    assert purge(client, cid, "reviewer").status_code == 403
    assert purge(client, cid, confirm=False).status_code == 400
    assert client.delete(f"/api/v1/privacy/candidates/{cid}", headers=auth(client)).status_code == 422
    assert client.delete(f"/api/v1/privacy/candidates/{uuid.uuid4()}",
                         headers={**auth(client), "X-Confirm-Candidate-Id":str(uuid.uuid4())}).status_code == 400
    with client.test_sessionmaker() as db:
        assert db.get(Candidate, uuid.UUID(cid)) is not None


def test_purge_removes_blob_db_evaluations_and_redacts_old_audit(client):
    vid, app, cid = setup(client)
    rid = upload(client, vid, app)
    # Simulate a second application of the same person in a different vacancy.
    second_vid = client.post("/api/v1/vacancies", json={
        "title": "Other vacancy", "description": "A separate synthetic vacancy description",
    }).json()["id"]
    with client.test_sessionmaker.begin() as db:
        second = Application(vacancy_id=uuid.UUID(second_vid), candidate_id=uuid.UUID(cid))
        db.add(second)
        db.flush()
        ev = Evaluation(application_id=uuid.UUID(app), resume_id=uuid.UUID(rid),
                        status="completed", model_name="test", prompt_version="test",
                        criteria_snapshot={"criteria": []}, overall_score=80)
        db.add(ev)
        db.flush()
        evaluation_id = ev.id
        db.add(CriterionEvaluation(evaluation_id=ev.id, criterion_key="python",
                                   match_level="met", evidence=[{"page": 1, "excerpt": "Python"}],
                                   rationale="synthetic"))
    with client.test_sessionmaker() as db:
        resume = db.get(Resume, uuid.UUID(rid))
        path = blob_path(resume.storage_key)
        assert path.exists()
        assert db.query(AuditEvent).filter_by(entity_id=uuid.UUID(rid)).count() > 0

    result = purge(client, cid)
    assert result.status_code == 202, result.text
    data = result.json()
    assert data["state"] == "completed"
    assert data["applications_removed"] == 2
    assert data["resumes_removed"] == 1
    assert data["evaluations_removed"] == 1
    assert data["audit_events_redacted"] >= 2
    assert data["files_pending"] == 0
    assert not path.exists()
    with client.test_sessionmaker() as db:
        for model in [Candidate, Resume, Application, Evaluation, CriterionEvaluation]:
            assert db.query(model).count() == 0
        assert db.query(AuditEvent).filter(AuditEvent.entity_id.in_([
            uuid.UUID(cid), uuid.UUID(app), uuid.UUID(rid), evaluation_id,
        ])).count() == 0
        assert db.query(AuditEvent).filter_by(action="privacy.candidate.purged").count() == 1
        upload_log = db.query(AuditEvent).filter_by(action="resume.uploaded").first()
        assert upload_log.details == {"redacted_after_privacy_purge": True}
        assert db.query(PurgeBlob).filter_by(state="completed").count() == 1
    assert client.get(f"/api/v1/vacancies/{vid}/applications").json() == []
    assert client.get(f"/api/v1/privacy/purge-requests/{data['request_id']}",
                      headers=auth(client)).json()["state"] == "completed"
    assert purge(client, cid).status_code == 404


def test_unlink_failure_is_retryable_and_has_no_pii_in_error(client, monkeypatch):
    vid, app, cid = setup(client)
    rid = upload(client, vid, app)
    with client.test_sessionmaker() as db:
        key = db.get(Resume, uuid.UUID(rid)).storage_key
    path = blob_path(key)
    original = privacy._unlink_blob

    def fail(_):
        raise PermissionError(f"sensitive/path/{cid}/should-not-be-stored")

    monkeypatch.setattr(privacy, "_unlink_blob", fail)
    response = purge(client, cid)
    assert response.status_code == 202
    data = response.json()
    assert data["state"] == "cleanup_pending"
    assert data["files_pending"] == 1
    assert data["files_with_retry"] == 1
    assert path.exists()  # physical erasure has NOT been falsely acknowledged
    with client.test_sessionmaker() as db:
        assert db.get(Candidate, uuid.UUID(cid)) is None
        ticket = db.query(PurgeBlob).one()
        assert ticket.error_code == "PermissionError"
        assert cid not in str(ticket.error_code)
        ticket.next_attempt_at = privacy.utcnow() - timedelta(seconds=1)
        db.commit()
    monkeypatch.setattr(privacy, "_unlink_blob", original)
    with client.test_sessionmaker() as db:
        privacy.try_cleanup_request(db, uuid.UUID(data["request_id"]))
        assert privacy.receipt_status(db, uuid.UUID(data["request_id"]))["state"] == "completed"
    assert not path.exists()


def test_no_resume_purge_is_immediately_complete(client):
    vid, app, cid = setup(client)
    resp = purge(client, cid)
    assert resp.status_code == 202
    assert resp.json()["state"] == "completed"
    assert resp.json()["resumes_removed"] == 0
    assert resp.json()["files_pending"] == 0
    assert resp.json()["finished_at"] is not None


def test_retention_update_and_policy_limit(client):
    vid, app, cid = setup(client)
    url = f"/api/v1/privacy/candidates/{cid}/retention"
    assert client.patch(url, json={"days":1}).status_code == 403
    too_long = client.patch(url, json={"days":settings.max_retention_days + 1}, headers=auth(client))
    assert too_long.status_code == 422
    good = client.patch(url, json={"days":20}, headers=auth(client))
    assert good.status_code == 200
    new_deadline = datetime.fromisoformat(good.json()["retention_until"])
    assert datetime.now(timezone.utc) + timedelta(days=19) < new_deadline
    with client.test_sessionmaker() as db:
        assert db.query(AuditEvent).filter_by(action="privacy.retention.changed").count() == 1


def test_expiry_worker_purges_only_overdue_and_skips_legacy_without_deadline(client):
    vid, app, cid = setup(client)
    expired_resume = upload(client, vid, app)
    _, _, active = setup(client)
    _, _, legacy = setup(client)
    with client.test_sessionmaker() as db:
        db.get(Candidate, uuid.UUID(cid)).retention_until = privacy.utcnow() - timedelta(days=1)
        db.get(Candidate, uuid.UUID(legacy)).retention_until = None
        db.commit()
        overview = privacy.retention_overview(db)
        assert overview["expired_candidates"] == 1
        assert overview["missing_retention_deadline"] == 1
        receipt_ids = privacy.purge_expired_batch(db)
        assert len(receipt_ids) == 1
        privacy.try_cleanup_request(db, receipt_ids[0])
        assert db.get(Candidate, uuid.UUID(cid)) is None
        assert db.get(Candidate, uuid.UUID(active)) is not None
        assert db.get(Candidate, uuid.UUID(legacy)) is not None
        assert privacy.receipt_status(db, receipt_ids[0])["reason"] == "retention_expired"


def test_admin_can_read_aggregate_overview_but_others_cannot(client):
    setup(client)
    assert client.get("/api/v1/privacy/overview").status_code == 403
    overview = client.get("/api/v1/privacy/overview", headers=auth(client))
    assert overview.status_code == 200
    assert overview.json()["expired_candidates"] == 0
    assert overview.json()["pending_file_cleanup"] == 0
    assert "candidate_name" not in str(overview.json())
    assert client.get(f"/api/v1/privacy/purge-requests/{uuid.uuid4()}",
                      headers=auth(client)).status_code == 404


def test_worker_does_not_resurrect_deleted_pending_tasks(client, monkeypatch):
    from app.worker import parse as parse_worker, evaluate as eval_worker
    vid, app, cid = setup(client)
    rid = upload(client, vid, app)
    with client.test_sessionmaker.begin() as db:
        db.add(Evaluation(application_id=uuid.UUID(app), resume_id=uuid.UUID(rid),
                          status="pending", model_name="local-exact-match-v1",
                          prompt_version="v1", criteria_snapshot={"criteria": []}))
    assert purge(client, cid).json()["state"] == "completed"
    monkeypatch.setattr(parse_worker, "SessionLocal", client.test_sessionmaker)
    monkeypatch.setattr(eval_worker, "SessionLocal", client.test_sessionmaker)
    assert parse_worker.process_next() is False
    assert eval_worker.process_next() is False
    with client.test_sessionmaker() as db:
        assert db.query(Resume).count() == 0
        assert db.query(Evaluation).count() == 0


def test_prune_completed_receipts_does_not_prune_audit_events(client):
    vid, app, cid = setup(client)
    response = purge(client, cid)
    request_id = uuid.UUID(response.json()["request_id"])
    with client.test_sessionmaker() as db:
        receipt = db.get(PurgeRequest, request_id)
        receipt.finished_at = privacy.utcnow() - timedelta(days=32)
        db.commit()
        assert privacy.prune_old_receipts(db, days=30) == 1
        assert db.get(PurgeRequest, request_id) is None
        assert db.query(AuditEvent).filter_by(action="privacy.candidate.purged").count() == 1
