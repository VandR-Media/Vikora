from pathlib import Path
import json

def test_synthetic_cases_are_well_formed_and_not_real_cv_data():
    data=json.loads((Path(__file__).resolve().parents[1]/'examples'/'quality_cases.json').read_text(encoding='utf-8'))
    ids=set()
    for case in data['cases']:
        assert case['id'] not in ids
        ids.add(case['id'])
        assert case['pages'] and len(case['criteria'])==len(case['expected'])
        assert {c['key'] for c in case['criteria']} == set(case['expected'])
        assert all(v in {'met','partial','not_met','unknown'} for v in case['expected'].values())
        assert 'Вымышлен' in case['pages'][0]['text']
    assert len(ids) >= 6
