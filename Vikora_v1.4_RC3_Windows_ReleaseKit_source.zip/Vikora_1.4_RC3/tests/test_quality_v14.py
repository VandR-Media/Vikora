"""V1.4: synthetic-only, opt-in quality comparisons; never any real candidate data."""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.auth import current_user
from app.routes.quality_audit import router
from app.services import quality_audit as qa


def _evidence(case):
    return [{"page": case['pages'][0]['page'], "excerpt": case['pages'][0]['text'][:32]}]


def fake_correct(_provider, criteria, pages):
    lookup = {case['pages'][0]['text']: case for case in qa.read_synthetic_cases()}
    case = lookup[pages[0]['text']]
    return {'results': [{'criterion_key': criterion['key'], 'match_level': case['expected'][criterion['key']],
                        'evidence': [] if case['expected'][criterion['key']] == 'unknown' else _evidence(case),
                        'rationale': 'Основано на конкретном фрагменте резюме'} for criterion in criteria]}


def fake_bad_quote(provider, criteria, pages):
    return {'results': [{'criterion_key': item['key'], 'match_level': 'met',
                         'evidence': [{'page': 1, 'excerpt': 'несуществующая в резюме цитата'}],
                         'rationale': 'Необоснованный вывод'} for item in criteria]}


def test_data_set_is_synthetic_and_does_not_depend_on_user_files():
    cases = qa.read_synthetic_cases()
    assert len(cases) == 22
    assert len({case['id'] for case in cases}) == len(cases)
    assert all(case['synthetic'] and case['pages'][0]['text'].startswith('Вымышленн') for case in cases)
    assert any('ИНСТРУКЦИЯ МОДЕЛИ:' in c['pages'][0]['text'] for c in cases)
    assert any('K8s' in c['pages'][0]['text'] for c in cases)


def test_comparison_reports_exact_agreement_and_safe_metrics():
    cases = qa.read_synthetic_cases()
    result = qa.evaluate_cases('heuristic', cases, assess=fake_correct)
    assert result['summary']['cases_completed'] == len(cases)
    assert result['summary']['agreement_percent_on_assessed'] == 100
    assert result['summary']['met_overclaims'] == 0
    assert result['summary']['cases_failed'] == 0
    assert all(item['correctly_matched'] for item in result['results'])


def test_bad_quotes_are_failures_not_silently_counted_as_unknown():
    result = qa.evaluate_cases('heuristic', qa.read_synthetic_cases()[:2], assess=fake_bad_quote)
    assert result['summary']['criteria_attempted'] == 2
    assert result['summary']['criteria_assessed'] == 0
    assert result['summary']['agreement_percent_on_assessed'] is None
    assert result['summary']['cases_failed'] == 2
    assert all(item['predicted'] == {} for item in result['results'])
    assert 'несуществующая' not in json.dumps(result, ensure_ascii=False)


def test_overclaim_and_unknown_misread_are_counted():
    examples = [c for c in qa.read_synthetic_cases() if c['id'] in ['absent-data', 'mentioned-only']]
    def unsafe(_provider, criteria, pages):
        return {'results': [{'criterion_key': criteria[0]['key'], 'match_level': 'met',
                'evidence': [{'page': 1, 'excerpt': pages[0]['text'][:32]}], 'rationale': 'Обобщение без доказательств'}]}
    result = qa.evaluate_cases('heuristic', examples, assess=unsafe)
    assert result['summary']['met_overclaims'] == 2
    assert result['summary']['unsupported_claims_on_unknown'] == 1
    assert result['summary']['agreement_percent_on_assessed'] == 0


def test_server_rejects_unconfirmed_cloud_and_invalid_case_sets(monkeypatch,tmp_path):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    ids=[c['id'] for c in qa.read_synthetic_cases()]
    with pytest.raises(PermissionError):
        qa.begin_run('openai_api', ids[:1], confirmed_cloud=False)
    with pytest.raises(ValueError):
        qa.begin_run('heuristic', ids[:1]*2, confirmed_cloud=False)
    with pytest.raises(ValueError):
        qa.begin_run('heuristic', ['unknown-case'], confirmed_cloud=False)
    with pytest.raises(ValueError):
        qa.begin_run('heuristic', [], confirmed_cloud=False)
    with pytest.raises(ValueError):
        qa.begin_run('heuristic', ids+ids[:3], confirmed_cloud=False)
    with pytest.raises(ValueError):
        qa.begin_run('bad-provider', ids[:1], confirmed_cloud=False)
    with pytest.raises(ValueError):
        qa.begin_run('openai_api', ids[:7], confirmed_cloud=True)
    assert not (tmp_path/'quality_audits').exists()


def _wait(run_id, timeout=12):
    deadline=time.time()+timeout
    while time.time()<deadline:
        job=qa.get_report(run_id)
        if job and job['status'] in ('completed','failed'):
            return job
        time.sleep(.025)
    raise AssertionError('Benchmark did not finish')


def test_local_run_persists_only_synthetic_metadata_and_can_be_compared(monkeypatch,tmp_path):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    monkeypatch.setattr(qa, 'provider_assess', fake_correct)
    ids = [c['id'] for c in qa.read_synthetic_cases()[:3]]
    job=qa.begin_run('heuristic', ids, confirmed_cloud=False)
    report=_wait(job['run_id'])
    assert report['summary']['exact_agreement'] == 3
    assert report['status'] == 'completed'
    path=tmp_path/'quality_audits'/f"{job['run_id']}.json"
    data=path.read_text(encoding='utf-8')
    assert 'Вымышленное резюме' not in data  # do not persist CV text
    assert 'rationale' not in data  # do not persist model prose
    assert qa.recent_reports()[0]['run_id'] == job['run_id']
    assert qa.get_report('../secret') is None
    assert qa.get_report('not-a-uuid') is None


def test_concurrent_run_rejected(monkeypatch,tmp_path):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    entered=threading.Event()
    release=threading.Event()
    def sleepy(_provider, criteria, pages):
        entered.set()
        release.wait(4)
        return fake_correct(_provider, criteria, pages)
    monkeypatch.setattr(qa, 'provider_assess', sleepy)
    ids=[qa.read_synthetic_cases()[0]['id']]
    first=qa.begin_run('heuristic', ids, confirmed_cloud=False)
    try:
        assert entered.wait(2)
        with pytest.raises(RuntimeError, match='выполняется'):
            qa.begin_run('heuristic', ids, confirmed_cloud=False)
    finally:
        release.set()
    assert _wait(first['run_id'])['status'] == 'completed'


def test_cloud_calls_require_key_even_with_confirmation(monkeypatch,tmp_path):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    from app.services import openai_bridge
    monkeypatch.setattr(openai_bridge, 'read_api_key', lambda:None)
    with pytest.raises(ValueError, match='API-ключ'):
        qa.begin_run('openai_api',[qa.read_synthetic_cases()[0]['id']],confirmed_cloud=True)


def test_http_routes_require_auth_and_validate_cloud_confirmation(monkeypatch, tmp_path):
    monkeypatch.setenv('VIKORA_DATA_DIR', str(tmp_path))
    mini=FastAPI()
    mini.include_router(router)
    with TestClient(mini) as c:
        assert c.get('/api/v1/local/quality/cases').status_code == 401
    mini.dependency_overrides[current_user] = lambda: object()
    with TestClient(mini) as c:
        found=c.get('/api/v1/local/quality/cases')
        assert found.status_code == 200 and len(found.json()['cases']) == 22
        requested=c.post('/api/v1/local/quality/runs',json={'provider':'openai_api', 'case_ids':['absent-data']})
        assert requested.status_code == 403
        assert c.get('/api/v1/local/quality/runs/../private').status_code in (404, 405)
