"""Malware scan must not silently permit files when scanning fails."""
import socket
from pathlib import Path
import pytest
from fastapi import HTTPException
from app.core.config import settings
from app.services.uploads import scan_for_malware


def test_missing_clamav_fails_closed(tmp_path, monkeypatch):
    file = tmp_path / 'synthetic.pdf'
    file.write_bytes(b'%PDF-1.7\n')
    monkeypatch.setattr(settings, 'malware_scan_mode', 'clamav')
    def unavailable(*args, **kwargs):
        raise ConnectionRefusedError('scanner absent')
    monkeypatch.setattr(socket, 'create_connection', unavailable)
    with pytest.raises(HTTPException) as err:
        scan_for_malware(file)
    assert err.value.status_code == 503


@pytest.mark.parametrize('answer,expected', [(b'stream: OK\x00', None),
                                             (b'stream: Eicar-Test FOUND\x00', 422),
                                             (b'stream: ERROR\x00', 503)])
def test_clamav_protocol(tmp_path, monkeypatch, answer, expected):
    file = tmp_path / 'sample.docx'
    file.write_bytes(b'SYNTHETIC')
    monkeypatch.setattr(settings, 'malware_scan_mode', 'clamav')
    class Scanner:
        def __init__(self): self.chunks=[]
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def settimeout(self, seconds): pass
        def sendall(self, data): self.chunks.append(data)
        def recv(self, size): return answer
    fake=Scanner()
    monkeypatch.setattr(socket, 'create_connection', lambda *args, **kw: fake)
    if expected:
        with pytest.raises(HTTPException) as err:
            scan_for_malware(file)
        assert err.value.status_code==expected
    else:
        scan_for_malware(file)
    assert fake.chunks[0].startswith(b'zINSTREAM')
    assert fake.chunks[-1] == b'\x00\x00\x00\x00'
