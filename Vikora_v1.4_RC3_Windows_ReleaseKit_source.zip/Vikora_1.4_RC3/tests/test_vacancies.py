def sample_vacancy():
    return {
        "title": "Python Backend Developer",
        "description": "Разработка API для внутренней платформы рекрутинга",
        "department": "IT",
        "status": "draft",
        "criteria": [
            {"key": "python", "label": "Python", "importance": "must", "weight": 10},
            {"key": "postgresql", "label": "PostgreSQL", "importance": "nice", "weight": 6},
        ],
    }


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_create_list_get_vacancy(client):
    result = client.post("/api/v1/vacancies", json=sample_vacancy())
    assert result.status_code == 201, result.text
    doc = result.json()
    assert len(doc["criteria"]) == 2
    assert doc["criteria"][0]["key"] == "python"
    uid = doc["id"]

    listed = client.get("/api/v1/vacancies")
    assert listed.status_code == 200
    assert len(listed.json()) == 1
    assert client.get(f"/api/v1/vacancies/{uid}").json()["id"] == uid


def test_patch_replaces_criteria(client):
    uid = client.post("/api/v1/vacancies", json=sample_vacancy()).json()["id"]
    response = client.patch(f"/api/v1/vacancies/{uid}", json={
        "status": "open",
        "criteria": [{"key": "fastapi", "label": "FastAPI", "importance": "must", "weight": 9}],
    })
    assert response.status_code == 200, response.text
    assert response.json()["status"] == "open"
    assert [x["key"] for x in response.json()["criteria"]] == ["fastapi"]


def test_invalid_weight_and_duplicate_keys(client):
    payload = sample_vacancy()
    payload["criteria"][0]["weight"] = 100
    assert client.post("/api/v1/vacancies", json=payload).status_code == 422
    payload = sample_vacancy()
    payload["criteria"][1]["key"] = "python"
    assert client.post("/api/v1/vacancies", json=payload).status_code == 422


def test_not_found(client):
    assert client.get("/api/v1/vacancies/aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa").status_code == 404


def test_patch_rejects_null_for_required_fields(client):
    uid = client.post("/api/v1/vacancies", json=sample_vacancy()).json()["id"]
    for key in ("title", "description", "status", "criteria"):
        resp = client.patch(f"/api/v1/vacancies/{uid}", json={key: None})
        assert resp.status_code == 422, (key, resp.text)
