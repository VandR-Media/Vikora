"""A browser UI must be static-only until the user proves their identity."""
import re


def test_ui_served_with_strict_headers(client):
    response = client.get('/app')
    assert response.status_code == 200
    assert 'Vikora' in response.text
    assert '/assets/app.js' in response.text
    assert response.headers['Cache-Control'] == 'no-store'
    assert response.headers['Referrer-Policy'] == 'no-referrer'
    assert "script-src 'self'" in response.headers['Content-Security-Policy']
    assert "frame-ancestors 'none'" in response.headers['Content-Security-Policy']
    assert '<script>' not in response.text
    assert not re.search(r'\son\w+\s*=', response.text)


def test_ui_assets_exist_and_no_secrets(client):
    script = client.get('/assets/app.js')
    css = client.get('/assets/styles.css')
    assert script.status_code == css.status_code == 200
    assert script.headers['content-type'].split(';', 1)[0] in {'text/javascript', 'application/javascript'}
    assert 'text/css' in css.headers['content-type']
    assert 'localStorage' not in script.text
    # The personal desktop mode intentionally retains its one-run random token
    # only within the browser tab, not in persistent localStorage.
    assert "sessionStorage.setItem('vikora-desktop-session'" in script.text
    assert 'history.replaceState' in script.text
    assert 'eval(' not in script.text
    assert 'innerHTML=shell(content)' in script.text


def test_me_requires_token(client):
    unauth = client.get('/api/v1/me', headers={'Authorization': ''})
    assert unauth.status_code == 401
    response = client.get('/api/v1/me')
    assert response.status_code == 200
    assert response.json()['role'] == 'recruiter'
    assert response.json()['full_name'] == 'Owner'
    assert 'sso_subject' not in response.json()
    assert response.headers['Cache-Control'] == 'no-store'


def test_me_uses_db_role_not_token_claim(client):
    response = client.get('/api/v1/me',headers={'Authorization': f"Bearer {client.tokens['reviewer']}"})
    assert response.status_code == 200
    assert response.json()['role'] == 'reviewer'
