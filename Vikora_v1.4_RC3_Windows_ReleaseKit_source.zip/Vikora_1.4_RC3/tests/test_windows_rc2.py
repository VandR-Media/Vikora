"""Cross-platform tests for the RC2 Windows-release preparation."""
from pathlib import Path
import subprocess
import sys

from app.local_runner import open_browser_when_ready
from app.local_runtime import SingleInstanceLock


class FakeServer:
    def __init__(self, *, started=False, should_exit=False):
        self.started = started
        self.should_exit = should_exit


def test_browser_opens_only_after_server_is_ready(monkeypatch):
    opened = []
    monkeypatch.setattr('app.local_runner.webbrowser.open', opened.append)
    assert open_browser_when_ready(FakeServer(started=True), 18467, 'demo-token')
    assert opened == ['http://127.0.0.1:18467/app#vikora=demo-token']


def test_browser_does_not_open_on_shutdown(monkeypatch):
    opened = []
    monkeypatch.setattr('app.local_runner.webbrowser.open', opened.append)
    assert not open_browser_when_ready(FakeServer(should_exit=True), 18467, 'demo-token')
    assert opened == []


def test_browser_does_not_open_if_not_ready(monkeypatch):
    opened = []
    monkeypatch.setattr('app.local_runner.webbrowser.open', opened.append)
    assert not open_browser_when_ready(FakeServer(), 18467, 'demo-token', max_wait=0)
    assert opened == []


def test_release_artifacts_validate_consistently():
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run([sys.executable, str(root / 'packaging/verify_release_sources.py')],
                            capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'NOT a Windows' in result.stdout


def test_installer_test_uses_same_profile_for_reinstall():
    root = Path(__file__).resolve().parents[1]
    script = (root / 'packaging/test_installer_windows.ps1').read_text(encoding='utf-8')
    assert script.count('--data-dir $testProfile') >= 2
    assert "'vikora.sqlite3'" in script
    assert "'synthetic_smoke_id.txt'" in script
