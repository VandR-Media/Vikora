"""Non-Windows-safe verification of the future Windows release contract."""
from pathlib import Path
import subprocess
import sys


def test_user_diagnostics_are_read_only():
    root = Path(__file__).resolve().parents[1]
    script = (root / 'packaging/diagnose_windows.ps1').read_text(encoding='utf-8')
    assert 'Get-MpComputerStatus' in script
    assert "'127.0.0.1', 18467" in script
    assert 'Start-Process' in script and 'notepad.exe' in script
    assert 'Read-only' in script
    assert 'Get-CimInstance' in script
    assert 'Invoke-RestMethod' not in script
    assert 'New-Item' not in script
    assert 'Set-MpPreference' not in script
    assert 'Get-Content' not in script
    assert 'Upload' not in script
    assert 'WriteAllLines' in script


def test_ci_installer_is_kept_only_after_windows_tests_pass():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / '.github/workflows/windows-installer.yml').read_text(encoding='utf-8')
    assert workflow.index('Test Vikora on Windows') < workflow.index('Build application and installer')
    assert workflow.index('Smoke-test frozen Windows EXE') < workflow.index('Upload Windows installer')
    assert workflow.index('Test installation, reinstallation and uninstallation') < workflow.index('Upload Windows installer')
    assert 'retention-days: 30' in workflow
    assert 'windows-2022' in workflow
    assert 'workflow_dispatch:' in workflow


def test_source_consistency_after_rc3_changes():
    root = Path(__file__).resolve().parents[1]
    proc = subprocess.run([sys.executable, str(root / 'packaging/verify_release_sources.py')],
                          cwd=root, capture_output=True, text=True)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert '1.4.0-rc3' in proc.stdout
