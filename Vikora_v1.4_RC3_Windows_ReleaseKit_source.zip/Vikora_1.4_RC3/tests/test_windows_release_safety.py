"""Portable preflight tests; CI additionally executes actual frozen EXE on Windows."""
from pathlib import Path
import sqlite3

import pytest

from app.local_runtime import check_existing_sqlite


def test_no_database_yet_is_expected(tmp_path: Path):
    check_existing_sqlite(tmp_path / "vikora.sqlite3")


def test_existing_valid_database_passes(tmp_path: Path):
    path = tmp_path / "vikora.sqlite3"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE user_accounts (id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO user_accounts VALUES ('test')")
        conn.commit()
    before = path.read_bytes()
    check_existing_sqlite(path)
    assert path.read_bytes() == before


def test_corrupt_database_fails_without_changes(tmp_path: Path):
    path = tmp_path / "vikora.sqlite3"
    original = b"NOT A SQLITE DATABASE - DO NOT DELETE"
    path.write_bytes(original)
    with pytest.raises(RuntimeError, match="базу"):
        check_existing_sqlite(path)
    assert path.read_bytes() == original


def test_unrelated_database_is_not_overwritten(tmp_path: Path):
    path = tmp_path / "vikora.sqlite3"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE some_other_app (value TEXT)")
        conn.execute("INSERT INTO some_other_app VALUES ('keep me')")
        conn.commit()
    with pytest.raises(RuntimeError, match="неизвестная"):
        check_existing_sqlite(path)
    with sqlite3.connect(path) as conn:
        assert conn.execute("SELECT value FROM some_other_app").fetchone() == ("keep me",)


def test_symlink_database_is_rejected(tmp_path: Path):
    target = tmp_path / "real.sqlite3"
    target.write_bytes(b"untouched")
    link = tmp_path / "vikora.sqlite3"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("Symlink creation is not permitted on this platform")
    with pytest.raises(RuntimeError, match="недопустимый"):
        check_existing_sqlite(link)
    assert target.read_bytes() == b"untouched"
