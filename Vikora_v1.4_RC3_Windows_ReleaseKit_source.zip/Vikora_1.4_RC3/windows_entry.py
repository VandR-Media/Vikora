"""PyInstaller must build this Windows executable ON Windows."""
from app.local_runner import main

if __name__ == "__main__":
    main()
