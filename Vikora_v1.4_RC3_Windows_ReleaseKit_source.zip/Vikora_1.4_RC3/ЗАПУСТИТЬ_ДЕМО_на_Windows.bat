@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo First launch: preparing Vikora. Requires Python 3.11+ and an internet connection for installing libraries.
 where py >nul 2>nul
 if errorlevel 1 (
  echo Python is not installed. The final .exe will NOT require Python.
  pause
  exit /b 1
 )
 py -3 -m venv ".venv"
 if errorlevel 1 (pause & exit /b 1)
 ".venv\Scripts\python.exe" -m pip install -e "."
 if errorlevel 1 (pause & exit /b 1)
)
".venv\Scripts\python.exe" -m app.local_runner
if errorlevel 1 pause
