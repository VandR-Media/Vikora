@echo off
chcp 65001 >nul
setlocal
where ollama >nul 2>nul
if errorlevel 1 (
 echo Vikora: AI engine Ollama is not installed or not found.
 echo Opening the official Ollama Windows download page.
 start "" "https://ollama.com/download/windows"
 echo Install Ollama for Windows. Then close this window and double-click this file again.
 pause
 exit /b 1
)
echo Preparing local qwen3:4b AI model. Download is about 2.5 GB.
echo Internet is required for this FIRST download only.
ollama pull qwen3:4b
if errorlevel 1 (
 echo Download failed. Check your internet connection and free disk space, then try again.
 pause
 exit /b 1
)
echo Local AI model is installed.
echo Open Vikora and click "Refresh local AI" then "Enable local AI" on the main page.
pause
